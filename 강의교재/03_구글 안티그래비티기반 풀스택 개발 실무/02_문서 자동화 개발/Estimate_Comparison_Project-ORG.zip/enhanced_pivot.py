import pandas as pd
from estimate_reader import get_dataframes

def create_enhanced_pivot_tables():
    """
    최저가와 업체명 컬럼이 추가된 향상된 PivotTable을 생성하는 함수
    """
    # DataFrame 가져오기
    products_df, conditions_df = get_dataframes()
    
    print("=" * 100)
    print("품목별 견적 비교 PivotTable (최저가 분석 포함)")
    print("=" * 100)
    
    # 1. 품목별 단가 비교 PivotTable
    print("\n📊 품목별 단가 비교 PivotTable")
    print("-" * 100)
    
    unit_price_pivot = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values='단가', 
        aggfunc='first'
    )
    
    # 최저가와 최저가 업체 계산
    unit_price_pivot['최저가'] = unit_price_pivot.min(axis=1)
    unit_price_pivot['최저가업체'] = unit_price_pivot.iloc[:, :-1].idxmin(axis=1)
    
    # 가격을 천 단위로 포맷팅
    unit_price_formatted = unit_price_pivot.copy()
    for col in unit_price_pivot.columns:
        if col not in ['최저가업체']:
            unit_price_formatted[col] = unit_price_pivot[col].map(
                lambda x: f"{x:,.0f}원" if pd.notna(x) else "-"
            )
    
    print(unit_price_formatted.to_string())
    
    # 2. 품목별 총액 비교 PivotTable
    print("\n💰 품목별 총액 비교 PivotTable")
    print("-" * 100)
    
    total_price_pivot = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values='총액', 
        aggfunc='first'
    )
    
    # 최저가와 최저가 업체 계산
    total_price_pivot['최저가'] = total_price_pivot.min(axis=1)
    total_price_pivot['최저가업체'] = total_price_pivot.iloc[:, :-1].idxmin(axis=1)
    
    # 총액을 천 단위로 포맷팅
    total_price_formatted = total_price_pivot.copy()
    for col in total_price_pivot.columns:
        if col not in ['최저가업체']:
            total_price_formatted[col] = total_price_pivot[col].map(
                lambda x: f"{x:,.0f}원" if pd.notna(x) else "-"
            )
    
    print(total_price_formatted.to_string())
    
    # 3. 최저가 요약 분석
    print("\n🏆 품목별 최저가 요약")
    print("-" * 100)
    
    summary_data = []
    for product in unit_price_pivot.index:
        min_unit_price = unit_price_pivot.loc[product, '최저가']
        min_unit_company = unit_price_pivot.loc[product, '최저가업체']
        min_total_price = total_price_pivot.loc[product, '최저가']
        min_total_company = total_price_pivot.loc[product, '최저가업체']
        
        summary_data.append({
            '품목': product,
            '단가최저가': f"{min_unit_price:,.0f}원",
            '단가최저가업체': min_unit_company,
            '총액최저가': f"{min_total_price:,.0f}원",
            '총액최저가업체': min_total_company
        })
    
    summary_df = pd.DataFrame(summary_data)
    print(summary_df.to_string(index=False))
    
    # 4. 업체별 경쟁력 분석
    print("\n📈 업체별 경쟁력 분석")
    print("-" * 100)
    
    # 각 업체가 최저가를 차지한 품목 수 계산
    unit_wins = unit_price_pivot['최저가업체'].value_counts()
    total_wins = total_price_pivot['최저가업체'].value_counts()
    
    print("단가 최저가 차지 품목 수:")
    for company, count in unit_wins.items():
        print(f"  {company}: {count}개 품목")
    
    print("\n총액 최저가 차지 품목 수:")
    for company, count in total_wins.items():
        print(f"  {company}: {count}개 품목")
    
    # 5. 업체별 총 합계
    print("\n💰 업체별 총 합계")
    print("-" * 100)
    
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values()
    for company, total in company_totals.items():
        print(f"{company}: {total:,.0f}원")
    
    print(f"\n최저가 업체: {company_totals.index[0]} - {company_totals.iloc[0]:,.0f}원")
    
    return unit_price_pivot, total_price_pivot, summary_df

def create_simple_comparison():
    """
    간단한 비교표만 보여주는 함수
    """
    products_df, conditions_df = get_dataframes()
    
    print("\n" + "=" * 100)
    print("간단한 품목별 최저가 비교표")
    print("=" * 100)
    
    # 품목별 최저가 정보만 추출
    comparison_data = []
    
    for product in products_df['품목'].unique():
        product_data = products_df[products_df['품목'] == product]
        
        # 단가 최저가
        min_unit_idx = product_data['단가'].idxmin()
        min_unit_price = product_data.loc[min_unit_idx, '단가']
        min_unit_company = product_data.loc[min_unit_idx, '업체명']
        
        # 총액 최저가
        min_total_idx = product_data['총액'].idxmin()
        min_total_price = product_data.loc[min_total_idx, '총액']
        min_total_company = product_data.loc[min_total_idx, '업체명']
        
        comparison_data.append({
            '품목': product,
            '단가최저가': f"{min_unit_price:,.0f}원",
            '단가최저가업체': min_unit_company,
            '총액최저가': f"{min_total_price:,.0f}원",
            '총액최저가업체': min_total_company
        })
    
    comparison_df = pd.DataFrame(comparison_data)
    print(comparison_df.to_string(index=False))

if __name__ == "__main__":
    # 향상된 PivotTable 생성
    unit_pivot, total_pivot, summary_df = create_enhanced_pivot_tables()
    
    # 간단한 비교표
    create_simple_comparison()
