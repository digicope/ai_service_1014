/**
 * KakaoTalk Theme Client Interaction Script
 * 카카오톡 스타일 UI 및 Fetch API 비동기 통신
 */

document.addEventListener("DOMContentLoaded", () => {
  const chatForm = document.getElementById("chat-form");
  const messageInput = document.getElementById("message-input");
  const sendButton = document.getElementById("send-button");
  const chatMessages = document.getElementById("chat-messages");
  const resetButton = document.getElementById("reset-button");
  const currentDateText = document.getElementById("current-date-text");

  // 오늘 날짜 텍스트 업데이트 (예: 2026년 10월 25일 일요일)
  const updateCurrentDate = () => {
    if (!currentDateText) return;
    const now = new Date();
    const days = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"];
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    const date = now.getDate();
    const dayName = days[now.getDay()];
    currentDateText.textContent = `${year}년 ${month}월 ${date}일 ${dayName}`;
  };
  updateCurrentDate();

  // 현재 시간 포맷팅 함수 (예: "오후 7:15")
  const getFormattedTime = () => {
    const now = new Date();
    let hours = now.getHours();
    const minutes = now.getMinutes();
    const ampm = hours >= 12 ? "오후" : "오전";
    hours = hours % 12;
    hours = hours ? hours : 12; // 0시는 12시로 표기
    const minutesStr = minutes < 10 ? `0${minutes}` : minutes;
    return `${ampm} ${hours}:${minutesStr}`;
  };

  // 메시지 스크롤 맨 아래로 이동
  const scrollToBottom = () => {
    chatMessages.scrollTop = chatMessages.scrollHeight;
  };

  // 전송 버튼 활성화/비활성화 상태 업데이트
  const updateSendButtonState = () => {
    const hasText = messageInput.value.trim().length > 0;
    if (hasText) {
      sendButton.classList.add("active");
    } else {
      sendButton.classList.remove("active");
    }
  };

  // textarea 자동 높이 조절
  messageInput.addEventListener("input", () => {
    messageInput.style.height = "auto";
    const nextHeight = Math.min(messageInput.scrollHeight, 80);
    messageInput.style.height = `${nextHeight}px`;
    updateSendButtonState();
  });

  // 엔터 키 전송 처리 (Shift + Enter는 줄바꿈)
  messageInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (messageInput.value.trim().length > 0 && !sendButton.disabled) {
        chatForm.dispatchEvent(new Event("submit", { cancelable: true }));
      }
    }
  });

  // 메시지 말풍선 추가 함수 (카카오톡 디자인 완벽 구현)
  const appendMessage = (sender, text, isError = false) => {
    const timeStr = getFormattedTime();
    const rowDiv = document.createElement("div");

    if (sender === "You") {
      // 1. 나(사용자) 메시지: 우측 노란색 말풍선 + 시간 + 1(읽음 표시)
      rowDiv.className = "message-row user-row";
      rowDiv.innerHTML = `
        <div class="bubble-wrap">
          <div class="message-bubble user-bubble">${escapeHtml(text)}</div>
          <div class="message-meta">
            <span class="unread-count">1</span>
            <span class="message-time">${timeStr}</span>
          </div>
        </div>
      `;
    } else {
      // 2. 상대방(봇) 메시지: 좌측 프로필 + 이름 + 흰색 말풍선 + 시간
      rowDiv.className = "message-row bot-row";
      const bubbleClass = isError ? "message-bubble error-bubble" : "message-bubble bot-bubble";

      rowDiv.innerHTML = `
        <div class="bot-avatar">
          <svg viewBox="0 0 36 36" width="36" height="36" fill="none">
            <circle cx="18" cy="18" r="18" fill="#FEE500"/>
            <rect x="9" y="11" width="18" height="14" rx="4" fill="#3A1D1D"/>
            <circle cx="14" cy="17" r="2" fill="#FEE500"/>
            <circle cx="22" cy="17" r="2" fill="#FEE500"/>
            <path d="M15 21 Q18 23 21 21" stroke="#FEE500" stroke-width="1.5" stroke-linecap="round" fill="none"/>
            <line x1="18" y1="7" x2="18" y2="11" stroke="#3A1D1D" stroke-width="2" stroke-linecap="round"/>
            <circle cx="18" cy="6" r="1.5" fill="#3A1D1D"/>
          </svg>
        </div>
        <div class="bot-content">
          <div class="sender-name">Bot: Gemini</div>
          <div class="bubble-wrap">
            <div class="${bubbleClass}">${escapeHtml(text)}</div>
            <span class="message-time">${timeStr}</span>
          </div>
        </div>
      `;
    }

    chatMessages.appendChild(rowDiv);
    scrollToBottom();
  };

  // HTML 이스케이프 헬퍼
  function escapeHtml(str) {
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // 봇 입력 중 로딩 말풍선 표시
  const showLoadingIndicator = () => {
    const rowDiv = document.createElement("div");
    rowDiv.className = "message-row bot-row";
    rowDiv.id = "loading-indicator";

    rowDiv.innerHTML = `
      <div class="bot-avatar">
        <svg viewBox="0 0 36 36" width="36" height="36" fill="none">
          <circle cx="18" cy="18" r="18" fill="#FEE500"/>
          <rect x="9" y="11" width="18" height="14" rx="4" fill="#3A1D1D"/>
          <circle cx="14" cy="17" r="2" fill="#FEE500"/>
          <circle cx="22" cy="17" r="2" fill="#FEE500"/>
        </svg>
      </div>
      <div class="bot-content">
        <div class="sender-name">Bot: Gemini</div>
        <div class="bubble-wrap">
          <div class="message-bubble bot-bubble">
            <span class="loading-dots">
              <span></span><span></span><span></span>
            </span>
          </div>
        </div>
      </div>
    `;

    chatMessages.appendChild(rowDiv);
    scrollToBottom();
  };

  const removeLoadingIndicator = () => {
    const indicator = document.getElementById("loading-indicator");
    if (indicator) indicator.remove();
  };

  // 폼 제출 (비동기 Fetch 전송)
  chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const message = messageInput.value.trim();
    if (!message) return;

    // 사용자 메시지 화면 출력
    appendMessage("You", message);
    messageInput.value = "";
    messageInput.style.height = "20px";
    updateSendButtonState();

    messageInput.disabled = true;
    sendButton.disabled = true;

    showLoadingIndicator();

    try {
      const response = await fetch("/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });

      const data = await response.json();
      removeLoadingIndicator();

      if (!response.ok || data.error) {
        appendMessage("Bot", data.error || "메시지 전송 중 오류가 발생했습니다.", true);
      } else {
        appendMessage("Bot", data.reply);
      }
    } catch (err) {
      removeLoadingIndicator();
      console.error("Fetch error:", err);
      appendMessage("Bot", "네트워크 오류가 발생했습니다. 서버 연결 상태를 확인해주세요.", true);
    } finally {
      messageInput.disabled = false;
      sendButton.disabled = false;
      messageInput.focus();
      updateSendButtonState();
    }
  });

  // 대화 리셋 버튼
  if (resetButton) {
    resetButton.addEventListener("click", async () => {
      if (!confirm("대화 히스토리를 초기화하고 새로운 대화를 시작하시겠습니까?")) {
        return;
      }

      try {
        const response = await fetch("/reset", { method: "POST" });
        if (response.ok) {
          const timeStr = getFormattedTime();
          chatMessages.innerHTML = `
            <div class="date-divider">
              <span id="current-date-text"></span>
            </div>
            <div class="message-row bot-row">
              <div class="bot-avatar">
                <svg viewBox="0 0 36 36" width="36" height="36" fill="none">
                  <circle cx="18" cy="18" r="18" fill="#FEE500"/>
                  <rect x="9" y="11" width="18" height="14" rx="4" fill="#3A1D1D"/>
                  <circle cx="14" cy="17" r="2" fill="#FEE500"/>
                  <circle cx="22" cy="17" r="2" fill="#FEE500"/>
                  <path d="M15 21 Q18 23 21 21" stroke="#FEE500" stroke-width="1.5" stroke-linecap="round" fill="none"/>
                  <line x1="18" y1="7" x2="18" y2="11" stroke="#3A1D1D" stroke-width="2" stroke-linecap="round"/>
                  <circle cx="18" cy="6" r="1.5" fill="#3A1D1D"/>
                </svg>
              </div>
              <div class="bot-content">
                <div class="sender-name">Bot: Gemini</div>
                <div class="bubble-wrap">
                  <div class="message-bubble bot-bubble">
                    대화가 초기화되었습니다. 새로운 질문을 자유롭게 입력해주세요!
                  </div>
                  <span class="message-time">${timeStr}</span>
                </div>
              </div>
            </div>
          `;
          updateCurrentDate();
          messageInput.value = "";
          messageInput.style.height = "20px";
          updateSendButtonState();
          messageInput.focus();
        }
      } catch (err) {
        console.error("Reset error:", err);
      }
    });
  }

  // 초기 포커스 및 초기 시간 설정
  const initialTimeEl = document.querySelector(".bot-row .message-time");
  if (initialTimeEl) {
    initialTimeEl.textContent = getFormattedTime();
  }
  messageInput.focus();
});
