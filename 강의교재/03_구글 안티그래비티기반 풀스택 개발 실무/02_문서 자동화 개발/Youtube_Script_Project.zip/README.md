# YouTube AI Analyzer

유튜브 영상의 스크립트를 추출하고 OpenAI API를 사용하여 다양한 형태로 분석하여 자동 저장하는 GUI 앱입니다.

## 주요 기능

- **유튜브 스크립트 추출**: 유튜브 URL을 입력하면 자동으로 스크립트를 추출
- **AI 분석**: OpenAI GPT-4o-mini를 사용한 다양한 분석
  - 전체 요약
  - 핵심 주제 추출
  - 5분 단위 구간별 요약
  - 자주 묻는 질문과 답변 (FAQ)
  - 블로그용 요약 글
- **자동 저장**: 분석 결과를 자동으로 파일로 저장

## 설치 방법

1. 필요한 패키지 설치:
```bash
pip install -r requirements.txt
```

2. OpenAI API 키 설정:
   - `C:/env/.env` 파일을 생성하고 다음 내용을 추가:
   ```
   OPENAI_API_KEY=your_openai_api_key_here
   ```

## 사용 방법

1. 앱 실행:
```bash
python run_analyzer.py
```

2. 유튜브 URL 입력:
   - YouTube URL을 입력 필드에 붙여넣기
   - "스크립트 추출" 버튼 클릭

3. AI 분석:
   - 스크립트 추출 완료 후 "AI 분석 시작" 버튼 클릭
   - 분석이 완료되면 "AI 분석 결과" 탭에서 결과 확인

4. 결과 저장:
   - "모든 결과 저장" 버튼 클릭
   - 저장할 폴더 선택
   - 각 분석 결과가 별도 파일로 저장됨

## 저장되는 파일들

- `{video_id}_summary_{timestamp}.txt`: 전체 요약
- `{video_id}_topics_{timestamp}.txt`: 핵심 주제 추출
- `{video_id}_segments_{timestamp}.txt`: 구간별 요약
- `{video_id}_faq_{timestamp}.txt`: FAQ
- `{video_id}_blog_{timestamp}.txt`: 블로그용 요약 글
- `{video_id}_all_results_{timestamp}.txt`: 모든 결과 통합
- `{video_id}_original_script_{timestamp}.txt`: 원본 스크립트

## 요구사항

- Python 3.7+
- OpenAI API 키
- 인터넷 연결

## 주의사항

- OpenAI API 사용량에 따라 비용이 발생할 수 있습니다
- 유튜브 영상에 자막이 있어야 스크립트를 추출할 수 있습니다
- API 키는 안전하게 보관하세요
