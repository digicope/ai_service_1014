import pandas as pd
from estimate_reader import get_dataframes

def create_company_summary():
    """
    업체별 제품 특장점, 납품 조건, A/S 안내를 한눈에 볼 수 있는 요약표를 생성하는 함수
    """
    # DataFrame 가져오기
    products_df, conditions_df = get_dataframes()
    
    print("=" * 120)
    print("업체별 종합 비교 요약표")
    print("=" * 120)
    
    # 1. 업체별 기본 정보 요약
    print("\n🏢 업체별 기본 정보")
    print("-" * 120)
    
    # 업체별 총 견적액 계산
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values()
    
    # 업체별 제품 수 계산
    company_product_counts = products_df.groupby('업체명')['품목'].count()
    
    # 기본 정보 DataFrame 생성
    basic_info = pd.DataFrame({
        '업체명': company_totals.index,
        '총견적액': [f"{total:,.0f}원" for total in company_totals.values],
        '제품수': company_product_counts.values,
        '순위': range(1, len(company_totals) + 1)
    })
    
    print(basic_info.to_string(index=False))
    
    # 2. 업체별 상세 조건 요약표
    print("\n📋 업체별 상세 조건 요약표")
    print("-" * 120)
    
    # 상세 조건을 보기 좋게 정리
    detailed_summary = []
    
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        company_products = products_df[products_df['업체명'] == company]
        total_amount = company_products['총액'].sum()
        
        # 제품 특장점 정리
        features = row['제품특장점'].replace('제품 특장점: ', '')
        
        # 납품 조건 정리
        delivery = row['납품조건'].replace('납품 조건: ', '')
        
        # A/S 안내 정리
        as_info = row['A/S안내'].replace('A/S 안내: ', '')
        
        detailed_summary.append({
            '업체명': company,
            '총견적액': f"{total_amount:,.0f}원",
            '제품특장점': features,
            '납품조건': delivery,
            'A/S안내': as_info
        })
    
    detailed_df = pd.DataFrame(detailed_summary)
    
    # 컬럼 너비 조정을 위해 각 컬럼별로 출력
    print("업체명\t\t총견적액\t\t제품특장점")
    print("-" * 120)
    for _, row in detailed_df.iterrows():
        print(f"{row['업체명']}\t\t{row['총견적액']}\t\t{row['제품특장점']}")
    
    print("\n업체명\t\t납품조건")
    print("-" * 120)
    for _, row in detailed_df.iterrows():
        print(f"{row['업체명']}\t\t{row['납품조건']}")
    
    print("\n업체명\t\tA/S안내")
    print("-" * 120)
    for _, row in detailed_df.iterrows():
        print(f"{row['업체명']}\t\t{row['A/S안내']}")
    
    # 3. 업체별 상세 분석
    print("\n🔍 업체별 상세 분석")
    print("-" * 120)
    
    for _, row in detailed_df.iterrows():
        company = row['업체명']
        print(f"\n【{company}】")
        print(f"💰 총 견적액: {row['총견적액']}")
        print(f"🎯 제품 특장점: {row['제품특장점']}")
        print(f"🚚 납품 조건: {row['납품조건']}")
        print(f"🔧 A/S 안내: {row['A/S안내']}")
        
        # 해당 업체의 제품 목록
        company_products = products_df[products_df['업체명'] == company]
        print(f"📦 제품 목록:")
        for _, product in company_products.iterrows():
            print(f"   - {product['품목']}: {product['수량']}개 × {product['단가']:,.0f}원 = {product['총액']:,.0f}원")
        print("-" * 80)
    
    # 4. 비교 분석 요약
    print("\n📊 비교 분석 요약")
    print("-" * 120)
    
    print("🏆 가격 경쟁력 순위:")
    for i, (company, total) in enumerate(company_totals.items(), 1):
        print(f"   {i}위: {company} - {total:,.0f}원")
    
    print("\n⚡ 납품 속도 비교:")
    delivery_speed = {
        'A컴퍼니': '5일',
        'B테크': '7일', 
        'C솔루션': '10일'
    }
    for company, days in sorted(delivery_speed.items(), key=lambda x: int(x[1].replace('일', ''))):
        print(f"   {company}: {days}")
    
    print("\n🛡️ A/S 기간 비교:")
    as_period = {
        'A컴퍼니': '2년',
        'B테크': '1년',
        'C솔루션': '3년'
    }
    for company, period in sorted(as_period.items(), key=lambda x: int(x[1].replace('년', '')), reverse=True):
        print(f"   {company}: {period}")
    
    return detailed_df

def create_simple_comparison_table():
    """
    간단한 비교표만 보여주는 함수
    """
    products_df, conditions_df = get_dataframes()
    
    print("\n" + "=" * 120)
    print("간단한 업체별 비교표")
    print("=" * 120)
    
    # 업체별 총 견적액
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values()
    
    # 간단한 비교표 생성
    comparison_data = []
    
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        company_products = products_df[products_df['업체명'] == company]
        total_amount = company_products['총액'].sum()
        
        # 조건 정보 정리
        features = row['제품특장점'].replace('제품 특장점: ', '')
        delivery = row['납품조건'].replace('납품 조건: ', '')
        as_info = row['A/S안내'].replace('A/S 안내: ', '')
        
        comparison_data.append({
            '업체명': company,
            '총견적액': f"{total_amount:,.0f}원",
            '제품특장점': features,
            '납품조건': delivery,
            'A/S안내': as_info
        })
    
    comparison_df = pd.DataFrame(comparison_data)
    
    # 가격 순으로 정렬
    comparison_df['총액_숫자'] = comparison_df['총견적액'].str.replace('원', '').str.replace(',', '').astype(int)
    comparison_df = comparison_df.sort_values('총액_숫자').drop('총액_숫자', axis=1)
    
    print(comparison_df.to_string(index=False))

if __name__ == "__main__":
    # 상세한 업체별 요약표 생성
    detailed_df = create_company_summary()
    
    # 간단한 비교표
    create_simple_comparison_table()
