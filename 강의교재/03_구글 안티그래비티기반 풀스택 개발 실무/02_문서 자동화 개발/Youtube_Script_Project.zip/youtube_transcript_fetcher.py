#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YouTube Transcript Fetcher
유튜브 영상의 자막을 가져오는 스크립트
"""

from youtube_transcript_api import YouTubeTranscriptApi
import re
import sys


def extract_video_id(url):
    """
    유튜브 URL에서 비디오 ID를 추출합니다.
    
    Args:
        url (str): 유튜브 URL
        
    Returns:
        str: 비디오 ID
    """
    # 다양한 유튜브 URL 형식을 지원
    patterns = [
        r'(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)',
        r'youtube\.com\/watch\?.*v=([^&\n?#]+)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    
    return None


def get_transcript(video_id, language_codes=['ko', 'en']):
    """
    유튜브 영상의 자막을 가져옵니다.
    
    Args:
        video_id (str): 유튜브 비디오 ID
        language_codes (list): 우선순위 언어 코드 리스트
        
    Returns:
        list: 자막 데이터 리스트
    """
    try:
        # API 인스턴스 생성
        api = YouTubeTranscriptApi()
        
        # 방법 1: 직접 fetch 시도 (더 간단한 방법)
        for lang_code in language_codes:
            try:
                transcript = api.fetch(video_id, languages=[lang_code])
                return transcript.to_raw_data()
            except:
                continue
        
        # 방법 2: 사용 가능한 자막 언어 확인 후 가져오기
        try:
            transcript_list = api.list(video_id)
            
            # 우선순위 언어로 자막 찾기
            for lang_code in language_codes:
                try:
                    transcript = transcript_list.find_transcript([lang_code])
                    return transcript.to_raw_data()
                except:
                    continue
            
            # 자동 생성 자막 시도
            try:
                transcript = transcript_list.find_generated_transcript(['ko', 'en'])
                return transcript.to_raw_data()
            except:
                pass
            
            # 첫 번째 사용 가능한 자막 사용
            transcript = transcript_list.find_manually_created_transcripts(['ko', 'en'])[0]
            return transcript.to_raw_data()
            
        except Exception as e2:
            print(f"자막 목록 조회 중 오류가 발생했습니다: {e2}")
            return None
        
    except Exception as e:
        print(f"자막을 가져오는 중 오류가 발생했습니다: {e}")
        return None


def format_transcript(transcript_data):
    """
    자막 데이터를 읽기 쉬운 형태로 포맷팅합니다.
    
    Args:
        transcript_data (list): 자막 데이터
        
    Returns:
        str: 포맷팅된 자막 텍스트
    """
    if not transcript_data:
        return "자막을 가져올 수 없습니다."
    
    formatted_text = ""
    for entry in transcript_data:
        start_time = entry['start']
        text = entry['text'].strip()
        
        # 시간을 분:초 형태로 변환
        minutes = int(start_time // 60)
        seconds = int(start_time % 60)
        time_str = f"{minutes:02d}:{seconds:02d}"
        
        formatted_text += f"[{time_str}] {text}\n"
    
    return formatted_text


def save_transcript_to_file(transcript_text, filename="transcript.txt"):
    """
    자막을 파일로 저장합니다.
    
    Args:
        transcript_text (str): 자막 텍스트
        filename (str): 저장할 파일명
    """
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(transcript_text)
        print(f"자막이 '{filename}' 파일로 저장되었습니다.")
    except Exception as e:
        print(f"파일 저장 중 오류가 발생했습니다: {e}")


def main():
    """
    메인 함수
    """
    # 유튜브 URL
    youtube_url = "https://www.youtube.com/watch?v=ZcmYHh1TgVc"
    
    print(f"유튜브 URL: {youtube_url}")
    
    # 비디오 ID 추출
    video_id = extract_video_id(youtube_url)
    if not video_id:
        print("유튜브 URL에서 비디오 ID를 추출할 수 없습니다.")
        sys.exit(1)
    
    print(f"비디오 ID: {video_id}")
    
    # 자막 가져오기
    print("자막을 가져오는 중...")
    transcript_data = get_transcript(video_id)
    
    if transcript_data:
        print("자막을 성공적으로 가져왔습니다!")
        
        # 자막 포맷팅
        formatted_transcript = format_transcript(transcript_data)
        
        # 콘솔에 출력
        print("\n" + "="*50)
        print("자막 내용:")
        print("="*50)
        print(formatted_transcript)
        
        # 파일로 저장
        save_transcript_to_file(formatted_transcript, f"transcript_{video_id}.txt")
        
        # 통계 정보 출력
        print(f"\n총 자막 개수: {len(transcript_data)}개")
        total_duration = transcript_data[-1]['start'] + transcript_data[-1]['duration']
        print(f"총 영상 길이: {int(total_duration // 60)}분 {int(total_duration % 60)}초")
        
    else:
        print("자막을 가져올 수 없습니다. 해당 영상에 자막이 없거나 접근할 수 없습니다.")


if __name__ == "__main__":
    main()
