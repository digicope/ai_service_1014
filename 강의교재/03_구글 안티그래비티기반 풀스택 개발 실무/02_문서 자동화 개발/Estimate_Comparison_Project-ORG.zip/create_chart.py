import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from estimate_reader import get_dataframes
import numpy as np

def create_vendor_totals_chart():
    """
    업체별 총액 합계를 막대그래프로 출력하고 PNG 파일로 저장하는 함수
    """
    # DataFrame 가져오기
    products_df, conditions_df = get_dataframes()
    
    print("=" * 80)
    print("📊 업체별 총액 합계 막대그래프 생성")
    print("=" * 80)
    
    # 업체별 총액 합계 계산
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values(ascending=True)
    
    print("업체별 총액 합계:")
    for company, total in company_totals.items():
        print(f"  {company}: {total:,.0f}원")
    
    # 한글 폰트 설정
    plt.rcParams['font.family'] = 'Malgun Gothic'  # Windows
    plt.rcParams['axes.unicode_minus'] = False
    
    # 그래프 생성
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # 막대그래프 색상 설정
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1']  # 빨강, 청록, 파랑
    
    # 막대그래프 생성
    bars = ax.bar(company_totals.index, company_totals.values, color=colors, alpha=0.8, edgecolor='black', linewidth=1)
    
    # 그래프 제목 및 라벨 설정
    ax.set_title('업체별 총액 합계 비교', fontsize=20, fontweight='bold', pad=20)
    ax.set_xlabel('업체명', fontsize=14, fontweight='bold')
    ax.set_ylabel('총액 (원)', fontsize=14, fontweight='bold')
    
    # Y축 포맷팅 (천 단위 구분)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{x:,.0f}'))
    
    # 막대 위에 값 표시
    for i, (bar, value) in enumerate(zip(bars, company_totals.values)):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                f'{value:,.0f}원', ha='center', va='bottom', fontsize=12, fontweight='bold')
    
    # 그리드 추가
    ax.grid(True, alpha=0.3, axis='y')
    ax.set_axisbelow(True)
    
    # Y축 범위 설정 (여백 추가)
    max_value = company_totals.max()
    ax.set_ylim(0, max_value * 1.15)
    
    # 순위 표시
    for i, (company, total) in enumerate(company_totals.items()):
        rank = i + 1
        ax.text(i, max_value * 0.05, f'{rank}위', ha='center', va='center', 
                fontsize=14, fontweight='bold', color='white',
                bbox=dict(boxstyle='circle', facecolor=colors[i], alpha=0.8))
    
    # 레이아웃 조정
    plt.tight_layout()
    
    # PNG 파일로 저장
    filename = 'totals_by_vendor.png'
    plt.savefig(filename, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"✅ 그래프 저장 완료: {filename}")
    
    # 그래프 표시
    plt.show()
    
    # 통계 정보 출력
    print(f"\n📈 통계 정보:")
    print(f"  최고가: {company_totals.max():,.0f}원 ({company_totals.idxmax()})")
    print(f"  최저가: {company_totals.min():,.0f}원 ({company_totals.idxmin()})")
    print(f"  평균: {company_totals.mean():,.0f}원")
    print(f"  가격 차이: {company_totals.max() - company_totals.min():,.0f}원")
    
    return company_totals

def create_detailed_chart():
    """
    더 상세한 정보를 포함한 막대그래프 생성
    """
    products_df, conditions_df = get_dataframes()
    
    # 업체별 총액 합계 계산
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values(ascending=True)
    
    # 한글 폰트 설정
    plt.rcParams['font.family'] = 'Malgun Gothic'
    plt.rcParams['axes.unicode_minus'] = False
    
    # 서브플롯 생성
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
    
    # 1. 기본 막대그래프
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1']
    bars1 = ax1.bar(company_totals.index, company_totals.values, color=colors, alpha=0.8, edgecolor='black', linewidth=1)
    
    ax1.set_title('업체별 총액 합계', fontsize=16, fontweight='bold')
    ax1.set_xlabel('업체명', fontsize=12)
    ax1.set_ylabel('총액 (원)', fontsize=12)
    ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{x:,.0f}'))
    ax1.grid(True, alpha=0.3, axis='y')
    
    # 값 표시
    for bar, value in zip(bars1, company_totals.values):
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                f'{value:,.0f}원', ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    # 2. 수평 막대그래프
    bars2 = ax2.barh(company_totals.index, company_totals.values, color=colors, alpha=0.8, edgecolor='black', linewidth=1)
    
    ax2.set_title('업체별 총액 합계 (수평)', fontsize=16, fontweight='bold')
    ax2.set_xlabel('총액 (원)', fontsize=12)
    ax2.set_ylabel('업체명', fontsize=12)
    ax2.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{x:,.0f}'))
    ax2.grid(True, alpha=0.3, axis='x')
    
    # 값 표시
    for bar, value in zip(bars2, company_totals.values):
        width = bar.get_width()
        ax2.text(width + width*0.01, bar.get_y() + bar.get_height()/2.,
                f'{value:,.0f}원', ha='left', va='center', fontsize=10, fontweight='bold')
    
    plt.tight_layout()
    
    # PNG 파일로 저장
    filename = 'totals_by_vendor_detailed.png'
    plt.savefig(filename, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"✅ 상세 그래프 저장 완료: {filename}")
    
    plt.show()

def create_pie_chart():
    """
    파이차트로 업체별 비율 표시
    """
    products_df, conditions_df = get_dataframes()
    
    # 업체별 총액 합계 계산
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values(ascending=False)
    
    # 한글 폰트 설정
    plt.rcParams['font.family'] = 'Malgun Gothic'
    plt.rcParams['axes.unicode_minus'] = False
    
    # 파이차트 생성
    fig, ax = plt.subplots(figsize=(10, 8))
    
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1']
    wedges, texts, autotexts = ax.pie(company_totals.values, labels=company_totals.index, 
                                     autopct='%1.1f%%', colors=colors, startangle=90,
                                     textprops={'fontsize': 12, 'fontweight': 'bold'})
    
    # 퍼센트 텍스트 스타일 설정
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontsize(14)
        autotext.set_fontweight('bold')
    
    ax.set_title('업체별 총액 비율', fontsize=18, fontweight='bold', pad=20)
    
    # 범례 추가
    legend_labels = [f'{company}: {total:,.0f}원' for company, total in company_totals.items()]
    ax.legend(wedges, legend_labels, title="업체별 총액", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))
    
    plt.tight_layout()
    
    # PNG 파일로 저장
    filename = 'totals_by_vendor_pie.png'
    plt.savefig(filename, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"✅ 파이차트 저장 완료: {filename}")
    
    plt.show()

if __name__ == "__main__":
    # 기본 막대그래프 생성
    company_totals = create_vendor_totals_chart()
    
    # 상세 그래프 생성
    create_detailed_chart()
    
    # 파이차트 생성
    create_pie_chart()
