"""
Streamlit 기반 멀티모달 AI 에이전트 챗봇 UI
이미지 분석, RAG 검색, 에이전트 도구 실행을 통합한 웹 애플리케이션
"""

import os
import streamlit as st
from dotenv import load_dotenv
from pathlib import Path
from agent.agent_builder import create_agent_instance, run_agent, analyze_image
from agent.rag_store import RAGStore

# 환경 변수 로드
load_dotenv("C:/env/.env")

# 페이지 설정
st.set_page_config(
    page_title="멀티모달 AI 에이전트",
    page_icon="🤖",
    layout="wide"
)

# 세션 상태 초기화
if "agent_executor" not in st.session_state:
    st.session_state.agent_executor = None
if "rag_store" not in st.session_state:
    st.session_state.rag_store = None
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "messages" not in st.session_state:
    st.session_state.messages = []


def initialize_rag_store():
    """RAG 스토어 초기화"""
    if st.session_state.rag_store is None:
        with st.spinner("RAG 스토어를 초기화하는 중..."):
            rag_store = RAGStore(embedding_model="text-embedding-3-small")
            docs_dir = Path("data/samples")
            rag_store.build_vectorstore(str(docs_dir))
            st.session_state.rag_store = rag_store
            st.success("RAG 스토어 초기화 완료!")


def initialize_agent():
    """에이전트 초기화"""
    if st.session_state.agent_executor is None:
        with st.spinner("에이전트를 초기화하는 중..."):
            agent = create_agent_instance(st.session_state.rag_store)
            st.session_state.agent_executor = agent
            st.success("에이전트 초기화 완료!")


# 메인 UI
st.title("🤖 멀티모달 AI 에이전트 챗봇")
st.markdown("이미지 분석, RAG 검색, 문서 요약 등 다양한 기능을 제공하는 AI 에이전트입니다.")

# 사이드바: 초기화 및 설정
with st.sidebar:
    st.header("⚙️ 설정")
    
    # RAG 스토어 초기화 버튼
    if st.button("RAG 스토어 초기화", type="primary"):
        initialize_rag_store()
    
    # 에이전트 초기화 버튼
    if st.button("에이전트 초기화", type="primary"):
        if st.session_state.rag_store is None:
            st.warning("먼저 RAG 스토어를 초기화해주세요.")
        else:
            initialize_agent()
    
    st.divider()
    
    # 상태 표시
    st.subheader("📊 상태")
    rag_status = "✅ 초기화됨" if st.session_state.rag_store else "❌ 미초기화"
    agent_status = "✅ 초기화됨" if st.session_state.agent_executor else "❌ 미초기화"
    
    st.write(f"RAG 스토어: {rag_status}")
    st.write(f"에이전트: {agent_status}")
    
    st.divider()
    
    # 대화 기록 초기화
    if st.button("대화 기록 초기화"):
        st.session_state.chat_history = []
        st.session_state.messages = []
        st.rerun()


# 메인 컨텐츠 영역
tab1, tab2 = st.tabs(["💬 채팅", "🖼️ 이미지 분석"])

with tab1:
    st.header("텍스트 채팅")
    
    # 자동 초기화 (첫 실행 시)
    if st.session_state.rag_store is None:
        initialize_rag_store()
    if st.session_state.agent_executor is None and st.session_state.rag_store:
        initialize_agent()
    
    # 채팅 메시지 표시
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # 사용자 입력
    user_input = st.chat_input("메시지를 입력하세요...")
    
    if user_input:
        # 사용자 메시지 표시
        st.session_state.messages.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.markdown(user_input)
        
        # 에이전트 실행
        if st.session_state.agent_executor:
            with st.chat_message("assistant"):
                with st.spinner("에이전트가 작업을 수행하는 중..."):
                    try:
                        # 에이전트 실행
                        result = run_agent(
                            st.session_state.agent_executor,
                            user_input,
                            st.session_state.chat_history
                        )
                        
                        # 결과 추출 (LangChain v1.0 create_agent는 messages를 반환)
                        if "messages" in result and len(result["messages"]) > 0:
                            # 마지막 메시지가 AIMessage인지 확인
                            last_message = result["messages"][-1]
                            if hasattr(last_message, 'content'):
                                response = last_message.content
                            else:
                                response = str(last_message)
                        else:
                            response = result.get("output", "응답을 생성할 수 없습니다.")
                        
                        # 응답 표시
                        st.markdown(response)
                        
                        # 메시지 기록에 추가
                        st.session_state.messages.append({"role": "assistant", "content": response})
                        
                        # 채팅 히스토리 업데이트
                        st.session_state.chat_history.append({
                            "role": "user",
                            "content": user_input
                        })
                        st.session_state.chat_history.append({
                            "role": "assistant",
                            "content": response
                        })
                        
                    except Exception as e:
                        error_msg = f"오류가 발생했습니다: {str(e)}"
                        st.error(error_msg)
                        st.session_state.messages.append({"role": "assistant", "content": error_msg})
        else:
            st.warning("에이전트가 초기화되지 않았습니다. 사이드바에서 초기화해주세요.")


with tab2:
    st.header("이미지 분석")
    
    # 이미지 업로드
    uploaded_file = st.file_uploader(
        "이미지를 업로드하세요",
        type=["png", "jpg", "jpeg", "gif", "bmp"],
        help="이미지를 업로드하면 AI가 내용을 분석하고 설명을 생성합니다."
    )
    
    if uploaded_file is not None:
        # 이미지 표시
        st.image(uploaded_file, caption="업로드된 이미지")
        
        # 분석 프롬프트 입력
        analysis_prompt = st.text_area(
            "분석 프롬프트 (선택사항)",
            value="이 이미지를 자세히 설명해주세요. 이미지에 있는 객체, 색상, 구성, 의미 등을 포함해서 설명해주세요.",
            height=100
        )
        
        # 분석 버튼
        if st.button("이미지 분석 시작", type="primary"):
            # 임시 파일로 저장
            import tempfile
            with tempfile.NamedTemporaryFile(delete=False, suffix=f".{uploaded_file.name.split('.')[-1]}") as tmp_file:
                tmp_file.write(uploaded_file.getvalue())
                tmp_path = tmp_file.name
            
            try:
                with st.spinner("이미지를 분석하는 중..."):
                    # 이미지 분석 수행
                    analysis_result = analyze_image(tmp_path, analysis_prompt)
                    
                    # 결과 표시
                    st.subheader("📝 분석 결과")
                    st.markdown(analysis_result)
                    
                    # 결과를 채팅 기록에 추가할지 선택
                    if st.button("이 분석 결과를 채팅에 추가"):
                        st.session_state.messages.append({
                            "role": "user",
                            "content": f"[이미지 분석 요청] {analysis_prompt}"
                        })
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": analysis_result
                        })
                        st.success("채팅 기록에 추가되었습니다!")
                        st.rerun()
                        
            except Exception as e:
                st.error(f"이미지 분석 중 오류가 발생했습니다: {str(e)}")
            finally:
                # 임시 파일 삭제
                if os.path.exists(tmp_path):
                    os.unlink(tmp_path)


# 하단 정보
st.divider()
st.markdown("""
### 사용 가능한 기능
- **문서 요약**: `summarize_doc` 도구를 사용하여 텍스트를 요약합니다.
- **키워드 추출**: `extract_keywords` 도구를 사용하여 핵심 키워드를 추출합니다.
- **문서 검색**: `search_docs` 도구를 사용하여 RAG 기반으로 문서를 검색합니다.
- **이미지 분석**: 이미지를 업로드하여 내용을 분석하고 설명을 생성합니다.

### 사용 예시
- "RAG에 대해 검색해줘"
- "인공지능에 대한 문서를 요약해줘"
- "LangChain의 주요 기능을 알려줘"
""")

