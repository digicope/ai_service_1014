import tkinter as tk
from tkinter import ttk, filedialog, scrolledtext
import os
import datetime
from pathlib import Path
import threading
import queue
import csv

class FileOrganizerGUI:
    def __init__(self, root):
        self.root = root
        self.selected_folder = tk.StringVar()
        self.organize_criteria = tk.StringVar(value="extension")  # 기본값: 확장자
        self.date_criteria = tk.StringVar(value="created")  # 기본값: 생성일
        self.progress_queue = queue.Queue()
        self.is_processing = False
        self.setup_window()
        self.create_widgets()
        self.check_queue()
    
    def setup_window(self):
        """창 설정"""
        self.root.title("File Organizer GUI")
        self.root.geometry("600x700")
        self.root.resizable(True, True)
        
        # 창을 화면 중앙에 배치
        self.center_window()
    
    def center_window(self):
        """창을 화면 중앙에 배치"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f"{width}x{height}+{x}+{y}")
    
    def create_widgets(self):
        """GUI 위젯 생성"""
        # 메인 프레임
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 제목 라벨
        title_label = ttk.Label(main_frame, text="File Organizer", 
                               font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        # 설명 라벨
        desc_label = ttk.Label(main_frame, 
                              text="정리할 폴더를 선택하세요.",
                              font=("Arial", 10))
        desc_label.grid(row=1, column=0, columnspan=3, pady=(0, 20))
        
        # 폴더 선택 섹션
        folder_frame = ttk.LabelFrame(main_frame, text="폴더 선택", padding="10")
        folder_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 20))
        
        # 폴더 경로 표시 Entry
        self.folder_entry = ttk.Entry(folder_frame, textvariable=self.selected_folder, 
                                     state="readonly", width=50)
        self.folder_entry.grid(row=0, column=0, padx=(0, 10), sticky=(tk.W, tk.E))
        
        # 폴더 선택 버튼
        select_button = ttk.Button(folder_frame, text="폴더 선택", 
                                  command=self.select_folder)
        select_button.grid(row=0, column=1)
        
        # MyWorkFolder 바로 선택 버튼
        mywork_button = ttk.Button(folder_frame, text="MyWorkFolder 선택", 
                                  command=self.select_mywork_folder)
        mywork_button.grid(row=0, column=2, padx=(10, 0))
        
        # 옵션 섹션
        options_frame = ttk.LabelFrame(main_frame, text="정리 옵션", padding="10")
        options_frame.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 20))
        
        # 정리 기준 옵션
        criteria_frame = ttk.Frame(options_frame)
        criteria_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        ttk.Label(criteria_frame, text="정리 기준:", font=("Arial", 10, "bold")).grid(row=0, column=0, sticky=tk.W)
        
        criteria_options_frame = ttk.Frame(criteria_frame)
        criteria_options_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), padx=(20, 0))
        
        ttk.Radiobutton(criteria_options_frame, text="확장자", 
                       variable=self.organize_criteria, value="extension").grid(row=0, column=0, sticky=tk.W, padx=(0, 20))
        ttk.Radiobutton(criteria_options_frame, text="날짜", 
                       variable=self.organize_criteria, value="date").grid(row=0, column=1, sticky=tk.W, padx=(0, 20))
        ttk.Radiobutton(criteria_options_frame, text="둘 다", 
                       variable=self.organize_criteria, value="both").grid(row=0, column=2, sticky=tk.W)
        
        # 날짜 기준 옵션
        date_frame = ttk.Frame(options_frame)
        date_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E))
        
        ttk.Label(date_frame, text="날짜 기준:", font=("Arial", 10, "bold")).grid(row=0, column=0, sticky=tk.W)
        
        date_options_frame = ttk.Frame(date_frame)
        date_options_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), padx=(20, 0))
        
        ttk.Radiobutton(date_options_frame, text="생성일", 
                       variable=self.date_criteria, value="created").grid(row=0, column=0, sticky=tk.W, padx=(0, 20))
        ttk.Radiobutton(date_options_frame, text="수정일", 
                       variable=self.date_criteria, value="modified").grid(row=0, column=1, sticky=tk.W)
        
        # 선택된 옵션 미리보기
        preview_frame = ttk.LabelFrame(main_frame, text="선택된 옵션", padding="10")
        preview_frame.grid(row=4, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 20))
        
        self.preview_label = ttk.Label(preview_frame, text="", font=("Arial", 9))
        self.preview_label.grid(row=0, column=0, sticky=tk.W)
        
        # 옵션 변경 시 미리보기 업데이트
        self.organize_criteria.trace('w', self.update_preview)
        self.date_criteria.trace('w', self.update_preview)
        self.update_preview()  # 초기 미리보기 설정
        
        # 버튼 프레임
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=5, column=0, columnspan=3, pady=(10, 10))
        
        # 미리보기 버튼
        preview_button = ttk.Button(button_frame, text="미리보기", 
                                   command=self.show_preview)
        preview_button.grid(row=0, column=0, padx=(0, 10))
        
        # 실행 버튼
        self.execute_button = ttk.Button(button_frame, text="실행", 
                                        command=self.execute_organization)
        self.execute_button.grid(row=0, column=1, padx=(0, 10))
        
        # 되돌리기 버튼
        self.undo_button = ttk.Button(button_frame, text="되돌리기", 
                                     command=self.undo_organization)
        self.undo_button.grid(row=0, column=2, padx=(0, 10))
        
        # 검색 버튼
        search_button = ttk.Button(button_frame, text="검색", 
                                  command=self.show_search_dialog)
        search_button.grid(row=0, column=3)
        
        # 진행률 표시 프레임
        progress_frame = ttk.Frame(main_frame)
        progress_frame.grid(row=6, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(5, 10))
        
        # 진행률 라벨
        self.progress_label = ttk.Label(progress_frame, text="")
        self.progress_label.grid(row=0, column=0, sticky=tk.W)
        
        # 진행률 바
        self.progress_bar = ttk.Progressbar(progress_frame, mode='determinate')
        self.progress_bar.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(5, 0))
        
        progress_frame.columnconfigure(0, weight=1)
        
        # 미리보기 결과 텍스트 영역
        result_frame = ttk.LabelFrame(main_frame, text="미리보기 결과", padding="10")
        result_frame.grid(row=8, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        self.result_text = scrolledtext.ScrolledText(result_frame, height=12, width=70, 
                                                    font=("Consolas", 9))
        self.result_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 그리드 가중치 설정
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.columnconfigure(2, weight=1)
        folder_frame.columnconfigure(0, weight=1)
        options_frame.columnconfigure(0, weight=1)
        options_frame.columnconfigure(1, weight=1)
        result_frame.columnconfigure(0, weight=1)
        result_frame.rowconfigure(0, weight=1)
        main_frame.rowconfigure(8, weight=1)
    
    def select_folder(self):
        """폴더 선택 다이얼로그"""
        folder_path = filedialog.askdirectory(
            title="정리할 폴더를 선택하세요",
            initialdir=os.getcwd()
        )
        if folder_path:
            self.selected_folder.set(folder_path)
    
    def select_mywork_folder(self):
        """MyWorkFolder 직접 선택"""
        mywork_path = os.path.join(os.getcwd(), "MyWorkFolder")
        if os.path.exists(mywork_path):
            self.selected_folder.set(mywork_path)
        else:
            # MyWorkFolder가 없으면 생성
            os.makedirs(mywork_path, exist_ok=True)
            self.selected_folder.set(mywork_path)
    
    def update_preview(self, *args):
        """선택된 옵션 미리보기 업데이트"""
        organize = self.organize_criteria.get()
        date_criteria = self.date_criteria.get()
        
        # 정리 기준 텍스트 변환
        organize_text = {
            "extension": "확장자",
            "date": "날짜", 
            "both": "확장자 + 날짜"
        }.get(organize, "확장자")
        
        # 날짜 기준 텍스트 변환
        date_text = {
            "created": "생성일",
            "modified": "수정일"
        }.get(date_criteria, "생성일")
        
        # 미리보기 텍스트 생성
        if organize == "extension":
            preview_text = f"정리 기준: {organize_text}"
        elif organize == "date":
            preview_text = f"정리 기준: {organize_text} ({date_text})"
        else:  # both
            preview_text = f"정리 기준: {organize_text} (날짜 기준: {date_text})"
        
        self.preview_label.config(text=preview_text)
    
    def get_selected_options(self):
        """선택된 옵션 반환"""
        return {
            "folder_path": self.selected_folder.get(),
            "organize_criteria": self.organize_criteria.get(),
            "date_criteria": self.date_criteria.get()
        }
    
    def get_extension_category(self, extension):
        """확장자를 카테고리로 분류"""
        extension = extension.lower()
        
        image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tiff', 'webp', 'svg']
        doc_extensions = ['doc', 'docx', 'pdf', 'txt', 'rtf', 'odt', 'hwp']
        presentation_extensions = ['ppt', 'pptx', 'odp']
        spreadsheet_extensions = ['xls', 'xlsx', 'csv', 'ods']
        archive_extensions = ['zip', 'rar', '7z', 'tar', 'gz', 'bz2']
        audio_extensions = ['mp3', 'wav', 'flac', 'aac', 'ogg', 'wma']
        video_extensions = ['mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'webm']
        code_extensions = ['py', 'js', 'html', 'css', 'java', 'cpp', 'c', 'php', 'rb']
        executable_extensions = ['exe', 'msi', 'app', 'deb', 'rpm']
        
        if extension in image_extensions:
            return "Images"
        elif extension in doc_extensions:
            return "Docs"
        elif extension in presentation_extensions:
            return "Presentations"
        elif extension in spreadsheet_extensions:
            return "Spreadsheets"
        elif extension in archive_extensions:
            return "Archives"
        elif extension in audio_extensions:
            return "Audio"
        elif extension in video_extensions:
            return "Videos"
        elif extension in code_extensions:
            return "Code"
        elif extension in executable_extensions:
            return "Executables"
        else:
            return "Others"
    
    def scan_files(self, folder_path):
        """폴더 내 파일들을 스캔"""
        if not os.path.exists(folder_path):
            return []
        
        files = []
        for item in os.listdir(folder_path):
            item_path = os.path.join(folder_path, item)
            if os.path.isfile(item_path):
                stat = os.stat(item_path)
                files.append({
                    'name': item,
                    'path': item_path,
                    'extension': os.path.splitext(item)[1][1:].lower(),
                    'created': datetime.datetime.fromtimestamp(stat.st_ctime),
                    'modified': datetime.datetime.fromtimestamp(stat.st_mtime)
                })
        return files
    
    def generate_organization_plan(self, files, organize_criteria, date_criteria):
        """파일 정리 계획 생성"""
        plan = []
        
        if organize_criteria == "extension":
            # 확장자별 정리
            categories = {}
            for file in files:
                category = self.get_extension_category(file['extension'])
                if category not in categories:
                    categories[category] = []
                categories[category].append(file)
            
            for category, file_list in categories.items():
                plan.append(f"\n=== {category} 폴더 ===")
                for file in file_list:
                    plan.append(f"  {file['name']}")
                plan.append(f"  총 {len(file_list)}개 파일")
        
        elif organize_criteria == "date":
            # 날짜별 정리
            date_groups = {}
            for file in files:
                if date_criteria == "created":
                    date = file['created']
                else:
                    date = file['modified']
                
                date_key = date.strftime("%Y_%m")
                if date_key not in date_groups:
                    date_groups[date_key] = []
                date_groups[date_key].append(file)
            
            for date_key, file_list in sorted(date_groups.items()):
                plan.append(f"\n=== {date_key} 폴더 ===")
                for file in file_list:
                    plan.append(f"  {file['name']}")
                plan.append(f"  총 {len(file_list)}개 파일")
        
        else:  # both
            # 확장자 + 날짜별 정리
            categories = {}
            for file in files:
                category = self.get_extension_category(file['extension'])
                if category not in categories:
                    categories[category] = {}
                
                if date_criteria == "created":
                    date = file['created']
                else:
                    date = file['modified']
                
                date_key = date.strftime("%Y_%m")
                if date_key not in categories[category]:
                    categories[category][date_key] = []
                categories[category][date_key].append(file)
            
            for category, date_groups in categories.items():
                plan.append(f"\n=== {category} 폴더 ===")
                for date_key, file_list in sorted(date_groups.items()):
                    plan.append(f"  └─ {date_key} 폴더")
                    for file in file_list:
                        plan.append(f"    {file['name']}")
                    plan.append(f"    총 {len(file_list)}개 파일")
        
        return plan
    
    def show_preview(self):
        """미리보기 결과 표시"""
        folder_path = self.selected_folder.get()
        if not folder_path:
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "폴더를 먼저 선택해주세요.")
            return
        
        # 텍스트 영역 초기화
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, "파일 스캔 중...\n")
        self.root.update()
        
        # 파일 스캔
        files = self.scan_files(folder_path)
        
        if not files:
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, f"'{folder_path}' 폴더에 파일이 없습니다.")
            return
        
        # 정리 계획 생성
        organize_criteria = self.organize_criteria.get()
        date_criteria = self.date_criteria.get()
        
        # 헤더 정보
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, f"📁 폴더: {folder_path}\n")
        self.result_text.insert(tk.END, f"📊 총 파일 수: {len(files)}개\n")
        self.result_text.insert(tk.END, f"🔧 정리 기준: {self.preview_label.cget('text')}\n")
        self.result_text.insert(tk.END, "=" * 60 + "\n")
        
        # 정리 계획 표시
        plan = self.generate_organization_plan(files, organize_criteria, date_criteria)
        for line in plan:
            self.result_text.insert(tk.END, line + "\n")
    
    def get_unique_filename(self, target_path):
        """중복 파일명 처리 - _1, _2 형식으로 자동 변경"""
        if not os.path.exists(target_path):
            return target_path
        
        base_path = os.path.splitext(target_path)
        counter = 1
        
        while True:
            new_path = f"{base_path[0]}_{counter}{base_path[1]}"
            if not os.path.exists(new_path):
                return new_path
            counter += 1
    
    def log_operation(self, message):
        """로그 파일에 작업 내역 기록"""
        log_file = "organizer_log.txt"
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] {message}\n")
    
    def save_to_manifest(self, original_path, new_path, operation_type="move"):
        """manifest.csv에 파일 이동 내역 저장"""
        manifest_file = "manifest.csv"
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # CSV 파일이 없으면 헤더 생성
        file_exists = os.path.exists(manifest_file)
        
        with open(manifest_file, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            
            # 헤더가 없으면 추가
            if not file_exists:
                writer.writerow(["timestamp", "operation", "original_path", "new_path"])
            
            # 데이터 추가
            writer.writerow([timestamp, operation_type, original_path, new_path])
    
    def load_manifest(self):
        """manifest.csv에서 파일 이동 내역 로드"""
        manifest_file = "manifest.csv"
        
        if not os.path.exists(manifest_file):
            return []
        
        movements = []
        with open(manifest_file, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                movements.append({
                    'timestamp': row['timestamp'],
                    'operation': row['operation'],
                    'original_path': row['original_path'],
                    'new_path': row['new_path']
                })
        
        return movements
    
    def execute_organization(self):
        """파일 정리 실행"""
        if self.is_processing:
            return
        
        folder_path = self.selected_folder.get()
        if not folder_path:
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "폴더를 먼저 선택해주세요.")
            return
        
        # 확인 대화상자
        import tkinter.messagebox as msgbox
        result = msgbox.askyesno("확인", "파일 정리를 실행하시겠습니까?\n이 작업은 되돌릴 수 없습니다.")
        if not result:
            return
        
        # 처리 중 상태로 변경
        self.is_processing = True
        self.execute_button.config(text="처리 중...", state="disabled")
        self.progress_bar['value'] = 0
        self.progress_label.config(text="준비 중...")
        
        # 정리 계획 생성
        organize_criteria = self.organize_criteria.get()
        date_criteria = self.date_criteria.get()
        
        # 스레드에서 파일 정리 실행
        thread = threading.Thread(
            target=self.execute_organization_threaded,
            args=(folder_path, organize_criteria, date_criteria),
            daemon=True
        )
        thread.start()
    
    def check_queue(self):
        """큐에서 메시지를 확인하고 GUI 업데이트"""
        try:
            while True:
                message = self.progress_queue.get_nowait()
                if message['type'] == 'progress':
                    self.progress_bar['value'] = message['value']
                    self.progress_label.config(text=message['text'])
                elif message['type'] == 'update_text':
                    self.result_text.insert(tk.END, message['text'])
                elif message['type'] == 'clear_text':
                    self.result_text.delete(1.0, tk.END)
                elif message['type'] == 'complete':
                    self.is_processing = False
                    self.execute_button.config(text="실행", state="normal")
                    self.undo_button.config(text="되돌리기", state="normal")
                    self.progress_bar['value'] = 100
                    self.progress_label.config(text="완료!")
                elif message['type'] == 'error':
                    self.is_processing = False
                    self.execute_button.config(text="실행", state="normal")
                    self.undo_button.config(text="되돌리기", state="normal")
                    self.progress_label.config(text="오류 발생")
        except queue.Empty:
            pass
        
        # 100ms 후에 다시 확인
        self.root.after(100, self.check_queue)
    
    def update_progress(self, value, text=""):
        """진행률 업데이트 (스레드에서 호출)"""
        self.progress_queue.put({'type': 'progress', 'value': value, 'text': text})
    
    def update_text(self, text):
        """텍스트 영역 업데이트 (스레드에서 호출)"""
        self.progress_queue.put({'type': 'update_text', 'text': text})
    
    def clear_text(self):
        """텍스트 영역 초기화 (스레드에서 호출)"""
        self.progress_queue.put({'type': 'clear_text'})
    
    def complete_operation(self):
        """작업 완료 처리 (스레드에서 호출)"""
        self.progress_queue.put({'type': 'complete'})
    
    def error_operation(self):
        """오류 처리 (스레드에서 호출)"""
        self.progress_queue.put({'type': 'error'})
    
    def execute_organization_threaded(self, folder_path, organize_criteria, date_criteria):
        """스레드에서 실행되는 파일 정리 작업"""
        try:
            # 로그 파일 초기화
            self.log_operation("=" * 50)
            self.log_operation("파일 정리 시작")
            self.log_operation(f"대상 폴더: {folder_path}")
            
            # 파일 스캔
            files = self.scan_files(folder_path)
            
            if not files:
                self.clear_text()
                self.update_text(f"'{folder_path}' 폴더에 파일이 없습니다.")
                self.complete_operation()
                return
            
            total_files = len(files)
            moved_count = 0
            error_count = 0
            
            self.clear_text()
            self.update_text("파일 정리 실행 중...\n")
            self.update_progress(0, f"0/{total_files} 파일 처리 중...")
            
            if organize_criteria == "extension":
                # 확장자별 정리
                categories = {}
                for file in files:
                    category = self.get_extension_category(file['extension'])
                    if category not in categories:
                        categories[category] = []
                    categories[category].append(file)
                
                processed = 0
                for category, file_list in categories.items():
                    category_folder = os.path.join(folder_path, category)
                    os.makedirs(category_folder, exist_ok=True)
                    
                    for file in file_list:
                        source_path = file['path']
                        target_path = os.path.join(category_folder, file['name'])
                        target_path = self.get_unique_filename(target_path)
                        
                        try:
                            os.rename(source_path, target_path)
                            moved_count += 1
                            self.save_to_manifest(source_path, target_path, "move")
                            self.log_operation(f"이동: {file['name']} → {category}/{os.path.basename(target_path)}")
                        except Exception as e:
                            error_count += 1
                            self.log_operation(f"오류: {file['name']} - {str(e)}")
                        
                        processed += 1
                        progress = (processed / total_files) * 100
                        self.update_progress(progress, f"{processed}/{total_files} 파일 처리 중...")
            
            elif organize_criteria == "date":
                # 날짜별 정리
                date_groups = {}
                for file in files:
                    if date_criteria == "created":
                        date = file['created']
                    else:
                        date = file['modified']
                    
                    date_key = date.strftime("%Y_%m")
                    if date_key not in date_groups:
                        date_groups[date_key] = []
                    date_groups[date_key].append(file)
                
                processed = 0
                for date_key, file_list in date_groups.items():
                    date_folder = os.path.join(folder_path, date_key)
                    os.makedirs(date_folder, exist_ok=True)
                    
                    for file in file_list:
                        source_path = file['path']
                        target_path = os.path.join(date_folder, file['name'])
                        target_path = self.get_unique_filename(target_path)
                        
                        try:
                            os.rename(source_path, target_path)
                            moved_count += 1
                            self.save_to_manifest(source_path, target_path, "move")
                            self.log_operation(f"이동: {file['name']} → {date_key}/{os.path.basename(target_path)}")
                        except Exception as e:
                            error_count += 1
                            self.log_operation(f"오류: {file['name']} - {str(e)}")
                        
                        processed += 1
                        progress = (processed / total_files) * 100
                        self.update_progress(progress, f"{processed}/{total_files} 파일 처리 중...")
            
            else:  # both
                # 확장자 + 날짜별 정리
                categories = {}
                for file in files:
                    category = self.get_extension_category(file['extension'])
                    if category not in categories:
                        categories[category] = {}
                    
                    if date_criteria == "created":
                        date = file['created']
                    else:
                        date = file['modified']
                    
                    date_key = date.strftime("%Y_%m")
                    if date_key not in categories[category]:
                        categories[category][date_key] = []
                    categories[category][date_key].append(file)
                
                processed = 0
                for category, date_groups in categories.items():
                    category_folder = os.path.join(folder_path, category)
                    os.makedirs(category_folder, exist_ok=True)
                    
                    for date_key, file_list in date_groups.items():
                        date_folder = os.path.join(category_folder, date_key)
                        os.makedirs(date_folder, exist_ok=True)
                        
                        for file in file_list:
                            source_path = file['path']
                            target_path = os.path.join(date_folder, file['name'])
                            target_path = self.get_unique_filename(target_path)
                            
                            try:
                                os.rename(source_path, target_path)
                                moved_count += 1
                                self.save_to_manifest(source_path, target_path, "move")
                                self.log_operation(f"이동: {file['name']} → {category}/{date_key}/{os.path.basename(target_path)}")
                            except Exception as e:
                                error_count += 1
                                self.log_operation(f"오류: {file['name']} - {str(e)}")
                            
                            processed += 1
                            progress = (processed / total_files) * 100
                            self.update_progress(progress, f"{processed}/{total_files} 파일 처리 중...")
            
            # 결과 표시
            self.clear_text()
            self.update_text(f"✅ 파일 정리 완료!\n\n")
            self.update_text(f"📊 처리 결과:\n")
            self.update_text(f"  • 성공적으로 이동된 파일: {moved_count}개\n")
            self.update_text(f"  • 오류 발생: {error_count}개\n")
            self.update_text(f"  • 총 파일 수: {total_files}개\n\n")
            self.update_text(f"📝 상세 내역은 organizer_log.txt 파일을 확인하세요.\n")
            
            # 로그 기록
            self.log_operation(f"정리 완료 - 성공: {moved_count}개, 오류: {error_count}개")
            self.log_operation("=" * 50)
            
            self.complete_operation()
            
        except Exception as e:
            self.clear_text()
            self.update_text(f"❌ 오류 발생: {str(e)}")
            self.log_operation(f"치명적 오류: {str(e)}")
            self.error_operation()
    
    def undo_organization(self):
        """파일 정리 되돌리기"""
        if self.is_processing:
            return
        
        # manifest.csv 파일 확인
        movements = self.load_manifest()
        if not movements:
            import tkinter.messagebox as msgbox
            msgbox.showinfo("알림", "되돌릴 파일 이동 내역이 없습니다.")
            return
        
        # 확인 대화상자
        import tkinter.messagebox as msgbox
        result = msgbox.askyesno("확인", f"최근 {len(movements)}개의 파일 이동을 되돌리시겠습니까?\n파일들이 원래 위치로 복원됩니다.")
        if not result:
            return
        
        # 처리 중 상태로 변경
        self.is_processing = True
        self.undo_button.config(text="되돌리는 중...", state="disabled")
        self.progress_bar['value'] = 0
        self.progress_label.config(text="준비 중...")
        
        # 스레드에서 되돌리기 실행
        thread = threading.Thread(
            target=self.undo_organization_threaded,
            args=(movements,),
            daemon=True
        )
        thread.start()
    
    def undo_organization_threaded(self, movements):
        """스레드에서 실행되는 되돌리기 작업"""
        try:
            self.clear_text()
            self.update_text("파일 되돌리기 실행 중...\n")
            self.update_progress(0, f"0/{len(movements)} 파일 되돌리는 중...")
            
            restored_count = 0
            error_count = 0
            
            # 최신 이동 내역부터 역순으로 처리
            for i, movement in enumerate(reversed(movements)):
                try:
                    original_path = movement['original_path']
                    new_path = movement['new_path']
                    
                    # 파일이 존재하는지 확인
                    if os.path.exists(new_path):
                        # 원본 위치에 이미 파일이 있는지 확인
                        if os.path.exists(original_path):
                            # 중복 파일명 처리
                            original_path = self.get_unique_filename(original_path)
                        
                        # 파일 이동
                        os.rename(new_path, original_path)
                        restored_count += 1
                        
                        # 되돌리기 내역을 manifest에 기록
                        self.save_to_manifest(new_path, original_path, "undo")
                        self.log_operation(f"되돌리기: {os.path.basename(new_path)} → {os.path.basename(original_path)}")
                    else:
                        error_count += 1
                        self.log_operation(f"오류: {new_path} 파일을 찾을 수 없습니다.")
                    
                    # 진행률 업데이트
                    progress = ((i + 1) / len(movements)) * 100
                    self.update_progress(progress, f"{i + 1}/{len(movements)} 파일 되돌리는 중...")
                    
                except Exception as e:
                    error_count += 1
                    self.log_operation(f"오류: {movement['new_path']} - {str(e)}")
            
            # 결과 표시
            self.clear_text()
            self.update_text(f"✅ 파일 되돌리기 완료!\n\n")
            self.update_text(f"📊 처리 결과:\n")
            self.update_text(f"  • 성공적으로 복원된 파일: {restored_count}개\n")
            self.update_text(f"  • 오류 발생: {error_count}개\n")
            self.update_text(f"  • 총 처리 파일 수: {len(movements)}개\n\n")
            self.update_text(f"📝 상세 내역은 organizer_log.txt 파일을 확인하세요.\n")
            
            # 로그 기록
            self.log_operation(f"되돌리기 완료 - 성공: {restored_count}개, 오류: {error_count}개")
            self.log_operation("=" * 50)
            
            self.complete_operation()
            
        except Exception as e:
            self.clear_text()
            self.update_text(f"❌ 오류 발생: {str(e)}")
            self.log_operation(f"되돌리기 치명적 오류: {str(e)}")
            self.error_operation()
    
    def show_search_dialog(self):
        """검색 대화상자 표시"""
        folder_path = self.selected_folder.get()
        if not folder_path:
            import tkinter.messagebox as msgbox
            msgbox.showwarning("경고", "먼저 폴더를 선택해주세요.")
            return
        
        # 검색 대화상자 생성
        search_dialog = tk.Toplevel(self.root)
        search_dialog.title("파일 검색")
        search_dialog.geometry("500x400")
        search_dialog.resizable(False, False)
        search_dialog.transient(self.root)
        search_dialog.grab_set()
        
        # 중앙 배치
        search_dialog.update_idletasks()
        x = (search_dialog.winfo_screenwidth() // 2) - (500 // 2)
        y = (search_dialog.winfo_screenheight() // 2) - (400 // 2)
        search_dialog.geometry(f"500x400+{x}+{y}")
        
        # 메인 프레임
        main_frame = ttk.Frame(search_dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 제목
        title_label = ttk.Label(main_frame, text="파일 검색", font=("Arial", 14, "bold"))
        title_label.pack(pady=(0, 20))
        
        # 검색 조건 프레임
        criteria_frame = ttk.LabelFrame(main_frame, text="검색 조건", padding="10")
        criteria_frame.pack(fill=tk.X, pady=(0, 20))
        
        # 파일명 검색
        ttk.Label(criteria_frame, text="파일명 (부분 일치):").grid(row=0, column=0, sticky=tk.W, pady=(0, 5))
        filename_var = tk.StringVar()
        filename_entry = ttk.Entry(criteria_frame, textvariable=filename_var, width=40)
        filename_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=(0, 5))
        
        # 확장자 검색
        ttk.Label(criteria_frame, text="확장자:").grid(row=1, column=0, sticky=tk.W, pady=(0, 5))
        extension_var = tk.StringVar()
        extension_entry = ttk.Entry(criteria_frame, textvariable=extension_var, width=40)
        extension_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=(0, 5))
        
        # 날짜 범위 검색
        ttk.Label(criteria_frame, text="수정일 범위:").grid(row=2, column=0, sticky=tk.W, pady=(0, 5))
        date_frame = ttk.Frame(criteria_frame)
        date_frame.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=(0, 5))
        
        from_date_var = tk.StringVar()
        to_date_var = tk.StringVar()
        
        ttk.Label(date_frame, text="부터:").grid(row=0, column=0, sticky=tk.W)
        from_date_entry = ttk.Entry(date_frame, textvariable=from_date_var, width=12)
        from_date_entry.grid(row=0, column=1, padx=(5, 10))
        
        ttk.Label(date_frame, text="까지:").grid(row=0, column=2, sticky=tk.W)
        to_date_entry = ttk.Entry(date_frame, textvariable=to_date_var, width=12)
        to_date_entry.grid(row=0, column=3, padx=(5, 0))
        
        # 날짜 형식 도움말
        ttk.Label(criteria_frame, text="날짜 형식: YYYY-MM-DD (예: 2024-01-15)", 
                 font=("Arial", 8)).grid(row=3, column=1, sticky=tk.W, pady=(5, 0))
        
        criteria_frame.columnconfigure(1, weight=1)
        
        # 버튼 프레임
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(0, 20))
        
        def perform_search():
            """검색 실행"""
            filename = filename_var.get().strip()
            extension = extension_var.get().strip()
            from_date = from_date_var.get().strip()
            to_date = to_date_var.get().strip()
            
            # 검색 실행
            results = self.search_files(folder_path, filename, extension, from_date, to_date)
            
            # 결과 표시
            self.display_search_results(results)
            search_dialog.destroy()
        
        def clear_search():
            """검색 조건 초기화"""
            filename_var.set("")
            extension_var.set("")
            from_date_var.set("")
            to_date_var.set("")
        
        # 버튼들
        ttk.Button(button_frame, text="검색", command=perform_search).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="초기화", command=clear_search).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="취소", command=search_dialog.destroy).pack(side=tk.LEFT)
    
    def search_files(self, folder_path, filename="", extension="", from_date="", to_date=""):
        """파일 검색 실행"""
        results = []
        
        if not os.path.exists(folder_path):
            return results
        
        # 날짜 파싱
        from_datetime = None
        to_datetime = None
        
        if from_date:
            try:
                from_datetime = datetime.datetime.strptime(from_date, "%Y-%m-%d")
            except ValueError:
                pass
        
        if to_date:
            try:
                to_datetime = datetime.datetime.strptime(to_date, "%Y-%m-%d")
                # 하루 끝까지 포함
                to_datetime = to_datetime.replace(hour=23, minute=59, second=59)
            except ValueError:
                pass
        
        # 파일 스캔
        for item in os.listdir(folder_path):
            item_path = os.path.join(folder_path, item)
            if os.path.isfile(item_path):
                # 파일명 검색
                if filename and filename.lower() not in item.lower():
                    continue
                
                # 확장자 검색
                file_extension = os.path.splitext(item)[1][1:].lower()
                if extension and extension.lower() != file_extension:
                    continue
                
                # 날짜 범위 검색
                if from_datetime or to_datetime:
                    stat = os.stat(item_path)
                    modified_time = datetime.datetime.fromtimestamp(stat.st_mtime)
                    
                    if from_datetime and modified_time < from_datetime:
                        continue
                    if to_datetime and modified_time > to_datetime:
                        continue
                
                # 결과에 추가
                stat = os.stat(item_path)
                results.append({
                    'name': item,
                    'path': item_path,
                    'extension': file_extension,
                    'size': stat.st_size,
                    'modified': datetime.datetime.fromtimestamp(stat.st_mtime),
                    'created': datetime.datetime.fromtimestamp(stat.st_ctime)
                })
        
        # 수정일 기준으로 정렬
        results.sort(key=lambda x: x['modified'], reverse=True)
        return results
    
    def display_search_results(self, results):
        """검색 결과 표시"""
        self.clear_text()
        
        if not results:
            self.update_text("검색 결과가 없습니다.")
            return
        
        # 헤더 정보
        self.update_text(f"🔍 검색 결과: {len(results)}개 파일 발견\n")
        self.update_text("=" * 80 + "\n\n")
        
        # 결과 표시
        for i, file_info in enumerate(results, 1):
            size_kb = file_info['size'] / 1024
            modified_str = file_info['modified'].strftime("%Y-%m-%d %H:%M:%S")
            
            self.update_text(f"{i:3d}. {file_info['name']}\n")
            self.update_text(f"     📁 경로: {file_info['path']}\n")
            self.update_text(f"     📄 확장자: {file_info['extension'] or '(확장자 없음)'}\n")
            self.update_text(f"     📊 크기: {size_kb:.1f} KB\n")
            self.update_text(f"     📅 수정일: {modified_str}\n")
            self.update_text(f"     🕒 생성일: {file_info['created'].strftime('%Y-%m-%d %H:%M:%S')}\n")
            self.update_text("-" * 80 + "\n")

def main():
    """메인 함수"""
    root = tk.Tk()
    app = FileOrganizerGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
