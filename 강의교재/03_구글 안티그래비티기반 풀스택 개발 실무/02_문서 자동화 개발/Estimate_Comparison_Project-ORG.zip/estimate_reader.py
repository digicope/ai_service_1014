import pandas as pd
import os
import glob

def read_estimate_files():
    """
    현재 폴더의 모든 견적서 엑셀 파일을 읽어서 두 개의 DataFrame으로 변환하는 함수
    Returns:
        products_df: 제품 정보 DataFrame (업체명, 품목, 수량, 단가, 총액)
        conditions_df: 업체별 상세 조건 DataFrame (업체명, 제품특장점, 납품조건, A/S안내)
    """
    # 현재 폴더의 모든 엑셀 파일 찾기
    excel_files = glob.glob("*.xlsx")
    
    all_products = []
    all_conditions = []
    
    for file in excel_files:
        try:
            # 엑셀 파일 읽기
            df = pd.read_excel(file)
            
            # 업체명 추출 (2행, 1열)
            company_name = df.iloc[2, 0] if pd.notna(df.iloc[2, 0]) else "알 수 없음"
            
            # 제품 정보 추출 (12-14행)
            for i in range(12, 15):  # 12, 13, 14행
                if i < len(df) and pd.notna(df.iloc[i, 0]) and pd.notna(df.iloc[i, 1]):
                    quantity = df.iloc[i, 0]
                    product_name = df.iloc[i, 1]
                    unit_price = df.iloc[i, 2]
                    total_price = df.iloc[i, 3]
                    
                    all_products.append({
                        '업체명': company_name,
                        '품목': product_name,
                        '수량': quantity,
                        '단가': unit_price,
                        '총액': total_price
                    })
            
            # 제품 특장점, 납품 조건, A/S 안내 추출 (28-30행)
            features = ""
            delivery = ""
            as_info = ""
            
            for i in range(28, 31):  # 28, 29, 30행
                if i < len(df):
                    row_data = df.iloc[i, 0]
                    if pd.notna(row_data):
                        if i == 28:  # 제품 특장점
                            features = str(row_data)
                        elif i == 29:  # 납품 조건
                            delivery = str(row_data)
                        elif i == 30:  # A/S 안내
                            as_info = str(row_data)
            
            # 업체별 상세 조건 정보 저장
            all_conditions.append({
                '업체명': company_name,
                '제품특장점': features,
                '납품조건': delivery,
                'A/S안내': as_info
            })
            
        except Exception as e:
            print(f"파일 {file} 읽기 중 오류 발생: {e}")
    
    # DataFrame 생성
    products_df = pd.DataFrame(all_products)
    conditions_df = pd.DataFrame(all_conditions)
    
    return products_df, conditions_df

def display_results():
    """
    결과를 보기 좋게 출력하는 함수
    """
    # 데이터 읽기
    products_df, conditions_df = read_estimate_files()
    
    if products_df.empty:
        print("읽을 수 있는 견적서 파일이 없습니다.")
        return
    
    print("=" * 80)
    print("견적서 비교 분석")
    print("=" * 80)
    
    # 1. 제품 정보 DataFrame 출력
    print("\n📋 제품별 견적 정보 DataFrame")
    print("-" * 80)
    print(products_df.to_string(index=False))
    
    # 2. 업체별 상세 조건 DataFrame 출력
    print("\n🏢 업체별 상세 조건 DataFrame")
    print("-" * 80)
    print(conditions_df.to_string(index=False))
    
    # 3. 업체별 요약 정보
    print("\n📊 업체별 요약")
    print("-" * 80)
    summary = products_df.groupby('업체명').agg({
        '총액': 'sum',
        '품목': 'count'
    }).rename(columns={'품목': '제품수'})
    summary['총액'] = summary['총액'].apply(lambda x: f"{x:,}원")
    print(summary.to_string())
    
    # 4. 가격 비교 분석
    print("\n💰 가격 비교 분석")
    print("-" * 80)
    
    # 품목별 가격 비교
    product_comparison = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values=['단가', '총액'], 
        aggfunc='first'
    )
    
    print("품목별 단가 비교:")
    print(product_comparison['단가'].to_string())
    
    print("\n품목별 총액 비교:")
    print(product_comparison['총액'].to_string())
    
    # 최저가 업체 찾기
    print("\n🏆 최저가 업체")
    print("-" * 80)
    total_by_company = products_df.groupby('업체명')['총액'].sum()
    min_price_company = total_by_company.idxmin()
    min_price = total_by_company.min()
    
    print(f"전체 최저가: {min_price_company} - {min_price:,}원")
    
    # 품목별 최저가 업체
    print("\n품목별 최저가 업체:")
    for product in products_df['품목'].unique():
        product_data = products_df[products_df['품목'] == product]
        min_price_idx = product_data['단가'].idxmin()
        min_company = product_data.loc[min_price_idx, '업체명']
        min_unit_price = product_data.loc[min_price_idx, '단가']
        print(f"  {product}: {min_company} - {min_unit_price:,}원")

def get_dataframes():
    """
    두 개의 DataFrame을 반환하는 함수
    Returns:
        products_df: 제품 정보 DataFrame
        conditions_df: 업체별 상세 조건 DataFrame
    """
    return read_estimate_files()

if __name__ == "__main__":
    display_results()
