"""
에이전트 도구 구현 모듈
에이전트가 사용할 수 있는 다양한 도구들을 정의합니다.
"""

from typing import List
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from agent.rag_store import RAGStore


# 전역 RAG 스토어 인스턴스 (에이전트 빌더에서 초기화됨)
rag_store: RAGStore = None


def set_rag_store(store: RAGStore):
    """RAG 스토어를 전역 변수로 설정"""
    global rag_store
    rag_store = store


@tool
def summarize_doc(text: str) -> str:
    """
    주어진 텍스트를 요약합니다.
    
    Args:
        text: 요약할 텍스트
        
    Returns:
        요약된 텍스트
    """
    if not text or len(text.strip()) == 0:
        return "요약할 텍스트가 없습니다."
    
    # OpenAI 모델을 사용하여 요약
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    prompt = f"""다음 텍스트를 간결하고 명확하게 요약해주세요.
요약은 핵심 내용만 포함하고, 3-5문장으로 작성해주세요.

텍스트:
{text}

요약:"""
    
    response = llm.invoke(prompt)
    return response.content


@tool
def extract_keywords(text: str) -> str:
    """
    주어진 텍스트에서 핵심 키워드를 추출합니다.
    
    Args:
        text: 키워드를 추출할 텍스트
        
    Returns:
        추출된 키워드 목록 (쉼표로 구분)
    """
    if not text or len(text.strip()) == 0:
        return "키워드를 추출할 텍스트가 없습니다."
    
    # OpenAI 모델을 사용하여 키워드 추출
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    
    prompt = f"""다음 텍스트에서 가장 중요한 핵심 키워드 5-10개를 추출해주세요.
키워드는 쉼표로 구분하여 나열해주세요.

텍스트:
{text}

핵심 키워드:"""
    
    response = llm.invoke(prompt)
    return response.content


@tool
def search_docs(query: str) -> str:
    """
    RAG 기반으로 문서를 검색합니다.
    
    Args:
        query: 검색 쿼리
        
    Returns:
        검색된 문서 내용
    """
    global rag_store
    
    if rag_store is None:
        return "RAG 스토어가 초기화되지 않았습니다. 먼저 문서를 로드해주세요."
    
    if not query or len(query.strip()) == 0:
        return "검색 쿼리가 비어있습니다."
    
    # 문서 검색 수행
    results = rag_store.search(query, k=3)
    
    if not results:
        return f"'{query}'에 대한 검색 결과가 없습니다."
    
    # 검색 결과 포맷팅
    formatted_results = []
    for i, doc in enumerate(results, 1):
        source = doc.metadata.get("source", "Unknown")
        content = doc.page_content[:500]  # 처음 500자만 표시
        formatted_results.append(
            f"[결과 {i}] 출처: {source}\n내용: {content}..."
        )
    
    return "\n\n".join(formatted_results)


def get_tools() -> List:
    """
    모든 도구를 리스트로 반환합니다.
    
    Returns:
        도구 리스트
    """
    return [summarize_doc, extract_keywords, search_docs]

