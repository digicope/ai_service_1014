import os
import uuid
from flask import Flask, render_template, request, jsonify, session
from dotenv import load_dotenv
from google import genai

# 현재 스크립트 파일 위치 기준 .env 로드
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
env_path = os.path.join(BASE_DIR, ".env")
load_dotenv(dotenv_path=env_path)

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static"),
)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "gemini-chatbot-secret-key-12345")

# Gemini API 클라이언트 초기화
api_key = os.getenv("GEMINI_API_KEY")
MODEL_NAME = "gemini-3.5-flash"

client = None
if api_key:
    client = genai.Client(api_key=api_key)

# 세션별 대화(Chat) 객체를 저장하는 메모리 딕셔너리
# chat_sessions = { "chat_session_id": chat_instance }
chat_sessions = {}

def get_or_create_chat(session_id: str):
    """세션 ID에 해당하는 Gemini Chat 인스턴스를 가져오거나 새로 생성하여 반환"""
    global client
    if not client:
        current_key = os.getenv("GEMINI_API_KEY")
        if current_key:
            client = genai.Client(api_key=current_key)

    if not client:
        return None

    if session_id not in chat_sessions:
        # 최신 google-genai SDK의 대화 히스토리 관리 객체 생성
        chat_sessions[session_id] = client.chats.create(model=MODEL_NAME)

    return chat_sessions[session_id]

@app.route("/")
def index():
    """메인 채팅 웹 페이지 렌더링 및 세션 ID 할당"""
    if "chat_id" not in session:
        session["chat_id"] = str(uuid.uuid4())
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    """
    사용자 메시지를 받아 대화 히스토리를 유지하며 Gemini API에 전달하고 응답 반환
    """
    if "chat_id" not in session:
        session["chat_id"] = str(uuid.uuid4())

    chat_id = session["chat_id"]
    chat_instance = get_or_create_chat(chat_id)

    if not chat_instance:
        return jsonify({
            "error": ".env 파일에서 GEMINI_API_KEY를 찾을 수 없습니다. API 키를 확인해주세요."
        }), 500

    data = request.get_json(silent=True) or {}
    user_message = data.get("message", "").strip()

    if not user_message:
        return jsonify({"error": "메시지를 입력해주세요."}), 400

    try:
        # multi-turn 대화: 이전 히스토리가 자동으로 유지된 상태로 전송됨
        response = chat_instance.send_message(user_message)
        bot_reply = response.text if response.text else "응답을 생성하지 못했습니다."
        return jsonify({"reply": bot_reply})
    except Exception as e:
        return jsonify({"error": f"Gemini API 호출 오류: {str(e)}"}), 500

@app.route("/reset", methods=["POST"])
def reset():
    """현재 세션의 대화 히스토리를 초기화하고 새로운 대화 세션을 시작"""
    chat_id = session.get("chat_id")
    if chat_id and chat_id in chat_sessions:
        del chat_sessions[chat_id]
    session["chat_id"] = str(uuid.uuid4())
    return jsonify({"success": True, "message": "대화 히스토리가 초기화되었습니다."})

if __name__ == "__main__":
    print("Flask 웹 챗봇 서버를 시작합니다: http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=True)
