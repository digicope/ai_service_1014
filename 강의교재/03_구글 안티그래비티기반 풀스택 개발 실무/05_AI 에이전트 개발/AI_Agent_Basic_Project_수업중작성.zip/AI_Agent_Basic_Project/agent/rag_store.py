"""
RAG 스토어 구현 모듈
문서 임베딩 및 검색 기능을 제공합니다.
"""

import os
from pathlib import Path
from typing import List, Optional
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document


class RAGStore:
    """RAG 기반 문서 검색 스토어"""
    
    def __init__(self, embedding_model: str = "text-embedding-3-small"):
        """
        RAG 스토어 초기화
        
        Args:
            embedding_model: OpenAI 임베딩 모델명
        """
        # OpenAI 임베딩 모델 초기화
        self.embeddings = OpenAIEmbeddings(model=embedding_model)
        
        # 벡터 스토어 (메모리 기반)
        self.vectorstore: Optional[FAISS] = None
        
        # 텍스트 분할기 초기화
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len,
        )
    
    def load_documents(self, docs_dir: str) -> List[Document]:
        """
        디렉토리에서 문서들을 로드합니다.
        
        Args:
            docs_dir: 문서가 있는 디렉토리 경로
            
        Returns:
            Document 객체 리스트
        """
        documents = []
        docs_path = Path(docs_dir)
        
        # 디렉토리 내의 모든 .txt 파일 읽기
        for txt_file in docs_path.glob("*.txt"):
            try:
                with open(txt_file, "r", encoding="utf-8") as f:
                    content = f.read()
                    # Document 객체 생성 (메타데이터에 파일명 포함)
                    doc = Document(
                        page_content=content,
                        metadata={"source": str(txt_file.name)}
                    )
                    documents.append(doc)
            except Exception as e:
                print(f"문서 로드 오류 ({txt_file}): {e}")
        
        return documents
    
    def build_vectorstore(self, docs_dir: str):
        """
        문서들을 로드하고 벡터 스토어를 구축합니다.
        
        Args:
            docs_dir: 문서가 있는 디렉토리 경로
        """
        # 문서 로드
        documents = self.load_documents(docs_dir)
        
        if not documents:
            print("로드된 문서가 없습니다.")
            return
        
        # 문서를 청크로 분할
        texts = self.text_splitter.split_documents(documents)
        print(f"총 {len(documents)}개 문서를 {len(texts)}개 청크로 분할했습니다.")
        
        # FAISS 벡터 스토어 생성
        self.vectorstore = FAISS.from_documents(
            documents=texts,
            embedding=self.embeddings
        )
        print("벡터 스토어 구축이 완료되었습니다.")
    
    def search(self, query: str, k: int = 3) -> List[Document]:
        """
        쿼리에 대한 유사 문서를 검색합니다.
        
        Args:
            query: 검색 쿼리
            k: 반환할 문서 개수
            
        Returns:
            검색된 Document 객체 리스트
        """
        if self.vectorstore is None:
            return []
        
        # 유사도 검색 수행
        results = self.vectorstore.similarity_search(query, k=k)
        return results
    
    def search_with_scores(self, query: str, k: int = 3) -> List[tuple]:
        """
        쿼리에 대한 유사 문서를 유사도 점수와 함께 검색합니다.
        
        Args:
            query: 검색 쿼리
            k: 반환할 문서 개수
            
        Returns:
            (Document, score) 튜플 리스트
        """
        if self.vectorstore is None:
            return []
        
        # 유사도 점수와 함께 검색
        results = self.vectorstore.similarity_search_with_score(query, k=k)
        return results

