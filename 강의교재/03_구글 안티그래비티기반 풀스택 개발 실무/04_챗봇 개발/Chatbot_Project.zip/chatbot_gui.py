import os
import sys
import sqlite3
import datetime
import threading
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from dotenv import load_dotenv
from google import genai
from google.genai import types
from google.genai.errors import APIError

# .env 파일 로드
current_dir = os.path.dirname(os.path.abspath(__file__))
dotenv_path = os.path.join(current_dir, ".env")
load_dotenv(dotenv_path)

DB_PATH = os.path.join(current_dir, "chat_history.db")


# ==========================================
# 11단계: SQLite 데이터베이스 관리 클래스
# ==========================================
class DatabaseManager:
    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path
        self.init_db()

    def get_connection(self):
        return sqlite3.connect(self.db_path)

    def init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    sender TEXT NOT NULL,
                    message TEXT NOT NULL,
                    timestamp TEXT NOT NULL
                )
            """)
            conn.commit()

    def save_message(self, session_id: str, sender: str, message: str):
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO messages (session_id, sender, message, timestamp) VALUES (?, ?, ?, ?)",
                (session_id, sender, message, now),
            )
            conn.commit()

    def get_all_sessions(self):
        """세션 목록(세션ID, 시작 시간, 첫 질문 미리보기) 조회"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT session_id, MIN(timestamp) as start_time, 
                       (SELECT message FROM messages m2 WHERE m2.session_id = m1.session_id AND sender = 'You' ORDER BY id ASC LIMIT 1) as first_question,
                       COUNT(*) as msg_count
                FROM messages m1
                GROUP BY session_id
                ORDER BY start_time DESC
            """)
            return cursor.fetchall()

    def get_messages_by_session(self, session_id: str):
        """특정 세션의 모든 메시지 조회"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT sender, message, timestamp FROM messages WHERE session_id = ? ORDER BY id ASC",
                (session_id,),
            )
            return cursor.fetchall()


# ==========================================
# 11단계: 대화 기록(History) 조회 팝업 창
# ==========================================
class HistoryWindow(tk.Toplevel):
    def __init__(self, parent, db_manager: DatabaseManager):
        super().__init__(parent)
        self.db_manager = db_manager
        self.title("대화 내역 (Chat History)")
        self.geometry("750x550")
        self.configure(bg="#1E1F22")

        self.create_widgets()
        self.load_sessions()

    def create_widgets(self):
        # 상단 타이틀
        title_frame = tk.Frame(self, bg="#2B2D31", height=45)
        title_frame.pack(fill=tk.X)
        title_label = tk.Label(
            title_frame,
            text="저장된 대화 기록 조회",
            font=("Malgun Gothic", 12, "bold"),
            fg="#FFFFFF",
            bg="#2B2D31",
            pady=10,
        )
        title_label.pack(side=tk.LEFT, padx=15)

        # 메인 컨테이너 (좌우 분할)
        paned = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 좌측: 세션 목록 (Treeview)
        left_frame = tk.Frame(paned, bg="#1E1F22")
        paned.add(left_frame, weight=1)

        tree_label = tk.Label(
            left_frame,
            text="대화 세션 목록",
            font=("Malgun Gothic", 10, "bold"),
            fg="#B5BAC1",
            bg="#1E1F22",
        )
        tree_label.pack(anchor=tk.W, pady=(0, 5))

        self.tree = ttk.Treeview(
            left_frame,
            columns=("time", "preview"),
            show="headings",
            selectmode="browse",
        )
        self.tree.heading("time", text="일시")
        self.tree.heading("preview", text="첫 질문 미리보기")
        self.tree.column("time", width=140, anchor=tk.CENTER)
        self.tree.column("preview", width=180, anchor=tk.W)

        tree_scroll = ttk.Scrollbar(left_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=tree_scroll.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree.bind("<<TreeviewSelect>>", self.on_session_selected)

        # 우측: 선택한 세션의 상세 대화 내용
        right_frame = tk.Frame(paned, bg="#1E1F22")
        paned.add(right_frame, weight=2)

        detail_label = tk.Label(
            right_frame,
            text="대화 상세 내용",
            font=("Malgun Gothic", 10, "bold"),
            fg="#B5BAC1",
            bg="#1E1F22",
        )
        detail_label.pack(anchor=tk.W, pady=(0, 5))

        self.detail_text = scrolledtext.ScrolledText(
            right_frame,
            wrap=tk.WORD,
            font=("Malgun Gothic", 10),
            bg="#2B2D31",
            fg="#F2F3F5",
            insertbackground="#FFFFFF",
            relief=tk.FLAT,
            padx=10,
            pady=10,
        )
        self.detail_text.pack(fill=tk.BOTH, expand=True)

        # 텍스트 태그 스타일
        self.detail_text.tag_config("you_header", foreground="#5865F2", font=("Malgun Gothic", 10, "bold"))
        self.detail_text.tag_config("bot_header", foreground="#57F287", font=("Malgun Gothic", 10, "bold"))
        self.detail_text.tag_config("time_tag", foreground="#80848E", font=("Malgun Gothic", 8))
        self.detail_text.tag_config("content", foreground="#DBDEE1", spacing3=8)

        # 하단 닫기 버튼
        bottom_frame = tk.Frame(self, bg="#1E1F22", pady=8)
        bottom_frame.pack(fill=tk.X)
        close_btn = tk.Button(
            bottom_frame,
            text="닫기",
            command=self.destroy,
            font=("Malgun Gothic", 9),
            bg="#4E5058",
            fg="#FFFFFF",
            activebackground="#6D6F78",
            relief=tk.FLAT,
            padx=15,
            pady=4,
            cursor="hand2",
        )
        close_btn.pack(side=tk.RIGHT, padx=15)

    def load_sessions(self):
        sessions = self.db_manager.get_all_sessions()
        for session in sessions:
            session_id, start_time, first_q, _ = session
            preview = (first_q[:25] + "...") if first_q and len(first_q) > 25 else (first_q or "(대화 없음)")
            self.tree.insert("", tk.END, iid=session_id, values=(start_time, preview))

    def on_session_selected(self, event):
        selected_items = self.tree.selection()
        if not selected_items:
            return
        session_id = selected_items[0]
        messages = self.db_manager.get_messages_by_session(session_id)

        self.detail_text.config(state=tk.NORMAL)
        self.detail_text.delete("1.0", tk.END)

        if not messages:
            self.detail_text.insert(tk.END, "기록된 대화 내용이 없습니다.\n")
        else:
            for sender, message, timestamp in messages:
                if sender == "You":
                    self.detail_text.insert(tk.END, f"👤 You ", "you_header")
                    self.detail_text.insert(tk.END, f"[{timestamp}]\n", "time_tag")
                else:
                    self.detail_text.insert(tk.END, f"🤖 Bot (Gemini) ", "bot_header")
                    self.detail_text.insert(tk.END, f"[{timestamp}]\n", "time_tag")
                self.detail_text.insert(tk.END, f"{message}\n\n", "content")

        self.detail_text.config(state=tk.DISABLED)


# ==========================================
# 9, 10, 11단계: Tkinter 기반 챗봇 GUI 메인
# ==========================================
class ChatbotGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Gemini AI 챗봇")
        self.root.geometry("680x740")
        self.root.minsize(550, 600)
        self.root.configure(bg="#1E1F22")

        # 데이터베이스 및 대화 상태 관리
        self.db_manager = DatabaseManager()
        self.new_session()

        # 6단계: 대화 메모리 (Gemini 요청용 히스토리)
        self.gemini_history = []

        # 8단계: temperature 기본값
        self.temperature_var = tk.DoubleVar(value=0.2)

        # 7단계: Gemini 클라이언트 초기화
        self.client = None
        self.init_gemini_client()

        # UI 생성
        self.create_widgets()

    def new_session(self):
        """새로운 대화 세션 ID 생성"""
        self.session_id = datetime.datetime.now().strftime("session_%Y%m%d_%H%M%S")
        self.gemini_history = []

    def init_gemini_client(self):
        """7단계: API 키 및 클라이언트 초기화 (오류 처리 포함)"""
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            messagebox.showwarning(
                "API 키 경고",
                "GEMINI_API_KEY 환경 변수가 설정되지 않았습니다.\n.env 파일을 확인해주세요.",
            )
            return

        try:
            self.client = genai.Client(api_key=api_key)
        except Exception as e:
            messagebox.showerror(
                "초기화 오류",
                f"Gemini 클라이언트를 초기화하는 중 오류가 발생했습니다:\n{e}",
            )

    # 10단계: GUI 디자인 개선
    def create_widgets(self):
        # 1. 상단 툴바 (세션 정보, Temperature 선택, History 버튼)
        top_bar = tk.Frame(self.root, bg="#2B2D31", height=50)
        top_bar.pack(fill=tk.X, side=tk.TOP)

        title_label = tk.Label(
            top_bar,
            text="✨ Gemini Chatbot",
            font=("Malgun Gothic", 12, "bold"),
            fg="#FFFFFF",
            bg="#2B2D31",
        )
        title_label.pack(side=tk.LEFT, padx=15, pady=10)

        # 8단계: Temperature 라디오 버튼 메뉴
        temp_frame = tk.Frame(top_bar, bg="#2B2D31")
        temp_frame.pack(side=tk.LEFT, padx=10)

        temp_title = tk.Label(
            temp_frame,
            text="온도(Temp):",
            font=("Malgun Gothic", 9),
            fg="#B5BAC1",
            bg="#2B2D31",
        )
        temp_title.pack(side=tk.LEFT, padx=(0, 5))

        rb_02 = tk.Radiobutton(
            temp_frame,
            text="0.2 (정밀)",
            variable=self.temperature_var,
            value=0.2,
            font=("Malgun Gothic", 9),
            fg="#FFFFFF",
            bg="#2B2D31",
            selectcolor="#1E1F22",
            activebackground="#2B2D31",
            activeforeground="#FFFFFF",
            cursor="hand2",
        )
        rb_02.pack(side=tk.LEFT, padx=2)

        rb_10 = tk.Radiobutton(
            temp_frame,
            text="1.0 (창의)",
            variable=self.temperature_var,
            value=1.0,
            font=("Malgun Gothic", 9),
            fg="#FFFFFF",
            bg="#2B2D31",
            selectcolor="#1E1F22",
            activebackground="#2B2D31",
            activeforeground="#FFFFFF",
            cursor="hand2",
        )
        rb_10.pack(side=tk.LEFT, padx=2)

        # 상단 우측 버튼들 (History, 새 대화)
        btn_frame = tk.Frame(top_bar, bg="#2B2D31")
        btn_frame.pack(side=tk.RIGHT, padx=15)

        # 11단계: History 버튼
        history_btn = tk.Button(
            btn_frame,
            text="📜 History",
            command=self.open_history,
            font=("Malgun Gothic", 9, "bold"),
            bg="#4E5058",
            fg="#FFFFFF",
            activebackground="#6D6F78",
            activeforeground="#FFFFFF",
            relief=tk.FLAT,
            padx=10,
            pady=3,
            cursor="hand2",
        )
        history_btn.pack(side=tk.RIGHT, padx=5)

        new_chat_btn = tk.Button(
            btn_frame,
            text="🔄 새 대화",
            command=self.on_new_chat,
            font=("Malgun Gothic", 9),
            bg="#3B3E45",
            fg="#FFFFFF",
            activebackground="#4E5058",
            activeforeground="#FFFFFF",
            relief=tk.FLAT,
            padx=8,
            pady=3,
            cursor="hand2",
        )
        new_chat_btn.pack(side=tk.RIGHT, padx=5)

        # 2. 채팅 영역 (10단계: 스크롤 기능 및 깔끔한 대화창)
        chat_container = tk.Frame(self.root, bg="#1E1F22", padx=15, pady=10)
        chat_container.pack(fill=tk.BOTH, expand=True)

        self.chat_display = scrolledtext.ScrolledText(
            chat_container,
            wrap=tk.WORD,
            font=("Malgun Gothic", 10),
            bg="#2B2D31",
            fg="#F2F3F5",
            insertbackground="#FFFFFF",
            relief=tk.FLAT,
            padx=12,
            pady=12,
        )
        self.chat_display.pack(fill=tk.BOTH, expand=True)

        # 10단계: 사용자 질문과 Gemini 답변 표시 형식 스타일 태그
        self.chat_display.tag_config("you_tag", foreground="#5865F2", font=("Malgun Gothic", 10, "bold"))
        self.chat_display.tag_config("bot_tag", foreground="#57F287", font=("Malgun Gothic", 10, "bold"))
        self.chat_display.tag_config("system_tag", foreground="#FEE75C", font=("Malgun Gothic", 9, "italic"))
        self.chat_display.tag_config("error_tag", foreground="#ED4245", font=("Malgun Gothic", 9, "bold"))
        self.chat_display.tag_config("msg_content", foreground="#DBDEE1", spacing3=10)

        # 초기 환영 메시지
        self.append_system_message("Gemini 챗봇에 오신 것을 환영합니다! 질문을 입력해 대화를 시작해보세요.")

        # 3. 입력 영역 (9단계: 입력창, 전송 버튼, Enter 키 바인딩)
        input_container = tk.Frame(self.root, bg="#2B2D31", padx=12, pady=10)
        input_container.pack(fill=tk.X, side=tk.BOTTOM)

        self.input_entry = tk.Entry(
            input_container,
            font=("Malgun Gothic", 11),
            bg="#1E1F22",
            fg="#FFFFFF",
            insertbackground="#FFFFFF",
            relief=tk.FLAT,
        )
        self.input_entry.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, ipady=8, padx=(0, 10))

        # 9단계: Enter 키 바인딩
        self.input_entry.bind("<Return>", lambda event: self.send_message())
        self.input_entry.focus_set()

        # 9단계: 전송 버튼
        self.send_btn = tk.Button(
            input_container,
            text="전송",
            command=self.send_message,
            font=("Malgun Gothic", 10, "bold"),
            bg="#5865F2",
            fg="#FFFFFF",
            activebackground="#4752C4",
            activeforeground="#FFFFFF",
            relief=tk.FLAT,
            padx=18,
            cursor="hand2",
        )
        self.send_btn.pack(side=tk.RIGHT, ipady=4)

        # 하단 상태 바
        self.status_label = tk.Label(
            self.root,
            text="준비 완료",
            font=("Malgun Gothic", 8),
            fg="#80848E",
            bg="#1E1F22",
            anchor=tk.W,
            padx=15,
            pady=3,
        )
        self.status_label.pack(fill=tk.X, side=tk.BOTTOM)

    def append_system_message(self, text: str):
        self.chat_display.config(state=tk.NORMAL)
        self.chat_display.insert(tk.END, f"[안내] {text}\n\n", "system_tag")
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)

    def append_message(self, sender: str, message: str):
        self.chat_display.config(state=tk.NORMAL)
        if sender == "You":
            self.chat_display.insert(tk.END, "You: ", "you_tag")
        elif sender == "Bot":
            self.chat_display.insert(tk.END, "Bot: ", "bot_tag")
        else:
            self.chat_display.insert(tk.END, f"{sender}: ", "system_tag")

        self.chat_display.insert(tk.END, f"{message}\n\n", "msg_content")
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)

    def on_new_chat(self):
        """새로운 대화 세션 시작"""
        if messagebox.askyesno("새 대화", "현재 대화를 마치고 새 대화를 시작하시겠습니까?"):
            self.new_session()
            self.chat_display.config(state=tk.NORMAL)
            self.chat_display.delete("1.0", tk.END)
            self.chat_display.config(state=tk.DISABLED)
            self.append_system_message("새로운 대화가 시작되었습니다.")
            self.status_label.config(text="새 대화 세션 시작됨")

    def open_history(self):
        """11단계: History 조회 창 열기"""
        HistoryWindow(self.root, self.db_manager)

    def send_message(self):
        """메시지 전송 및 백그라운드 API 호출"""
        user_text = self.input_entry.get().strip()
        if not user_text:
            return

        if not self.client:
            self.init_gemini_client()
            if not self.client:
                messagebox.showerror("오류", "Gemini API 클라이언트가 준비되지 않았습니다.")
                return

        # 입력창 초기화
        self.input_entry.delete(0, tk.END)

        # 10단계: 화면에 You: 메시지 출력
        self.append_message("You", user_text)

        # 11단계: SQLite DB에 사용자 메시지 저장
        self.db_manager.save_message(self.session_id, "You", user_text)

        # 6단계: 대화 메모리(히스토리)에 사용자 메시지 추가
        user_content = types.Content(
            role="user",
            parts=[types.Part.from_text(text=user_text)],
        )
        self.gemini_history.append(user_content)

        # UI 상태 업데이트: 비활성화 및 로딩 표시
        self.send_btn.config(state=tk.DISABLED, bg="#4E5058")
        self.input_entry.config(state=tk.DISABLED)
        self.status_label.config(text="답변 생성 중...")

        # 백그라운드 스레드에서 API 호출 (GUI 멈춤 방지)
        current_temp = self.temperature_var.get()
        threading.Thread(
            target=self._request_gemini_response,
            args=(current_temp,),
            daemon=True,
        ).start()

    def _request_gemini_response(self, temperature: float):
        """7단계: 오류 처리가 포함된 비동기 API 요청"""
        try:
            response = self.client.models.generate_content(
                model="gemini-3.5-flash",
                contents=self.gemini_history,
                config=types.GenerateContentConfig(temperature=temperature),
            )
            bot_text = response.text if response.text else "(답변 내용이 없습니다)"

            # UI 스레드로 결과 전달
            self.root.after(0, self._on_response_success, bot_text)

        except APIError as e:
            err_msg = f"Gemini API 오류: {e.message or e}"
            self.root.after(0, self._on_response_error, err_msg)
        except ConnectionError as e:
            err_msg = f"네트워크 연결 오류: {e}"
            self.root.after(0, self._on_response_error, err_msg)
        except Exception as e:
            err_msg = f"오류 발생: {e}"
            self.root.after(0, self._on_response_error, err_msg)

    def _on_response_success(self, bot_text: str):
        # 10단계: 화면에 Bot: 메시지 출력
        self.append_message("Bot", bot_text)

        # 11단계: SQLite DB에 Bot 답변 저장
        self.db_manager.save_message(self.session_id, "Bot", bot_text)

        # 6단계: 히스토리에 Bot 답변 추가하여 맥락 유지
        bot_content = types.Content(
            role="model",
            parts=[types.Part.from_text(text=bot_text)],
        )
        self.gemini_history.append(bot_content)

        # UI 복원
        self._restore_ui()
        self.status_label.config(text="답변 수신 완료")

    def _on_response_error(self, error_message: str):
        # 7단계: 오류 메시지 출력
        self.chat_display.config(state=tk.NORMAL)
        self.chat_display.insert(tk.END, f"[오류] {error_message}\n\n", "error_tag")
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)

        # 실패한 사용자 메시지는 맥락에서 제거
        if self.gemini_history:
            self.gemini_history.pop()

        self._restore_ui()
        self.status_label.config(text="오류 발생")

    def _restore_ui(self):
        self.send_btn.config(state=tk.NORMAL, bg="#5865F2")
        self.input_entry.config(state=tk.NORMAL)
        self.input_entry.focus_set()


if __name__ == "__main__":
    root = tk.Tk()
    app = ChatbotGUI(root)
    root.mainloop()
