import os
import streamlit as st
from PIL import Image
from dotenv import load_dotenv

from agent.agent_builder import create_multimodal_agent, analyze_image_caption, run_agent_query
from agent.rag_store import build_vector_store

# .env 환경 변수 로드 (C:\env\.env 경로 우선 로드)
ENV_PATH = r"C:\env\.env"
if os.path.exists(ENV_PATH):
    load_dotenv(dotenv_path=ENV_PATH)
else:
    load_dotenv()

# Streamlit 페이지 설정
st.set_page_config(
    page_title="AI Agent Basic Project",
    page_icon="🤖",
    layout="wide"
)

st.title("🤖 멀티모달 AI Agent & RAG 챗봇")
st.caption("Google Gemini + 최신 LangChain 기반 멀티모달 에이전트 & RAG 시스템")

# --- 사이드바 설정 ---
with st.sidebar:
    st.header("⚙️ 설정 및 도구")
    
    # API 키 입력 관리
    env_api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY", "")
    api_key_input = st.text_input(
        "Gemini API Key (GEMINI_API_KEY)",
        value=env_api_key,
        type="password",
        help="C:\\env\\.env 파일에 설정되어 있거나 직접 입력 가능합니다."
    )
    if api_key_input:
        os.environ["GEMINI_API_KEY"] = api_key_input
        os.environ["GOOGLE_API_KEY"] = api_key_input

    st.markdown("---")
    st.subheader("📚 PDF ChromaDB 관리")
    if st.button("PDF 지식 문서 다시 색인 (Re-indexing)"):
        with st.spinner("pdf_data/ 폴더 내 PDF들을 ChromaDB에 색인 중입니다..."):
            try:
                build_vector_store("pdf_data")
                st.success("✅ ChromaDB PDF 색인 완료! (기존 DB 갱신)")
            except Exception as e:
                st.error(f"색인 중 오류 발생: {e}")

    st.markdown("---")
    st.markdown("### 🛠️ 등록된 Agent 도구(Tools)")
    st.markdown(
        "- **`search_docs(query)`**: PDF ChromaDB 검색 (출처 파일/페이지 포함)\n"
        "- **`summarize_doc(text)`**: 문서 3문장 요약\n"
        "- **`extract_keywords(text)`**: 핵심 키워드 추출"
    )

# 에이전트 캐싱 초기화
@st.cache_resource
def load_agent():
    return create_multimodal_agent()

# API 키 유효성 체크
if not (os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")):
    st.warning("⚠️ GEMINI_API_KEY가 설정되지 않았습니다. 사이드바에 입력하거나 C:\\env\\.env 파일에 GEMINI_API_KEY를 설정해주세요.")
    st.stop()

try:
    agent = load_agent()
except Exception as e:
    st.error(f"에이전트 초기화 실패: {e}")
    st.stop()

# --- 탭 구성 (1. 이미지 분석 / 2. 에이전트 챗봇) ---
tab_chat, tab_image = st.tabs(["💬 에이전트 질의응답 (RAG & Tools)", "🖼️ 이미지 분석 (Multimodal)"])

# 탭 1: 에이전트 질의응답 및 RAG
with tab_chat:
    st.markdown("##### AI 에이전트에게 질문하거나 작업을 요청해보세요.")
    st.caption("예시: `금융상품 추천 및 혼잡도 예측에 대해 알려줘`, `PDF 문서에서 혼잡도 예측 모델 부분을 검색해서 요약해줘`")

    # 세션 상태에 대화 기록 저장
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    # 이전 대화 렌더링
    for msg in st.session_state.chat_history:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    # 사용자 질의 입력
    user_prompt = st.chat_input("메시지를 입력하세요 (예: 인공지능에 대해 검색해줘)")
    if user_prompt:
        # 사용자 메시지 표시
        st.session_state.chat_history.append({"role": "user", "content": user_prompt})
        with st.chat_message("user"):
            st.markdown(user_prompt)

        # 에이전트 실행 및 응답
        with st.chat_message("assistant"):
            with st.spinner("AI 에이전트가 도구를 확인하고 추론하는 중입니다..."):
                try:
                    # 질의문 요구사항: result["messages"][-1].content 형태로 출력
                    response_text = run_agent_query(agent, user_prompt)
                    st.markdown(response_text)
                    st.session_state.chat_history.append({"role": "assistant", "content": response_text})
                except Exception as e:
                    error_msg = f"에이전트 실행 중 오류가 발생했습니다: {e}"
                    st.error(error_msg)
                    st.session_state.chat_history.append({"role": "assistant", "content": error_msg})

# 탭 2: 이미지 분석
with tab_image:
    st.markdown("##### 이미지를 업로드하고 Gemini 멀티모달 모델로 설명 및 캡션을 생성합니다.")
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        uploaded_image = st.file_uploader(
            "이미지 파일 업로드 (JPG, PNG)",
            type=["jpg", "jpeg", "png"],
            help="배포된 image.jpg 파일을 업로드해보세요."
        )
        
        image_prompt = st.text_input(
            "이미지 분석 요청 프롬프트",
            value="이 이미지의 핵심 객체와 상황을 자세히 설명하고, 간결한 한 줄 캡션을 생성해줘."
        )
        
        analyze_btn = st.button("이미지 분석 시작", type="primary")

    with col2:
        if uploaded_image is not None:
            # 안전하게 PIL Image 열기 (추가 질의-2 해결)
            pil_img = Image.open(uploaded_image)
            st.image(pil_img, caption="업로드된 이미지 미리보기", use_container_width=True)

            if analyze_btn:
                with st.spinner("Gemini가 이미지를 분석하고 있습니다..."):
                    try:
                        # 이미지 분석 함수 호출
                        caption_result = analyze_image_caption(uploaded_image, prompt=image_prompt)
                        st.success("분석 완료!")
                        st.markdown("### 📋 분석 결과 및 캡션")
                        st.info(caption_result)
                    except Exception as e:
                        st.error(f"이미지 분석 중 오류 발생: {e}")
        else:
            st.info("왼쪽에서 이미지를 업로드하세요.")

