import PyPDF2
import os
import json
import re
from pathlib import Path

def preprocess_text(text):
    """
    텍스트를 전처리하여 불필요한 줄바꿈, 공백 등을 제거하는 함수
    
    Args:
        text (str): 원본 텍스트
        
    Returns:
        str: 전처리된 텍스트
    """
    if not text:
        return ""
    
    # 1. 연속된 공백을 하나로 통합
    text = re.sub(r' +', ' ', text)
    
    # 2. 연속된 줄바꿈을 하나로 통합 (단, 문단 구분은 유지)
    text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
    
    # 3. 줄 시작과 끝의 공백 제거
    lines = text.split('\n')
    lines = [line.strip() for line in lines]
    
    # 4. 빈 줄들을 적절히 정리 (연속된 빈 줄을 하나로)
    processed_lines = []
    prev_empty = False
    
    for line in lines:
        if line == "":
            if not prev_empty:
                processed_lines.append("")
            prev_empty = True
        else:
            processed_lines.append(line)
            prev_empty = False
    
    # 5. 문장 끝에서 줄바꿈이 잘못된 경우 수정
    text = '\n'.join(processed_lines)
    
    # 6. 문장 중간에 불필요한 줄바꿈 제거 (단어가 끊어진 경우)
    text = re.sub(r'(\w)\n(\w)', r'\1 \2', text)
    
    # 7. 특수 문자 주변의 공백 정리
    text = re.sub(r'\s+([.,;:!?])', r'\1', text)
    text = re.sub(r'([.,;:!?])\s*([.,;:!?])', r'\1\2', text)
    
    # 8. 괄호 주변 공백 정리
    text = re.sub(r'\s*\(\s*', ' (', text)
    text = re.sub(r'\s*\)\s*', ') ', text)
    
    # 9. 최종적으로 연속된 공백을 하나로 통합
    text = re.sub(r' +', ' ', text)
    
    # 10. 전체 텍스트의 시작과 끝 공백 제거
    text = text.strip()
    
    return text

def extract_text_from_pdf(pdf_path, output_dir="extracted_text"):
    """
    PDF 파일에서 페이지별로 텍스트를 추출하여 저장하는 함수
    
    Args:
        pdf_path (str): PDF 파일 경로
        output_dir (str): 추출된 텍스트를 저장할 디렉토리
    """
    
    # 출력 디렉토리 생성
    Path(output_dir).mkdir(exist_ok=True)
    
    try:
        # PDF 파일 열기
        with open(pdf_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            
            # PDF 정보 출력
            total_pages = len(pdf_reader.pages)
            print(f"PDF 파일: {pdf_path}")
            print(f"총 페이지 수: {total_pages}")
            print("-" * 50)
            
            # 페이지별 텍스트 추출
            extracted_texts = {}
            preprocessed_texts = {}
            
            for page_num in range(total_pages):
                page = pdf_reader.pages[page_num]
                text = page.extract_text()
                
                # 페이지 번호 (1부터 시작)
                page_number = page_num + 1
                
                # 텍스트가 있는 경우에만 저장
                if text.strip():
                    # 원본 텍스트 저장
                    extracted_texts[page_number] = text
                    
                    # 전처리된 텍스트 생성
                    preprocessed_text = preprocess_text(text)
                    preprocessed_texts[page_number] = preprocessed_text
                    
                    # 개별 페이지 텍스트 파일로 저장 (원본)
                    page_filename = f"page_{page_number:03d}.txt"
                    page_filepath = os.path.join(output_dir, page_filename)
                    
                    with open(page_filepath, 'w', encoding='utf-8') as page_file:
                        page_file.write(f"=== 페이지 {page_number} ===\n\n")
                        page_file.write(text)
                    
                    # 개별 페이지 전처리된 텍스트 파일로 저장
                    preprocessed_page_filename = f"page_{page_number:03d}_cleaned.txt"
                    preprocessed_page_filepath = os.path.join(output_dir, preprocessed_page_filename)
                    
                    with open(preprocessed_page_filepath, 'w', encoding='utf-8') as preprocessed_page_file:
                        preprocessed_page_file.write(f"=== 페이지 {page_number} (전처리됨) ===\n\n")
                        preprocessed_page_file.write(preprocessed_text)
                    
                    print(f"페이지 {page_number}: {len(text)} 문자 추출, {len(preprocessed_text)} 문자 전처리 완료")
                else:
                    print(f"페이지 {page_number}: 텍스트 없음")
            
            # 전체 텍스트를 하나의 파일로 저장 (원본)
            all_text_filename = "all_pages_text.txt"
            all_text_filepath = os.path.join(output_dir, all_text_filename)
            
            with open(all_text_filepath, 'w', encoding='utf-8') as all_text_file:
                for page_num, text in extracted_texts.items():
                    all_text_file.write(f"=== 페이지 {page_num} ===\n\n")
                    all_text_file.write(text)
                    all_text_file.write("\n\n" + "="*80 + "\n\n")
            
            # 전체 전처리된 텍스트를 하나의 파일로 저장
            all_cleaned_text_filename = "all_pages_text_cleaned.txt"
            all_cleaned_text_filepath = os.path.join(output_dir, all_cleaned_text_filename)
            
            with open(all_cleaned_text_filepath, 'w', encoding='utf-8') as all_cleaned_text_file:
                for page_num, text in preprocessed_texts.items():
                    all_cleaned_text_file.write(f"=== 페이지 {page_num} (전처리됨) ===\n\n")
                    all_cleaned_text_file.write(text)
                    all_cleaned_text_file.write("\n\n" + "="*80 + "\n\n")
            
            # JSON 형태로도 저장 (구조화된 데이터 - 원본)
            json_filename = "extracted_text.json"
            json_filepath = os.path.join(output_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as json_file:
                json.dump(extracted_texts, json_file, ensure_ascii=False, indent=2)
            
            # JSON 형태로도 저장 (구조화된 데이터 - 전처리됨)
            json_cleaned_filename = "extracted_text_cleaned.json"
            json_cleaned_filepath = os.path.join(output_dir, json_cleaned_filename)
            
            with open(json_cleaned_filepath, 'w', encoding='utf-8') as json_cleaned_file:
                json.dump(preprocessed_texts, json_cleaned_file, ensure_ascii=False, indent=2)
            
            print("-" * 50)
            print(f"텍스트 추출 및 전처리 완료!")
            print(f"추출된 페이지 수: {len(extracted_texts)}")
            print(f"저장 위치: {output_dir}/")
            print(f"- 개별 페이지 (원본): page_XXX.txt")
            print(f"- 개별 페이지 (전처리): page_XXX_cleaned.txt")
            print(f"- 전체 텍스트 (원본): {all_text_filename}")
            print(f"- 전체 텍스트 (전처리): {all_cleaned_text_filename}")
            print(f"- JSON 형태 (원본): {json_filename}")
            print(f"- JSON 형태 (전처리): {json_cleaned_filename}")
            
            return extracted_texts, preprocessed_texts
            
    except FileNotFoundError:
        print(f"오류: PDF 파일을 찾을 수 없습니다 - {pdf_path}")
        return None
    except Exception as e:
        print(f"오류 발생: {str(e)}")
        return None

def main():
    """메인 함수"""
    # 현재 디렉토리의 PDF 파일 경로
    pdf_filename = "Tech-Report-Generative-AI.pdf"
    
    # 파일 존재 확인
    if not os.path.exists(pdf_filename):
        print(f"오류: {pdf_filename} 파일이 현재 디렉토리에 없습니다.")
        print("현재 디렉토리의 파일들:")
        for file in os.listdir("."):
            if file.endswith(".pdf"):
                print(f"  - {file}")
        return
    
    # 텍스트 추출 실행
    result = extract_text_from_pdf(pdf_filename)
    
    if result:
        extracted_texts, preprocessed_texts = result
        
        print("\n원본 텍스트 미리보기 (첫 번째 페이지):")
        print("-" * 50)
        first_page_text = list(extracted_texts.values())[0]
        preview = first_page_text[:500] + "..." if len(first_page_text) > 500 else first_page_text
        print(preview)
        
        print("\n전처리된 텍스트 미리보기 (첫 번째 페이지):")
        print("-" * 50)
        first_page_cleaned = list(preprocessed_texts.values())[0]
        preview_cleaned = first_page_cleaned[:500] + "..." if len(first_page_cleaned) > 500 else first_page_cleaned
        print(preview_cleaned)
        
        print(f"\n전처리 효과:")
        print(f"- 원본 문자 수: {len(first_page_text)}")
        print(f"- 전처리 후 문자 수: {len(first_page_cleaned)}")
        print(f"- 문자 수 변화: {len(first_page_cleaned) - len(first_page_text):+d}")

if __name__ == "__main__":
    main()
