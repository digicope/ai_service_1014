"""
에이전트 빌더 모듈
LangChain v1.0의 create_agent를 사용하여 멀티모달 AI 에이전트를 생성합니다.
"""

from typing import List, Optional
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage
from agent.tools import get_tools, set_rag_store
from agent.rag_store import RAGStore

# LangChain v1.0의 새로운 표준: create_agent 사용
from langchain.agents import create_agent


def analyze_image(image_path: str, prompt: str = "이 이미지를 자세히 설명해주세요.") -> str:
    """
    이미지를 분석하고 설명을 생성합니다.
    
    Args:
        image_path: 이미지 파일 경로
        prompt: 이미지 분석 프롬프트
        
    Returns:
        이미지 분석 결과 텍스트
    """
    from PIL import Image
    import base64
    from io import BytesIO
    
    # 이미지 로드 및 base64 인코딩
    try:
        # 이미지 파일 읽기
        with open(image_path, "rb") as image_file:
            image_data = image_file.read()
            base64_image = base64.b64encode(image_data).decode('utf-8')
        
        # 이미지 MIME 타입 결정
        img_ext = image_path.lower().split('.')[-1]
        mime_type_map = {
            'png': 'image/png',
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'gif': 'image/gif',
            'bmp': 'image/bmp',
            'webp': 'image/webp'
        }
        mime_type = mime_type_map.get(img_ext, 'image/jpeg')
        
        # OpenAI Vision 모델 사용
        # 참고: gpt-4o-mini가 vision을 지원하지 않는 경우, gpt-4o 또는 gpt-4-turbo를 사용하세요
        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        
        # 이미지와 함께 메시지 생성 (base64 데이터 URI 형식)
        image_url = f"data:{mime_type};base64,{base64_image}"
        message = HumanMessage(
            content=[
                {"type": "text", "text": prompt},
                {
                    "type": "image_url",
                    "image_url": {"url": image_url}
                }
            ]
        )
        
        # 이미지 분석 수행
        response = llm.invoke([message])
        return response.content
        
    except Exception as e:
        return f"이미지 분석 중 오류가 발생했습니다: {str(e)}"


def create_agent_instance(rag_store: Optional[RAGStore] = None):
    """
    LangChain v1.0의 create_agent를 사용하여 멀티모달 AI 에이전트를 생성합니다.
    
    Args:
        rag_store: RAG 스토어 인스턴스 (None인 경우 도구에서 사용 불가)
        
    Returns:
        에이전트 인스턴스 (LangChain v1.0 create_agent)
    """
    # RAG 스토어 설정
    if rag_store:
        set_rag_store(rag_store)
    
    # 도구 가져오기
    tools = get_tools()
    
    # 시스템 프롬프트 정의
    system_prompt = """당신은 유용한 AI 어시스턴트입니다.
사용자의 요청에 따라 적절한 도구를 사용하여 작업을 수행할 수 있습니다.

사용 가능한 도구:
- summarize_doc: 문서를 요약합니다.
- extract_keywords: 텍스트에서 핵심 키워드를 추출합니다.
- search_docs: RAG 기반으로 문서를 검색합니다.

사용자의 요청을 분석하고, 필요한 경우 적절한 도구를 사용하여 답변을 제공하세요.
한국어로 친절하고 명확하게 답변해주세요."""
    
    # LangChain v1.0의 create_agent 사용
    # 모델은 문자열 또는 ChatOpenAI 인스턴스를 전달할 수 있음
    agent = create_agent(
        model=ChatOpenAI(model="gpt-4o-mini", temperature=0),
        tools=tools,
        system_prompt=system_prompt
    )
    
    return agent


def run_agent(agent, user_input: str, chat_history: List = None) -> dict:
    """
    LangChain v1.0 create_agent를 실행하고 결과를 반환합니다.
    
    Args:
        agent: create_agent로 생성된 에이전트 인스턴스
        user_input: 사용자 입력
        chat_history: 대화 기록 (선택사항)
        
    Returns:
        에이전트 실행 결과 딕셔너리
    """
    from langchain_core.messages import HumanMessage, AIMessage
    
    # 메시지 리스트 구성
    messages = []
    
    # 채팅 히스토리 추가
    if chat_history:
        for msg in chat_history:
            if msg.get("role") == "user":
                messages.append(HumanMessage(content=msg.get("content", "")))
            elif msg.get("role") == "assistant":
                messages.append(AIMessage(content=msg.get("content", "")))
    
    # 현재 사용자 입력 추가
    messages.append(HumanMessage(content=user_input))
    
    # LangChain v1.0 방식으로 에이전트 실행
    result = agent.invoke({
        "messages": messages
    })
    
    return result

