#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YouTube AI Analyzer GUI
유튜브 영상의 스크립트를 추출하고 AI로 분석하여 다양한 형태로 저장하는 GUI 앱
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import threading
from datetime import datetime
import os
import json
from openai import OpenAI
from dotenv import load_dotenv

# 기존 모듈들 import
from youtube_transcript_fetcher import extract_video_id, get_transcript, format_transcript

class YouTubeAIAnalyzerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("YouTube AI Analyzer")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f0f0f0')
        
        # OpenAI 클라이언트 초기화
        self.init_openai()
        
        # 변수들
        self.current_transcript_data = None
        self.current_video_id = None
        self.analysis_results = {}
        
        self.setup_ui()
        
    def init_openai(self):
        """OpenAI 클라이언트 초기화"""
        try:
            load_dotenv("C:/env/.env")
            self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
            self.openai_available = True
        except Exception as e:
            self.openai_available = False
            print(f"OpenAI 초기화 실패: {e}")
    
    def setup_ui(self):
        """UI 구성"""
        # 메인 프레임
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 제목
        title_label = ttk.Label(main_frame, text="YouTube AI Analyzer", 
                               font=('Arial', 18, 'bold'))
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        # URL 입력 섹션
        url_frame = ttk.LabelFrame(main_frame, text="YouTube URL 입력", padding="10")
        url_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.url_var = tk.StringVar()
        url_entry = ttk.Entry(url_frame, textvariable=self.url_var, width=70)
        url_entry.grid(row=0, column=0, padx=(0, 10))
        
        fetch_btn = ttk.Button(url_frame, text="스크립트 추출", 
                              command=self.fetch_transcript)
        fetch_btn.grid(row=0, column=1)
        
        # 비디오 정보 섹션
        info_frame = ttk.LabelFrame(main_frame, text="비디오 정보", padding="10")
        info_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.info_text = scrolledtext.ScrolledText(info_frame, height=3, width=100)
        self.info_text.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        # 탭 컨트롤
        notebook = ttk.Notebook(main_frame)
        notebook.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        # 스크립트 미리보기 탭
        self.script_frame = ttk.Frame(notebook)
        notebook.add(self.script_frame, text="스크립트 미리보기")
        
        self.script_text = scrolledtext.ScrolledText(self.script_frame, height=15, width=100)
        self.script_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # AI 분석 결과 탭
        self.analysis_frame = ttk.Frame(notebook)
        notebook.add(self.analysis_frame, text="AI 분석 결과")
        
        # 분석 결과를 위한 스크롤 텍스트
        self.analysis_text = scrolledtext.ScrolledText(self.analysis_frame, height=15, width=100)
        self.analysis_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 진행 상황 표시
        self.progress_var = tk.StringVar(value="대기 중...")
        progress_label = ttk.Label(main_frame, textvariable=self.progress_var)
        progress_label.grid(row=4, column=0, columnspan=3, pady=(0, 10))
        
        # 버튼 프레임
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=5, column=0, columnspan=3, pady=(0, 10))
        
        # AI 분석 버튼들
        analyze_btn = ttk.Button(button_frame, text="AI 분석 시작", 
                                command=self.start_ai_analysis)
        analyze_btn.grid(row=0, column=0, padx=(0, 5))
        
        save_manual_btn = ttk.Button(button_frame, text="수동 저장", 
                                   command=self.save_all_results)
        save_manual_btn.grid(row=0, column=1, padx=(0, 5))
        
        clear_btn = ttk.Button(button_frame, text="초기화", 
                              command=self.clear_all)
        clear_btn.grid(row=0, column=2, padx=(0, 5))
        
        # OpenAI 상태 표시
        openai_status = "사용 가능" if self.openai_available else "사용 불가"
        status_label = ttk.Label(button_frame, text=f"OpenAI: {openai_status}")
        status_label.grid(row=0, column=3, padx=(10, 0))
        
        # 자동 저장 상태 표시
        self.auto_save_status = ttk.Label(button_frame, text="자동 저장: 활성화", 
                                         foreground="green")
        self.auto_save_status.grid(row=0, column=4, padx=(10, 0))
        
        # 그리드 가중치 설정
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(3, weight=1)
        
    def fetch_transcript(self):
        """유튜브 스크립트 가져오기"""
        url = self.url_var.get().strip()
        if not url:
            messagebox.showerror("오류", "YouTube URL을 입력해주세요.")
            return
            
        # 백그라운드에서 실행
        thread = threading.Thread(target=self._fetch_transcript_thread)
        thread.daemon = True
        thread.start()
        
    def _fetch_transcript_thread(self):
        """스크립트 가져오기 스레드"""
        try:
            self.progress_var.set("스크립트 가져오는 중...")
            
            # URL에서 비디오 ID 추출
            video_id = extract_video_id(self.url_var.get())
            if not video_id:
                self.root.after(0, lambda: messagebox.showerror("오류", "유효하지 않은 YouTube URL입니다."))
                return
                
            # 스크립트 가져오기
            transcript_data = get_transcript(video_id)
            
            if not transcript_data:
                self.root.after(0, lambda: messagebox.showerror("오류", "자막을 가져올 수 없습니다. 해당 영상에 자막이 없거나 접근할 수 없습니다."))
                return
            
            self.current_transcript_data = transcript_data
            self.current_video_id = video_id
            
            # 스크립트 포맷팅
            formatted_transcript = format_transcript(transcript_data)
            
            # UI 업데이트
            info_text = f"비디오 ID: {video_id}\n"
            info_text += f"자막 개수: {len(transcript_data)}개\n"
            if transcript_data:
                total_duration = transcript_data[-1]['start'] + transcript_data[-1]['duration']
                info_text += f"총 영상 길이: {int(total_duration // 60)}분 {int(total_duration % 60)}초"
            
            self.root.after(0, lambda: self.info_text.delete(1.0, tk.END))
            self.root.after(0, lambda: self.info_text.insert(1.0, info_text))
            
            self.root.after(0, lambda: self.script_text.delete(1.0, tk.END))
            self.root.after(0, lambda: self.script_text.insert(1.0, formatted_transcript))
            
            self.root.after(0, lambda: self.progress_var.set("스크립트 가져오기 완료 - AI 분석을 시작할 수 있습니다"))
            
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("오류", f"스크립트 가져오기 실패: {str(e)}"))
            self.root.after(0, lambda: self.progress_var.set("오류 발생"))
    
    def start_ai_analysis(self):
        """AI 분석 시작"""
        if not self.current_transcript_data:
            messagebox.showerror("오류", "먼저 스크립트를 가져와주세요.")
            return
            
        if not self.openai_available:
            messagebox.showerror("오류", "OpenAI API가 사용 불가능합니다. API 키를 확인해주세요.")
            return
            
        # 백그라운드에서 실행
        thread = threading.Thread(target=self._ai_analysis_thread)
        thread.daemon = True
        thread.start()
    
    def _ai_analysis_thread(self):
        """AI 분석 스레드"""
        try:
            self.progress_var.set("AI 분석 중...")
            
            # 스크립트 텍스트 준비
            script_text = format_transcript(self.current_transcript_data)
            
            # 각 분석 작업 수행
            analyses = {}
            
            # 1. 전체 요약
            self.root.after(0, lambda: self.progress_var.set("전체 요약 생성 중..."))
            summary_result = self._generate_summary(script_text)
            analyses['summary'] = summary_result
            self.root.after(0, lambda: self._update_analysis_display("전체 요약", summary_result))
            
            # 2. 핵심 주제 추출
            self.root.after(0, lambda: self.progress_var.set("핵심 주제 추출 중..."))
            topics_result = self._extract_topics(script_text)
            analyses['topics'] = topics_result
            self.root.after(0, lambda: self._update_analysis_display("핵심 주제 추출", topics_result))
            
            # 3. 5분 단위 구간별 요약
            self.root.after(0, lambda: self.progress_var.set("구간별 요약 생성 중..."))
            segments_result = self._generate_segment_summaries(script_text)
            analyses['segments'] = segments_result
            self.root.after(0, lambda: self._update_analysis_display("구간별 요약", segments_result))
            
            # 4. FAQ 생성
            self.root.after(0, lambda: self.progress_var.set("FAQ 생성 중..."))
            faq_result = self._generate_faq(script_text)
            analyses['faq'] = faq_result
            self.root.after(0, lambda: self._update_analysis_display("FAQ", faq_result))
            
            # 5. 블로그용 요약 글
            self.root.after(0, lambda: self.progress_var.set("블로그용 요약 글 생성 중..."))
            blog_result = self._generate_blog_summary(script_text)
            analyses['blog'] = blog_result
            self.root.after(0, lambda: self._update_analysis_display("블로그용 요약 글", blog_result))
            
            self.analysis_results = analyses
            
            # 자동 저장 실행
            self.root.after(0, lambda: self.progress_var.set("결과 자동 저장 중..."))
            self.root.after(0, lambda: self._auto_save_results())
            
            self.root.after(0, lambda: self.progress_var.set("AI 분석 및 저장 완료"))
            
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("오류", f"AI 분석 실패: {str(e)}"))
            self.root.after(0, lambda: self.progress_var.set("AI 분석 오류 발생"))
    
    def _generate_summary(self, script_text):
        """전체 요약 생성"""
        prompt = f"""
다음 유튜브 영상의 스크립트를 분석하여 간결하고 명확한 요약을 작성해주세요.

스크립트:
{script_text}

요약은 다음 형식으로 작성해주세요:
- 영상의 주요 내용 (3-4문장)
- 핵심 메시지
- 시청자에게 전달하고자 하는 목적
"""
        return self._call_openai(prompt)
    
    def _extract_topics(self, script_text):
        """핵심 주제 추출"""
        prompt = f"""
다음 유튜브 영상의 스크립트를 분석하여 핵심 주제들을 추출해주세요.

스크립트:
{script_text}

다음 형식으로 작성해주세요:
주요 주제:
1. [주제명] - [간단한 설명]
2. [주제명] - [간단한 설명]
3. [주제명] - [간단한 설명]

키워드:
- [키워드1], [키워드2], [키워드3], ...
"""
        return self._call_openai(prompt)
    
    def _generate_segment_summaries(self, script_text):
        """5분 단위 구간별 요약 생성"""
        prompt = f"""
다음 유튜브 영상의 스크립트를 5분 단위로 나누어 각 구간의 요약을 작성해주세요.

스크립트:
{script_text}

다음 형식으로 작성해주세요:
구간별 요약:

[0-5분]
- 주요 내용: [내용 요약]
- 핵심 포인트: [핵심 포인트]

[5-10분]
- 주요 내용: [내용 요약]
- 핵심 포인트: [핵심 포인트]

[10-15분]
- 주요 내용: [내용 요약]
- 핵심 포인트: [핵심 포인트]

(영상 길이에 따라 구간 수 조정)
"""
        return self._call_openai(prompt)
    
    def _generate_faq(self, script_text):
        """FAQ 생성"""
        prompt = f"""
다음 유튜브 영상의 스크립트를 바탕으로 시청자들이 자주 묻는 질문과 답변을 생성해주세요.

스크립트:
{script_text}

다음 형식으로 작성해주세요:
자주 묻는 질문과 답변 (FAQ):

Q1. [질문]
A1. [답변]

Q2. [질문]
A2. [답변]

Q3. [질문]
A3. [답변]

(5-7개의 질문과 답변 생성)
"""
        return self._call_openai(prompt)
    
    def _generate_blog_summary(self, script_text):
        """블로그용 요약 글 생성"""
        prompt = f"""
다음 유튜브 영상의 스크립트를 바탕으로 블로그 포스트용 요약 글을 작성해주세요.

스크립트:
{script_text}

다음 형식으로 작성해주세요:
# [영상 제목 추정]

## 개요
[영상의 전체적인 내용과 목적]

## 주요 내용
[상세한 내용 정리]

## 핵심 포인트
- [포인트 1]
- [포인트 2]
- [포인트 3]

## 결론
[영상을 시청한 후 얻을 수 있는 인사이트나 결론]

## 태그
#유튜브 #영상분석 #[관련태그들]
"""
        return self._call_openai(prompt)
    
    def _call_openai(self, prompt):
        """OpenAI API 호출"""
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "당신은 유튜브 영상 스크립트 분석 전문가입니다. 주어진 스크립트를 분석하여 요청된 형식으로 정확하고 유용한 정보를 제공합니다."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3
            )
            return response.choices[0].message.content
        except Exception as e:
            return f"OpenAI API 호출 오류: {str(e)}"
    
    def _update_analysis_display(self, analysis_type, content):
        """개별 분석 결과를 실시간으로 UI에 추가"""
        # 현재 텍스트 끝에 새로운 분석 결과 추가
        current_text = self.analysis_text.get(1.0, tk.END)
        
        # 이미 해당 분석이 있는지 확인하고 업데이트
        if f"={analysis_type}=" in current_text:
            # 기존 내용을 찾아서 교체
            lines = current_text.split('\n')
            new_lines = []
            skip_until_next_section = False
            
            for line in lines:
                if f"={analysis_type}=" in line:
                    skip_until_next_section = True
                    new_lines.append("=" * 50)
                    new_lines.append(analysis_type)
                    new_lines.append("=" * 50)
                    new_lines.append(content)
                    new_lines.append("")
                    continue
                elif skip_until_next_section and line.startswith("=") and "=" in line[1:]:
                    skip_until_next_section = False
                    new_lines.append(line)
                elif not skip_until_next_section:
                    new_lines.append(line)
            
            new_text = '\n'.join(new_lines)
        else:
            # 새로운 분석 결과 추가
            new_text = current_text.rstrip() + "\n\n" + "=" * 50 + "\n"
            new_text += analysis_type + "\n"
            new_text += "=" * 50 + "\n"
            new_text += content + "\n"
        
        self.analysis_text.delete(1.0, tk.END)
        self.analysis_text.insert(1.0, new_text)
        # 스크롤을 맨 아래로 이동
        self.analysis_text.see(tk.END)
    
    def _display_analysis_results(self):
        """분석 결과를 UI에 표시"""
        result_text = ""
        
        if 'summary' in self.analysis_results:
            result_text += "=" * 50 + "\n"
            result_text += "전체 요약\n"
            result_text += "=" * 50 + "\n"
            result_text += self.analysis_results['summary'] + "\n\n"
        
        if 'topics' in self.analysis_results:
            result_text += "=" * 50 + "\n"
            result_text += "핵심 주제 추출\n"
            result_text += "=" * 50 + "\n"
            result_text += self.analysis_results['topics'] + "\n\n"
        
        if 'segments' in self.analysis_results:
            result_text += "=" * 50 + "\n"
            result_text += "구간별 요약 (5분 단위)\n"
            result_text += "=" * 50 + "\n"
            result_text += self.analysis_results['segments'] + "\n\n"
        
        if 'faq' in self.analysis_results:
            result_text += "=" * 50 + "\n"
            result_text += "자주 묻는 질문과 답변 (FAQ)\n"
            result_text += "=" * 50 + "\n"
            result_text += self.analysis_results['faq'] + "\n\n"
        
        if 'blog' in self.analysis_results:
            result_text += "=" * 50 + "\n"
            result_text += "블로그용 요약 글\n"
            result_text += "=" * 50 + "\n"
            result_text += self.analysis_results['blog'] + "\n\n"
        
        self.root.after(0, lambda: self.analysis_text.delete(1.0, tk.END))
        self.root.after(0, lambda: self.analysis_text.insert(1.0, result_text))
    
    def _auto_save_results(self):
        """자동으로 결과 저장 (영상 ID별 폴더 생성)"""
        if not self.analysis_results:
            return
        
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            video_id = self.current_video_id or "unknown"
            
            # 현재 디렉토리에 영상 ID별 폴더 생성
            save_dir = os.path.join(os.getcwd(), "results", video_id)
            os.makedirs(save_dir, exist_ok=True)
            
            # 각 분석 결과를 별도 파일로 저장
            for analysis_type, content in self.analysis_results.items():
                filename = f"{analysis_type}_{timestamp}.txt"
                filepath = os.path.join(save_dir, filename)
                
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
            
            # 전체 결과를 하나의 파일로도 저장
            all_results_file = os.path.join(save_dir, f"all_results_{timestamp}.txt")
            with open(all_results_file, 'w', encoding='utf-8') as f:
                f.write("YouTube AI 분석 결과\n")
                f.write("=" * 50 + "\n\n")
                f.write(f"비디오 ID: {video_id}\n")
                f.write(f"분석 일시: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                
                for analysis_type, content in self.analysis_results.items():
                    f.write(f"\n{'=' * 50}\n")
                    f.write(f"{analysis_type.upper()}\n")
                    f.write(f"{'=' * 50}\n")
                    f.write(content)
                    f.write(f"\n\n")
            
            # 원본 스크립트도 저장
            if self.current_transcript_data:
                script_file = os.path.join(save_dir, f"original_script_{timestamp}.txt")
                with open(script_file, 'w', encoding='utf-8') as f:
                    f.write(format_transcript(self.current_transcript_data))
            
            # 저장 완료 메시지 및 상태 업데이트
            self.root.after(0, lambda: self.auto_save_status.config(text="자동 저장: 완료", foreground="blue"))
            self.root.after(0, lambda: messagebox.showinfo("저장 완료", 
                f"모든 결과가 자동으로 저장되었습니다:\n{save_dir}"))
            
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("오류", f"자동 저장 실패: {str(e)}"))
    
    def save_all_results(self):
        """수동으로 모든 결과 저장 (기존 기능 유지)"""
        if not self.analysis_results:
            messagebox.showerror("오류", "먼저 AI 분석을 수행해주세요.")
            return
        
        # 저장할 디렉토리 선택
        save_dir = filedialog.askdirectory(title="결과 저장할 폴더 선택")
        if not save_dir:
            return
        
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            video_id = self.current_video_id or "unknown"
            
            # 영상 ID별 폴더 생성
            video_folder = os.path.join(save_dir, video_id)
            os.makedirs(video_folder, exist_ok=True)
            
            # 각 분석 결과를 별도 파일로 저장
            for analysis_type, content in self.analysis_results.items():
                filename = f"{analysis_type}_{timestamp}.txt"
                filepath = os.path.join(video_folder, filename)
                
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
            
            # 전체 결과를 하나의 파일로도 저장
            all_results_file = os.path.join(video_folder, f"all_results_{timestamp}.txt")
            with open(all_results_file, 'w', encoding='utf-8') as f:
                f.write("YouTube AI 분석 결과\n")
                f.write("=" * 50 + "\n\n")
                f.write(f"비디오 ID: {video_id}\n")
                f.write(f"분석 일시: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                
                for analysis_type, content in self.analysis_results.items():
                    f.write(f"\n{'=' * 50}\n")
                    f.write(f"{analysis_type.upper()}\n")
                    f.write(f"{'=' * 50}\n")
                    f.write(content)
                    f.write(f"\n\n")
            
            # 원본 스크립트도 저장
            if self.current_transcript_data:
                script_file = os.path.join(video_folder, f"original_script_{timestamp}.txt")
                with open(script_file, 'w', encoding='utf-8') as f:
                    f.write(format_transcript(self.current_transcript_data))
            
            messagebox.showinfo("성공", f"모든 결과가 저장되었습니다:\n{video_folder}")
            
        except Exception as e:
            messagebox.showerror("오류", f"파일 저장 실패: {str(e)}")
    
    def clear_all(self):
        """모든 내용 초기화"""
        self.url_var.set("")
        self.info_text.delete(1.0, tk.END)
        self.script_text.delete(1.0, tk.END)
        self.analysis_text.delete(1.0, tk.END)
        self.progress_var.set("대기 중...")
        self.current_transcript_data = None
        self.current_video_id = None
        self.analysis_results = {}
        self.auto_save_status.config(text="자동 저장: 활성화", foreground="green")

def main():
    root = tk.Tk()
    app = YouTubeAIAnalyzerGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
