import pandas as pd
from estimate_reader import get_dataframes
import os

def save_comparison_results():
    """
    비교 결과를 Excel 파일과 CSV 파일로 저장하는 함수
    """
    # DataFrame 가져오기
    products_df, conditions_df = get_dataframes()
    
    print("=" * 80)
    print("📁 비교 결과 파일 저장")
    print("=" * 80)
    
    # 1. 단가 비교표 생성
    unit_price_pivot = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values='단가', 
        aggfunc='first'
    )
    
    # 최저가와 최저가 업체 계산
    unit_price_pivot['최저가'] = unit_price_pivot.min(axis=1)
    unit_price_pivot['최저가업체'] = unit_price_pivot.iloc[:, :-1].idxmin(axis=1)
    
    # 2. 총액 비교표 생성
    total_price_pivot = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values='총액', 
        aggfunc='first'
    )
    
    # 최저가와 최저가 업체 계산
    total_price_pivot['최저가'] = total_price_pivot.min(axis=1)
    total_price_pivot['최저가업체'] = total_price_pivot.iloc[:, :-1].idxmin(axis=1)
    
    # 3. 업체별 상세 조건 요약표 생성
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values()
    
    # 업체별 상세 정보 DataFrame 생성
    company_details = []
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        company_products = products_df[products_df['업체명'] == company]
        total_amount = company_products['총액'].sum()
        
        company_details.append({
            '업체명': company,
            '총견적액': total_amount,
            '제품특장점': row['제품특장점'].replace('제품 특장점: ', ''),
            '납품조건': row['납품조건'].replace('납품 조건: ', ''),
            'A/S안내': row['A/S안내'].replace('A/S 안내: ', '')
        })
    
    company_details_df = pd.DataFrame(company_details)
    
    # 4. 품목별 최저가 요약표 생성
    summary_data = []
    for product in unit_price_pivot.index:
        min_unit_price = unit_price_pivot.loc[product, '최저가']
        min_unit_company = unit_price_pivot.loc[product, '최저가업체']
        min_total_price = total_price_pivot.loc[product, '최저가']
        min_total_company = total_price_pivot.loc[product, '최저가업체']
        
        summary_data.append({
            '품목': product,
            '단가최저가': min_unit_price,
            '단가최저가업체': min_unit_company,
            '총액최저가': min_total_price,
            '총액최저가업체': min_total_company
        })
    
    summary_df = pd.DataFrame(summary_data)
    
    # 5. 업체별 경쟁력 분석 생성
    unit_wins = unit_price_pivot['최저가업체'].value_counts()
    total_wins = total_price_pivot['최저가업체'].value_counts()
    
    competitiveness_data = []
    for company in company_totals.index:
        unit_count = unit_wins.get(company, 0)
        total_count = total_wins.get(company, 0)
        total_amount = company_totals[company]
        
        competitiveness_data.append({
            '업체명': company,
            '총견적액': total_amount,
            '단가최저가품목수': unit_count,
            '총액최저가품목수': total_count,
            '가격순위': list(company_totals.index).index(company) + 1
        })
    
    competitiveness_df = pd.DataFrame(competitiveness_data)
    
    # 6. Excel 파일로 저장
    excel_filename = '비교결과.xlsx'
    
    with pd.ExcelWriter(excel_filename, engine='openpyxl') as writer:
        # 시트 1: 단가 비교표
        unit_price_pivot.to_excel(writer, sheet_name='단가비교표')
        
        # 시트 2: 총액 비교표
        total_price_pivot.to_excel(writer, sheet_name='총액비교표')
        
        # 시트 3: 업체별 상세 조건
        company_details_df.to_excel(writer, sheet_name='업체별상세조건', index=False)
        
        # 시트 4: 품목별 최저가 요약
        summary_df.to_excel(writer, sheet_name='품목별최저가요약', index=False)
        
        # 시트 5: 업체별 경쟁력 분석
        competitiveness_df.to_excel(writer, sheet_name='업체별경쟁력분석', index=False)
        
        # 시트 6: 원본 제품 데이터
        products_df.to_excel(writer, sheet_name='원본제품데이터', index=False)
    
    print(f"✅ Excel 파일 저장 완료: {excel_filename}")
    
    # 7. CSV 파일로 저장
    csv_filename = '단가비교.csv'
    unit_price_pivot.to_csv(csv_filename, encoding='utf-8-sig')
    print(f"✅ CSV 파일 저장 완료: {csv_filename}")
    
    # 8. 추가 CSV 파일들 저장
    # 총액 비교표
    total_price_pivot.to_csv('총액비교.csv', encoding='utf-8-sig')
    print("✅ CSV 파일 저장 완료: 총액비교.csv")
    
    # 업체별 상세 조건
    company_details_df.to_csv('업체별상세조건.csv', encoding='utf-8-sig', index=False)
    print("✅ CSV 파일 저장 완료: 업체별상세조건.csv")
    
    # 품목별 최저가 요약
    summary_df.to_csv('품목별최저가요약.csv', encoding='utf-8-sig', index=False)
    print("✅ CSV 파일 저장 완료: 품목별최저가요약.csv")
    
    # 9. 저장된 파일 목록 출력
    print("\n📁 저장된 파일 목록:")
    print("-" * 50)
    
    saved_files = [
        '비교결과.xlsx',
        '단가비교.csv',
        '총액비교.csv',
        '업체별상세조건.csv',
        '품목별최저가요약.csv'
    ]
    
    for file in saved_files:
        if os.path.exists(file):
            file_size = os.path.getsize(file)
            print(f"📄 {file} ({file_size:,} bytes)")
        else:
            print(f"❌ {file} (저장 실패)")
    
    return excel_filename, csv_filename

def create_summary_report():
    """
    저장된 결과에 대한 요약 리포트를 생성하는 함수
    """
    products_df, conditions_df = get_dataframes()
    
    print("\n" + "=" * 80)
    print("📊 저장된 결과 요약 리포트")
    print("=" * 80)
    
    # 기본 통계
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values()
    
    print(f"📈 분석된 업체 수: {len(company_totals)}개")
    print(f"📦 분석된 제품 수: {len(products_df)}개")
    print(f"💰 총 견적액 범위: {company_totals.min():,.0f}원 ~ {company_totals.max():,.0f}원")
    
    print("\n🏆 가격 경쟁력 순위:")
    for i, (company, total) in enumerate(company_totals.items(), 1):
        print(f"   {i}위: {company} - {total:,.0f}원")
    
    print("\n📁 생성된 파일:")
    print("   • 비교결과.xlsx (모든 분석 결과 통합)")
    print("   • 단가비교.csv (단가 비교표)")
    print("   • 총액비교.csv (총액 비교표)")
    print("   • 업체별상세조건.csv (업체별 상세 조건)")
    print("   • 품목별최저가요약.csv (품목별 최저가 요약)")

if __name__ == "__main__":
    # 비교 결과 저장
    excel_file, csv_file = save_comparison_results()
    
    # 요약 리포트 생성
    create_summary_report()
