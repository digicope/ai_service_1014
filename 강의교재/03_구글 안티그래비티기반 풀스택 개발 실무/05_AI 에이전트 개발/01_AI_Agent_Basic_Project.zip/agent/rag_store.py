import os
import glob
from typing import List
from dotenv import load_dotenv

# 최신 LangChain 분리 패키지 import
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader
from langchain_chroma import Chroma

# 환경 변수 로드 (C:\env\.env 경로 우선)
ENV_PATH = r"C:\env\.env"
if os.path.exists(ENV_PATH):
    load_dotenv(dotenv_path=ENV_PATH)
else:
    load_dotenv()

# ChromaDB 저장 디렉토리 및 컬렉션 이름 설정
CHROMA_PERSIST_DIR = os.path.abspath("./chroma_db")
COLLECTION_NAME = "pdf_rag_collection"

_VECTOR_STORE = None

def get_embedding_model(model_name: str = "gemini-embedding-001"):
    """Gemini 최신 텍스트 임베딩 모델 반환"""
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    return GoogleGenerativeAIEmbeddings(
        model=model_name,
        google_api_key=api_key
    )

def load_pdf_documents(pdf_dir: str = "pdf_data") -> List[Document]:
    """
    pdf_data 폴더 내 모든 PDF 파일을 읽어 Document 리스트로 반환합니다.
    PyPDFLoader를 통해 각 페이지별 텍스트 및 페이지 메타데이터(page)를 추출합니다.
    """
    pdf_files = glob.glob(os.path.join(pdf_dir, "*.pdf"))
    if not pdf_files:
        print(f"경고: {pdf_dir} 폴더에 PDF 파일이 없습니다.")
        return []

    documents = []
    for pdf_path in pdf_files:
        try:
            loader = PyPDFLoader(pdf_path)
            loaded_docs = loader.load()
            # 메타데이터의 source를 파일명(basename)으로 정제
            for doc in loaded_docs:
                doc.metadata["source"] = os.path.basename(doc.metadata.get("source", pdf_path))
            documents.extend(loaded_docs)
            print(f"로드 완료: {os.path.basename(pdf_path)} ({len(loaded_docs)} 페이지)")
        except Exception as e:
            print(f"PDF 로드 실패 ({pdf_path}): {e}")

    return documents

def build_vector_store(pdf_dir: str = "pdf_data", persist_dir: str = CHROMA_PERSIST_DIR) -> Chroma:
    """
    pdf_data의 PDF들을 로드/분할하여 ChromaDB 벡터스토어를 구축하고 디스크에 저장(persist)합니다.
    """
    global _VECTOR_STORE
    
    # 1. PDF 문서 로드
    raw_docs = load_pdf_documents(pdf_dir)
    if not raw_docs:
        # PDF 파일이 없을 경우 기본 폴백 문서
        raw_docs = [
            Document(
                page_content="등록된 PDF 문서가 없습니다. pdf_data 폴더에 PDF를 추가해주세요.",
                metadata={"source": "sample_fallback.pdf", "page": 0}
            )
        ]

    # 2. 텍스트 청크 분할 (메타데이터 유지)
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50,
        separators=["\n\n", "\n", " ", ""]
    )
    split_docs = text_splitter.split_documents(raw_docs)

    # 3. 임베딩 모델 준비 및 ChromaDB 생성 & 저장
    embeddings = get_embedding_model()
    _VECTOR_STORE = Chroma.from_documents(
        documents=split_docs,
        embedding=embeddings,
        collection_name=COLLECTION_NAME,
        persist_directory=persist_dir
    )
    return _VECTOR_STORE

def get_vector_store(pdf_dir: str = "pdf_data", persist_dir: str = CHROMA_PERSIST_DIR) -> Chroma:
    """
    기존 ChromaDB가 디스크에 저장되어 있으면 읽어와 재사용하고,
    없으면 새로 생성(build)하여 반환합니다.
    """
    global _VECTOR_STORE
    if _VECTOR_STORE is not None:
        return _VECTOR_STORE

    embeddings = get_embedding_model()
    
    # 기존 Chroma DB 디렉토리가 존재하는지 확인
    if os.path.exists(persist_dir) and os.listdir(persist_dir):
        try:
            _VECTOR_STORE = Chroma(
                collection_name=COLLECTION_NAME,
                embedding_function=embeddings,
                persist_directory=persist_dir
            )
            # 저장소에 문서가 있는지 확인
            count = _VECTOR_STORE._collection.count()
            if count > 0:
                print(f"기존 ChromaDB를 성공적으로 로드했습니다. (저장된 청크 수: {count})")
                return _VECTOR_STORE
        except Exception as e:
            print(f"기존 ChromaDB 로드 실패, 새로 생성합니다: {e}")

    # 기존 DB가 없거나 비어있는 경우 새로 구축
    return build_vector_store(pdf_dir, persist_dir)

def search_documents(query: str, k: int = 3) -> str:
    """
    사용자 쿼리와 가장 유사한 PDF 문서 내용을 검색하고,
    출처 파일명 및 페이지 번호를 포맷팅하여 반환합니다.
    """
    store = get_vector_store()
    results = store.similarity_search(query, k=k)
    
    if not results:
        return "검색 결과가 없습니다."
    
    formatted_results = []
    for i, doc in enumerate(results, start=1):
        source = doc.metadata.get("source", "알 수 없음")
        # PyPDFLoader는 0부터 페이지를 인덱싱하므로 +1하여 사용자 친화적 1-based 페이지 표기
        raw_page = doc.metadata.get("page", 0)
        page_num = raw_page + 1 if isinstance(raw_page, int) else raw_page
        
        content = doc.page_content.strip()
        
        formatted_results.append(
            f"[{i}] 출처: {source} (페이지: {page_num}p)\n"
            f"내용:\n{content}"
        )
    
    return "\n\n" + ("=" * 40) + "\n\n".join(formatted_results)
