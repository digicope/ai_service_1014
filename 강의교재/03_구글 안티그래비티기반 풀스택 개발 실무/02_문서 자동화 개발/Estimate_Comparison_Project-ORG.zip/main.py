#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
견적서 비교 분석 시스템 - 메인 실행 파일
작성자: AI Assistant
날짜: 2025년
"""

import os
import sys
import time
from datetime import datetime

# 프로젝트 모듈 import
from estimate_reader import get_dataframes, display_results
from enhanced_pivot import create_enhanced_pivot_tables
from clean_summary import create_clean_company_summary
from final_comparison import create_final_comparison
from save_results import save_comparison_results
from create_chart import create_vendor_totals_chart, create_detailed_chart, create_pie_chart

def print_header():
    """프로그램 헤더 출력"""
    print("=" * 80)
    print("📊 견적서 비교 분석 시스템")
    print("=" * 80)
    print(f"실행 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

def print_menu():
    """메뉴 출력"""
    print("\n📋 메뉴를 선택하세요:")
    print("-" * 50)
    print("1. 전체 분석 실행 (모든 기능 순차 실행)")
    print("2. 기본 데이터 읽기 및 표시")
    print("3. PivotTable 분석 (최저가 포함)")
    print("4. 업체별 상세 조건 요약")
    print("5. 종합 비교 분석")
    print("6. 결과 파일 저장 (Excel, CSV)")
    print("7. 막대그래프 생성")
    print("8. 개별 기능 실행")
    print("9. 프로그램 종료")
    print("-" * 50)

def run_full_analysis():
    """전체 분석 실행"""
    print("\n🚀 전체 분석을 시작합니다...")
    print("=" * 80)
    
    try:
        # 1. 기본 데이터 읽기 및 표시
        print("\n📊 1단계: 기본 데이터 읽기 및 표시")
        print("-" * 50)
        display_results()
        time.sleep(2)
        
        # 2. PivotTable 분석
        print("\n📊 2단계: PivotTable 분석 (최저가 포함)")
        print("-" * 50)
        unit_pivot, total_pivot, summary_df = create_enhanced_pivot_tables()
        time.sleep(2)
        
        # 3. 업체별 상세 조건 요약
        print("\n📊 3단계: 업체별 상세 조건 요약")
        print("-" * 50)
        create_clean_company_summary()
        time.sleep(2)
        
        # 4. 종합 비교 분석
        print("\n📊 4단계: 종합 비교 분석")
        print("-" * 50)
        create_final_comparison()
        time.sleep(2)
        
        # 5. 결과 파일 저장
        print("\n📊 5단계: 결과 파일 저장")
        print("-" * 50)
        excel_file, csv_file = save_comparison_results()
        time.sleep(2)
        
        # 6. 막대그래프 생성
        print("\n📊 6단계: 막대그래프 생성")
        print("-" * 50)
        create_vendor_totals_chart()
        create_detailed_chart()
        create_pie_chart()
        
        print("\n✅ 전체 분석이 완료되었습니다!")
        print("=" * 80)
        
    except Exception as e:
        print(f"❌ 오류 발생: {e}")
        return False
    
    return True

def run_individual_functions():
    """개별 기능 실행"""
    print("\n🔧 개별 기능을 선택하세요:")
    print("-" * 50)
    print("1. 기본 데이터 읽기")
    print("2. PivotTable 분석")
    print("3. 업체별 요약")
    print("4. 종합 비교")
    print("5. 파일 저장")
    print("6. 막대그래프")
    print("7. 상세 그래프")
    print("8. 파이차트")
    print("9. 뒤로 가기")
    
    choice = input("\n선택 (1-9): ").strip()
    
    try:
        if choice == "1":
            display_results()
        elif choice == "2":
            create_enhanced_pivot_tables()
        elif choice == "3":
            create_clean_company_summary()
        elif choice == "4":
            create_final_comparison()
        elif choice == "5":
            save_comparison_results()
        elif choice == "6":
            create_vendor_totals_chart()
        elif choice == "7":
            create_detailed_chart()
        elif choice == "8":
            create_pie_chart()
        elif choice == "9":
            return
        else:
            print("❌ 잘못된 선택입니다.")
            return
    except Exception as e:
        print(f"❌ 오류 발생: {e}")

def check_files():
    """필요한 파일들이 있는지 확인"""
    required_files = [
        "A컴퍼니_견적서.xlsx",
        "B테크_견적서.xlsx", 
        "C솔루션_견적서.xlsx"
    ]
    
    missing_files = []
    for file in required_files:
        if not os.path.exists(file):
            missing_files.append(file)
    
    if missing_files:
        print("❌ 다음 파일들이 없습니다:")
        for file in missing_files:
            print(f"   - {file}")
        print("\n견적서 파일들을 현재 폴더에 넣어주세요.")
        return False
    
    return True

def show_file_status():
    """생성된 파일들의 상태 표시"""
    print("\n📁 생성된 파일 목록:")
    print("-" * 50)
    
    files_to_check = [
        ("비교결과.xlsx", "Excel 통합 파일"),
        ("단가비교.csv", "단가 비교 CSV"),
        ("총액비교.csv", "총액 비교 CSV"),
        ("업체별상세조건.csv", "업체별 상세 조건 CSV"),
        ("품목별최저가요약.csv", "품목별 최저가 요약 CSV"),
        ("totals_by_vendor.png", "막대그래프"),
        ("totals_by_vendor_detailed.png", "상세 그래프"),
        ("totals_by_vendor_pie.png", "파이차트")
    ]
    
    for filename, description in files_to_check:
        if os.path.exists(filename):
            file_size = os.path.getsize(filename)
            print(f"✅ {filename} - {description} ({file_size:,} bytes)")
        else:
            print(f"❌ {filename} - {description} (없음)")

def main():
    """메인 함수"""
    print_header()
    
    # 필요한 파일 확인
    if not check_files():
        input("\nEnter 키를 눌러 종료...")
        return
    
    while True:
        print_menu()
        choice = input("\n선택 (1-9): ").strip()
        
        if choice == "1":
            # 전체 분석 실행
            if run_full_analysis():
                show_file_status()
                input("\nEnter 키를 눌러 계속...")
        
        elif choice == "2":
            # 기본 데이터 읽기 및 표시
            display_results()
            input("\nEnter 키를 눌러 계속...")
        
        elif choice == "3":
            # PivotTable 분석
            create_enhanced_pivot_tables()
            input("\nEnter 키를 눌러 계속...")
        
        elif choice == "4":
            # 업체별 상세 조건 요약
            create_clean_company_summary()
            input("\nEnter 키를 눌러 계속...")
        
        elif choice == "5":
            # 종합 비교 분석
            create_final_comparison()
            input("\nEnter 키를 눌러 계속...")
        
        elif choice == "6":
            # 결과 파일 저장
            save_comparison_results()
            show_file_status()
            input("\nEnter 키를 눌러 계속...")
        
        elif choice == "7":
            # 막대그래프 생성
            create_vendor_totals_chart()
            create_detailed_chart()
            create_pie_chart()
            show_file_status()
            input("\nEnter 키를 눌러 계속...")
        
        elif choice == "8":
            # 개별 기능 실행
            run_individual_functions()
        
        elif choice == "9":
            # 프로그램 종료
            print("\n👋 프로그램을 종료합니다.")
            print("=" * 80)
            break
        
        else:
            print("❌ 잘못된 선택입니다. 1-9 중에서 선택해주세요.")
            time.sleep(1)

def quick_run():
    """빠른 실행 (전체 분석만)"""
    print_header()
    
    if not check_files():
        return
    
    print("\n🚀 빠른 실행 모드 - 전체 분석을 시작합니다...")
    run_full_analysis()
    show_file_status()

if __name__ == "__main__":
    try:
        # 명령행 인수가 있으면 빠른 실행
        if len(sys.argv) > 1 and sys.argv[1] == "--quick":
            quick_run()
        else:
            # 일반 실행 (메뉴 모드)
            main()
    except KeyboardInterrupt:
        print("\n\n👋 사용자에 의해 프로그램이 종료되었습니다.")
    except Exception as e:
        print(f"\n❌ 예상치 못한 오류가 발생했습니다: {e}")
        print("프로그램을 다시 실행해주세요.")
