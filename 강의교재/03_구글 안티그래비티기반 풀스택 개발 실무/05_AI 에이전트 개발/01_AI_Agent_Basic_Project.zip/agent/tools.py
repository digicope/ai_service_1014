import os
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI
from agent.rag_store import search_documents

# 요약/키워드 추출 내부 보조용 LLM 인스턴스
def _get_helper_llm():
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    return ChatGoogleGenerativeAI(
        model="gemini-3.5-flash",
        temperature=0.2,
        google_api_key=api_key
    )

def _clean_content(content) -> str:
    """도구 실행 결과의 content에서 extras를 제거하고 순수 텍스트 반환"""
    if isinstance(content, str):
        return content.replace("\\n", "\n").strip()
    elif isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and "text" in item:
                parts.append(str(item["text"]))
        return "\n".join(parts).replace("\\n", "\n").strip()
    elif isinstance(content, dict):
        return str(content.get("text", "")).replace("\\n", "\n").strip()
    return str(content).replace("\\n", "\n").strip()

@tool
def summarize_doc(text: str) -> str:
    """
    제공된 긴 텍스트나 문서의 핵심 내용을 2~4문장으로 간결하게 요약합니다.
    입력(text): 요약할 문서 본문이나 텍스트.
    """
    llm = _get_helper_llm()
    prompt = f"다음 문서를 읽고 핵심 내용을 3문장 이내로 명확하게 요약해줘:\n\n{text}"
    response = llm.invoke(prompt)
    return _clean_content(response.content)

@tool
def extract_keywords(text: str) -> str:
    """
    제공된 텍스트에서 가장 중요한 핵심 키워드 5~7개를 추출하여 반환합니다.
    입력(text): 키워드를 추출할 본문 텍스트.
    """
    llm = _get_helper_llm()
    prompt = f"다음 텍스트에서 가장 핵심적인 키워드 5~7개를 쉼표(,)로 구분하여 나열해줘:\n\n{text}"
    response = llm.invoke(prompt)
    return _clean_content(response.content)

@tool
def search_docs(query: str) -> str:
    """
    ChromaDB 벡터 데이터베이스에서 질문(query)과 가장 관련성이 높은 PDF 문서 내용을 검색합니다.
    검색 결과에는 PDF 파일명과 정확한 페이지 번호(예: 3p)가 포함되어 있습니다.
    PDF 지식 문서(금융상품, 혼잡도 예측, 인공지능 등)와 관련된 질문 시 반드시 이 도구를 호출해야 합니다.
    입력(query): 검색 질의문 (예: '금융상품 추천 방식', '혼잡도 예측 모델')
    """
    return search_documents(query, k=3)

# 에이전트에 등록할 툴 목록
ALL_TOOLS = [summarize_doc, extract_keywords, search_docs]

