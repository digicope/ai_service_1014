import os
import base64
import io
from typing import Union
from PIL import Image
from dotenv import load_dotenv

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_google_genai import ChatGoogleGenerativeAI
from langgraph.prebuilt import create_react_agent

from agent.tools import ALL_TOOLS

# 환경 변수 로드 (C:\env\.env 경로 지정)
ENV_PATH = r"C:\env\.env"
if os.path.exists(ENV_PATH):
    load_dotenv(dotenv_path=ENV_PATH)
else:
    load_dotenv()

def get_agent_llm(model_name: str = "gemini-3.5-flash"):
    """
    Gemini Chat 모델 초기화 (API 키 자동 로드)
    """
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    return ChatGoogleGenerativeAI(
        model=model_name,
        temperature=0.3,
        google_api_key=api_key
    )

def create_multimodal_agent(model_name: str = "gemini-3.5-flash"):
    """
    최신 LangChain / LangGraph 기반의 ReAct Agent를 생성합니다.
    - tools: summarize_doc, extract_keywords, search_docs
    - state 형식: {"messages": [...]}
    - 출력 접근 방식: result["messages"][-1].content
    """
    llm = get_agent_llm(model_name=model_name)
    
    system_prompt = (
        "너는 사용자의 질의를 해결하는 유능한 멀티모달 AI 비서이자 리서치 에이전트야.\n"
        "너에게는 다음과 같은 도구들이 주어져 있어:\n"
        "1. search_docs(query): PDF 지식 문서(ChromaDB)를 검색할 때 사용.\n"
        "2. summarize_doc(text): 긴 문서를 간결하게 3문장으로 요약할 때 사용.\n"
        "3. extract_keywords(text): 텍스트의 핵심 키워드를 추출할 때 사용.\n\n"
        "지식 문서와 관련된 질문을 받으면 반드시 search_docs 도구를 호출하여 검색된 사실에 기반해 답변해줘.\n"
        "★ 중요: search_docs로 얻은 정보로 답변할 때는 반드시 검색 결과에 명시된 출처 파일명과 해당 페이지 번호(예: [출처: xxx.pdf, 3p])를 답변 하단이나 본문에 함께 기재해줘.\n"
        "요약이나 키워드 추출 요청 시에는 각각에 맞는 도구를 반드시 호출해줘.\n"
        "모든 답변은 한국어로 친절하고 명확하게 작성해줘."
    )
    
    agent = create_react_agent(
        model=llm,
        tools=ALL_TOOLS,
        prompt=system_prompt
    )
    return agent

def extract_clean_text(content) -> str:
    """
    메시지 content에서 extras 및 서명 메타데이터를 제거하고 순수 텍스트만 깔끔하게 추출합니다.
    - list/dict 구조에서 'text'만 추출
    - 이스케이프된 개행(\n\n)을 실제 줄바꿈으로 변환
    """
    if isinstance(content, str):
        text = content
    elif isinstance(content, list):
        text_parts = []
        for item in content:
            if isinstance(item, str):
                text_parts.append(item)
            elif isinstance(item, dict):
                # extras 등 메타데이터 제외하고 순수 텍스트만 추출
                if "text" in item and item["text"]:
                    text_parts.append(str(item["text"]))
                elif "content" in item and item["content"]:
                    text_parts.append(str(item["content"]))
        text = "\n".join(text_parts) if text_parts else ""
    elif isinstance(content, dict):
        text = content.get("text") or content.get("content") or ""
    else:
        text = str(content)

    # 문자열 내 이스케이프된 '\\n' 기호를 실제 개행으로 변환
    text = text.replace("\\n", "\n")
    return text.strip()

def analyze_image_caption(image_input: Union[bytes, io.BytesIO, Image.Image, str], prompt: str = "이 이미지의 핵심 객체와 상황을 자세히 설명하고, 간결한 한 줄 캡션을 생성해줘.") -> str:
    """
    이미지 입력을 받아 Google Gemini 멀티모달 모델을 통해 이미지 분석 및 캡션을 생성합니다.
    (추가 질의-2 해결: bytes/PIL Image/경로를 안전하게 Base64로 변환하여 Data URL로 전달)
    """
    llm = get_agent_llm()
    
    # 1. 이미지 바이트 데이터 및 MIME 타입 추출
    mime_type = "image/jpeg"
    
    if isinstance(image_input, bytes):
        raw_bytes = image_input
    elif isinstance(image_input, io.BytesIO):
        raw_bytes = image_input.getvalue()
    elif isinstance(image_input, Image.Image):
        buffered = io.BytesIO()
        image_input.save(buffered, format="JPEG")
        raw_bytes = buffered.getvalue()
    elif isinstance(image_input, str) and os.path.exists(image_input):
        if image_input.lower().endswith(".png"):
            mime_type = "image/png"
        with open(image_input, "rb") as f:
            raw_bytes = f.read()
    else:
        # Streamlit UploadedFile 대응 (read() 메서드 지원 객체)
        if hasattr(image_input, "read"):
            raw_bytes = image_input.read()
            if hasattr(image_input, "seek"):
                image_input.seek(0)
            if hasattr(image_input, "type") and image_input.type:
                mime_type = image_input.type
        else:
            raise ValueError("지원하지 않는 이미지 입력 형식입니다.")

    # 2. Base64 인코딩
    base64_encoded = base64.b64encode(raw_bytes).decode("utf-8")
    data_url = f"data:{mime_type};base64,{base64_encoded}"

    # 3. LangChain 멀티모달 메시지 구성
    message = HumanMessage(
        content=[
            {"type": "text", "text": prompt},
            {
                "type": "image_url",
                "image_url": {"url": data_url}
            }
        ]
    )

    # 4. 모델 호출 및 응답 반환
    response = llm.invoke([message])
    return extract_clean_text(response.content)

def run_agent_query(agent, query: str) -> str:
    """
    에이전트 실행 헬퍼 함수
    마지막 응답을 result["messages"][-1].content 형태로 추출한 뒤,
    extras 및 메타데이터를 제거하고 순수 텍스트로 깔끔하게 반환합니다.
    """
    result = agent.invoke({"messages": [HumanMessage(content=query)]})
    raw_content = result["messages"][-1].content
    return extract_clean_text(raw_content)

