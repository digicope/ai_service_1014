// 메인 페이지 Contact 기능
document.addEventListener('DOMContentLoaded', function() {
    const contactBtn = document.getElementById('contactBtn');
    const modal = document.getElementById('contactModal');
    const closeBtn = document.querySelector('.close');
    const cancelBtn = document.querySelector('.cancel-btn');
    const contactForm = document.getElementById('contactForm');
    
    // Contact 버튼 클릭 시 모달 열기
    contactBtn.addEventListener('click', function() {
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden'; // 스크롤 방지
    });
    
    // 모달 닫기 함수
    function closeModal() {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto'; // 스크롤 복원
        contactForm.reset(); // 폼 초기화
    }
    
    // X 버튼으로 모달 닫기
    closeBtn.addEventListener('click', closeModal);
    
    // 취소 버튼으로 모달 닫기
    cancelBtn.addEventListener('click', closeModal);
    
    // 모달 외부 클릭 시 닫기
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            closeModal();
        }
    });
    
    // ESC 키로 모달 닫기
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && modal.style.display === 'block') {
            closeModal();
        }
    });
    
    // 폼 제출 처리
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const submitBtn = document.querySelector('.submit-btn');
        const originalText = submitBtn.textContent;
        
        // 버튼 상태 변경
        submitBtn.textContent = '전송 중...';
        submitBtn.disabled = true;
        
        // FormData 생성
        const formData = new FormData(contactForm);
        
        // AJAX로 폼 제출
        fetch('send_mail.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // 성공 메시지 표시
                showMessage('success', data.message);
                closeModal();
            } else {
                // 에러 메시지 표시
                showMessage('error', data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showMessage('error', '네트워크 오류가 발생했습니다. 다시 시도해주세요.');
        })
        .finally(() => {
            // 버튼 상태 복원
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        });
    });
    
    // 메시지 표시 함수
    function showMessage(type, message) {
        // 기존 메시지 제거
        const existingMessage = document.querySelector('.message-toast');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // 새 메시지 생성
        const messageDiv = document.createElement('div');
        messageDiv.className = `message-toast ${type}`;
        messageDiv.innerHTML = `
            <div class="message-content">
                <span class="message-icon">${type === 'success' ? '✅' : '❌'}</span>
                <span class="message-text">${message}</span>
            </div>
        `;
        
        // 스타일 적용
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            padding: 15px 20px;
            border-radius: 10px;
            color: white;
            font-weight: 600;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            animation: slideInRight 0.3s ease-out;
            max-width: 400px;
            word-wrap: break-word;
        `;
        
        if (type === 'success') {
            messageDiv.style.background = 'linear-gradient(135deg, #28a745, #20c997)';
        } else {
            messageDiv.style.background = 'linear-gradient(135deg, #dc3545, #e74c3c)';
        }
        
        // DOM에 추가
        document.body.appendChild(messageDiv);
        
        // 5초 후 자동 제거
        setTimeout(() => {
            messageDiv.style.animation = 'slideOutRight 0.3s ease-out';
            setTimeout(() => {
                if (messageDiv.parentNode) {
                    messageDiv.remove();
                }
            }, 300);
        }, 5000);
    }
    
    // CSS 애니메이션 추가
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
        
        .message-content {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .message-icon {
            font-size: 1.2rem;
        }
        
        .message-text {
            flex: 1;
        }
    `;
    document.head.appendChild(style);
});
