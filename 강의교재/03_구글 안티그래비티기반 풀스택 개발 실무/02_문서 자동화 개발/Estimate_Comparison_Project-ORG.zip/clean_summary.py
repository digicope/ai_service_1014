import pandas as pd
from estimate_reader import get_dataframes

def create_clean_company_summary():
    """
    깔끔한 업체별 요약표를 생성하는 함수
    """
    # DataFrame 가져오기
    products_df, conditions_df = get_dataframes()
    
    print("=" * 100)
    print("업체별 종합 비교 요약표")
    print("=" * 100)
    
    # 1. 업체별 기본 정보
    print("\n🏢 업체별 기본 정보")
    print("-" * 100)
    
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values()
    company_product_counts = products_df.groupby('업체명')['품목'].count()
    
    basic_info = pd.DataFrame({
        '업체명': company_totals.index,
        '총견적액': [f"{total:,.0f}원" for total in company_totals.values],
        '제품수': company_product_counts.values,
        '순위': range(1, len(company_totals) + 1)
    })
    
    print(basic_info.to_string(index=False))
    
    # 2. 업체별 상세 조건 요약표
    print("\n📋 업체별 상세 조건 요약표")
    print("-" * 100)
    
    # 각 업체별로 상세 정보 출력
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        company_products = products_df[products_df['업체명'] == company]
        total_amount = company_products['총액'].sum()
        
        print(f"\n【{company}】")
        print(f"💰 총 견적액: {total_amount:,.0f}원")
        print(f"🎯 제품 특장점: {row['제품특장점'].replace('제품 특장점: ', '')}")
        print(f"🚚 납품 조건: {row['납품조건'].replace('납품 조건: ', '')}")
        print(f"🔧 A/S 안내: {row['A/S안내'].replace('A/S 안내: ', '')}")
        
        # 제품 목록
        print(f"📦 제품 목록:")
        for _, product in company_products.iterrows():
            print(f"   • {product['품목']}")
            print(f"     수량: {product['수량']}개, 단가: {product['단가']:,.0f}원, 총액: {product['총액']:,.0f}원")
        print("-" * 80)
    
    # 3. 비교 분석 요약
    print("\n📊 비교 분석 요약")
    print("-" * 100)
    
    print("🏆 가격 경쟁력 순위:")
    for i, (company, total) in enumerate(company_totals.items(), 1):
        print(f"   {i}위: {company} - {total:,.0f}원")
    
    print("\n⚡ 납품 속도 비교:")
    delivery_info = {
        'A컴퍼니': '5일 (가장 빠름)',
        'B테크': '7일', 
        'C솔루션': '10일 (가장 느림)'
    }
    for company, info in delivery_info.items():
        print(f"   {company}: {info}")
    
    print("\n🛡️ A/S 기간 비교:")
    as_info = {
        'C솔루션': '3년 (가장 긴 기간)',
        'A컴퍼니': '2년',
        'B테크': '1년 (가장 짧은 기간)'
    }
    for company, info in as_info.items():
        print(f"   {company}: {info}")
    
    # 4. 간단한 비교표
    print("\n📋 간단한 비교표")
    print("-" * 100)
    
    comparison_data = []
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        company_products = products_df[products_df['업체명'] == company]
        total_amount = company_products['총액'].sum()
        
        comparison_data.append({
            '업체명': company,
            '총견적액': f"{total_amount:,.0f}원",
            '제품특장점': row['제품특장점'].replace('제품 특장점: ', ''),
            '납품조건': row['납품조건'].replace('납품 조건: ', ''),
            'A/S안내': row['A/S안내'].replace('A/S 안내: ', '')
        })
    
    comparison_df = pd.DataFrame(comparison_data)
    
    # 가격 순으로 정렬
    comparison_df['총액_숫자'] = comparison_df['총견적액'].str.replace('원', '').str.replace(',', '').astype(int)
    comparison_df = comparison_df.sort_values('총액_숫자').drop('총액_숫자', axis=1)
    
    print(comparison_df.to_string(index=False))

def create_simple_table():
    """
    가장 간단한 형태의 비교표
    """
    products_df, conditions_df = get_dataframes()
    
    print("\n" + "=" * 100)
    print("간단한 업체별 비교표")
    print("=" * 100)
    
    # 업체별 총 견적액
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values()
    
    print("\n업체명\t\t총견적액\t\t제품특장점")
    print("-" * 100)
    
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        company_products = products_df[products_df['업체명'] == company]
        total_amount = company_products['총액'].sum()
        features = row['제품특장점'].replace('제품 특장점: ', '')
        
        print(f"{company}\t\t{total_amount:,.0f}원\t\t{features}")
    
    print("\n업체명\t\t납품조건")
    print("-" * 100)
    
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        delivery = row['납품조건'].replace('납품 조건: ', '')
        print(f"{company}\t\t{delivery}")
    
    print("\n업체명\t\tA/S안내")
    print("-" * 100)
    
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        as_info = row['A/S안내'].replace('A/S 안내: ', '')
        print(f"{company}\t\t{as_info}")

if __name__ == "__main__":
    # 깔끔한 업체별 요약표 생성
    create_clean_company_summary()
    
    # 간단한 비교표
    create_simple_table()
