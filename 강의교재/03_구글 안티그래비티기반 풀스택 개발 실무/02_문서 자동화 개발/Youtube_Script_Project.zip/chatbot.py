from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv("C:/env/.env")

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# 대화 히스토리 저장
conversation_history = []

# Temperature 모드 설정 (0.2: 보수적, 1.0: 창의적)
temperature_mode = 0.2

def select_temperature_mode():
    global temperature_mode
    print("OpenAI 클라이언트가 성공적으로 초기화되었습니다.")
    print("채팅봇에 오신 것을 환영합니다!")
    print("Temperature 모드를 선택해주세요:")
    print("1. 정확한 모드 (0.2) - 일관되고 정확한 응답")
    print("2. 창의적 모드 (1.0) - 다양하고 창의적인 응답")
    
    while True:
        choice = input("모드를 선택하세요 (1 또는 2): ")
        if choice == "1":
            temperature_mode = 0.2
            print("정확한 모드가 선택되었습니다.\n")
            break
        elif choice == "2":
            temperature_mode = 1.0
            print("창의적 모드가 선택되었습니다.\n")
            break
        else:
            print("잘못된 선택입니다. 1 또는 2를 입력해주세요.")

def chat_with_gpt(user_message):
    try:
        # 사용자 메시지를 히스토리에 추가
        conversation_history.append({"role": "user", "content": user_message})
        
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=conversation_history,
            temperature=temperature_mode
        )
        
        bot_response = response.choices[0].message.content
        
        # 봇 응답을 히스토리에 추가
        conversation_history.append({"role": "assistant", "content": bot_response})
        
        return bot_response
    
    except Exception as e:
        # 오류 발생 시 사용자 메시지를 히스토리에서 제거
        conversation_history.pop()
        return f"오류가 발생했습니다: {str(e)}"

# 메뉴 선택
select_temperature_mode()

print("명령어: 'quit' - 종료, 'temp' - temperature 모드 변경")

while True:
    user_input = input("You: ")
    
    if user_input.lower() == 'quit':
        break
    elif user_input.lower() == 'temp':
        temperature_mode = 1.0 if temperature_mode == 0.2 else 0.2
        mode_name = "정확한" if temperature_mode == 0.2 else "창의적"
        print(f"Temperature 모드가 {temperature_mode} ({mode_name})로 변경되었습니다.\n")
        continue
    
    bot_response = chat_with_gpt(user_input)
    print(f"Bot: {bot_response}\n")


