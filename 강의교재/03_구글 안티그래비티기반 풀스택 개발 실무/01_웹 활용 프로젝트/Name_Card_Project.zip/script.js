// 다크 모드 토글 기능
document.addEventListener('DOMContentLoaded', function() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;
    const businessCard = document.querySelector('.business-card');
    
    // 로컬 스토리지에서 다크 모드 상태 확인
    const isDarkMode = localStorage.getItem('darkMode') === 'true';
    
    // 초기 다크 모드 상태 적용
    if (isDarkMode) {
        body.classList.add('dark-mode');
        updateToggleButton(true);
    }
    
    // 다크 모드 토글 버튼 클릭 이벤트
    darkModeToggle.addEventListener('click', function() {
        body.classList.toggle('dark-mode');
        const isCurrentlyDark = body.classList.contains('dark-mode');
        
        // 로컬 스토리지에 상태 저장
        localStorage.setItem('darkMode', isCurrentlyDark);
        
        // 버튼 텍스트 및 아이콘 업데이트
        updateToggleButton(isCurrentlyDark);
        
        // 부드러운 전환 효과
        businessCard.style.transition = 'all 0.5s ease';
    });
    
    // 토글 버튼 업데이트 함수
    function updateToggleButton(isDark) {
        const toggleIcon = darkModeToggle.querySelector('.toggle-icon');
        const toggleText = darkModeToggle.querySelector('.toggle-text');
        
        if (isDark) {
            toggleIcon.textContent = '☀️';
            toggleText.textContent = '라이트 모드';
        } else {
            toggleIcon.textContent = '🌙';
            toggleText.textContent = '다크 모드';
        }
    }
    
    // 키보드 단축키 지원 (Ctrl + D)
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 'd') {
            e.preventDefault();
            darkModeToggle.click();
        }
    });
});
