#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YouTube Transcript Test Script
"""

from youtube_transcript_api import YouTubeTranscriptApi
import re

def extract_video_id(url):
    """유튜브 URL에서 비디오 ID를 추출"""
    patterns = [
        r'(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)',
        r'youtube\.com\/watch\?.*v=([^&\n?#]+)'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None

def main():
    # 유튜브 URL
    youtube_url = "https://www.youtube.com/watch?v=ZcmYHh1TgVc"
    
    print(f"유튜브 URL: {youtube_url}")
    
    # 비디오 ID 추출
    video_id = extract_video_id(youtube_url)
    if not video_id:
        print("비디오 ID를 추출할 수 없습니다.")
        return
    
    print(f"비디오 ID: {video_id}")
    
    try:
        # 자막 가져오기
        print("자막을 가져오는 중...")
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        
        print("자막을 성공적으로 가져왔습니다!")
        print(f"총 자막 개수: {len(transcript)}개")
        
        # 처음 5개 자막만 출력
        print("\n처음 5개 자막:")
        print("-" * 50)
        for i, entry in enumerate(transcript[:5]):
            start_time = entry['start']
            text = entry['text'].strip()
            minutes = int(start_time // 60)
            seconds = int(start_time % 60)
            print(f"[{minutes:02d}:{seconds:02d}] {text}")
        
        # 전체 자막을 파일로 저장
        with open(f"transcript_{video_id}.txt", 'w', encoding='utf-8') as f:
            for entry in transcript:
                start_time = entry['start']
                text = entry['text'].strip()
                minutes = int(start_time // 60)
                seconds = int(start_time % 60)
                f.write(f"[{minutes:02d}:{seconds:02d}] {text}\n")
        
        print(f"\n전체 자막이 'transcript_{video_id}.txt' 파일로 저장되었습니다.")
        
    except Exception as e:
        print(f"오류 발생: {e}")

if __name__ == "__main__":
    main()
