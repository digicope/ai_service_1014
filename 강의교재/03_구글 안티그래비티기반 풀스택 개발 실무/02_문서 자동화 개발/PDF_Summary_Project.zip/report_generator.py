from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.shared import OxmlElement, qn
from datetime import datetime
import os
import subprocess
import sys
from pptx import Presentation
from pptx.util import Inches as PptInches, Pt as PptPt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor

def create_report_document():
    """
    Generative AI 기술 보고서를 Word 문서로 생성하는 함수
    """
    
    # 새 문서 생성
    doc = Document()
    
    # 문서 스타일 설정
    setup_document_styles(doc)
    
    # 제목 페이지
    add_title_page(doc)
    
    # 목차
    add_table_of_contents(doc)
    
    # 요약
    add_executive_summary(doc)
    
    # 본문 내용
    add_main_content(doc)
    
    # 결론
    add_conclusion(doc)
    
    # 참고문헌
    add_references(doc)
    
    return doc

def setup_document_styles(doc):
    """
    문서 스타일 설정
    """
    # 제목 스타일 설정
    title_style = doc.styles['Title']
    title_style.font.name = '맑은 고딕'
    title_style.font.size = Pt(24)
    title_style.font.bold = True
    
    # 헤딩 스타일 설정
    heading1_style = doc.styles['Heading 1']
    heading1_style.font.name = '맑은 고딕'
    heading1_style.font.size = Pt(18)
    heading1_style.font.bold = True
    
    heading2_style = doc.styles['Heading 2']
    heading2_style.font.name = '맑은 고딕'
    heading2_style.font.size = Pt(16)
    heading2_style.font.bold = True
    
    heading3_style = doc.styles['Heading 3']
    heading3_style.font.name = '맑은 고딕'
    heading3_style.font.size = Pt(14)
    heading3_style.font.bold = True
    
    # 본문 스타일 설정
    normal_style = doc.styles['Normal']
    normal_style.font.name = '맑은 고딕'
    normal_style.font.size = Pt(11)

def add_title_page(doc):
    """
    제목 페이지 추가
    """
    # 제목
    title = doc.add_heading('Generative AI 기술 보고서', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 부제목
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle_run = subtitle.add_run('주제별 분석 및 요약')
    subtitle_run.font.size = Pt(16)
    subtitle_run.font.italic = True
    
    # 빈 줄
    doc.add_paragraph()
    doc.add_paragraph()
    
    # 보고서 정보
    info_para = doc.add_paragraph()
    info_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    info_para.add_run('Inter-American Development Bank (IDB)').font.size = Pt(14)
    info_para.add_run('\n2025년 기술 보고서').font.size = Pt(12)
    
    # 빈 줄
    doc.add_paragraph()
    doc.add_paragraph()
    
    # 날짜
    date_para = doc.add_paragraph()
    date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    date_para.add_run(f'작성일: {datetime.now().strftime("%Y년 %m월 %d일")}').font.size = Pt(12)
    
    # 페이지 나누기
    doc.add_page_break()

def add_table_of_contents(doc):
    """
    목차 추가
    """
    doc.add_heading('목차', level=1)
    
    toc_items = [
        "1. 요약 (Executive Summary)",
        "2. 정의 및 발전사 (Definition and Evolution)",
        "3. 기술 및 작동 원리 (Technology and Workings)",
        "4. 응용 분야 (Applications)",
        "5. 도전과제 및 위험요소 (Challenges and Risks)",
        "6. 모범 사례 및 가이드라인 (Best Practices and Guidelines)",
        "7. 결론 (Conclusion)",
        "8. 참고문헌 (References)"
    ]
    
    for item in toc_items:
        para = doc.add_paragraph(item, style='List Number')
        para.style.font.name = '맑은 고딕'
        para.style.font.size = Pt(11)
    
    doc.add_page_break()

def add_executive_summary(doc):
    """
    요약 섹션 추가
    """
    doc.add_heading('1. 요약 (Executive Summary)', level=1)
    
    # 요약 개요
    doc.add_heading('1.1 보고서 개요', level=2)
    overview_text = """
본 보고서는 Inter-American Development Bank(IDB)의 2025년 Generative AI 기술 보고서를 분석하여 
5개 주요 주제로 분류하고 각 주제별 핵심 내용을 요약한 문서입니다.
    """
    para = doc.add_paragraph(overview_text.strip())
    para.style.font.name = '맑은 고딕'
    para.style.font.size = Pt(11)
    
    # 핵심 내용 요약 표
    doc.add_heading('1.2 핵심 내용 요약', level=2)
    
    # 표 생성
    table = doc.add_table(rows=1, cols=2)
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 헤더 행
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = '주요 내용'
    hdr_cells[1].text = '요약'
    
    # 표 내용 추가
    summary_data = [
        ('기술 정의', '기존 데이터를 기반으로 새로운 콘텐츠를 생성하는 인공지능 기술'),
        ('주요 발전', '2022년 ChatGPT 출시 이후 급속도로 발전, 다양한 산업 분야 혁신'),
        ('응용 분야', '텍스트/이미지/비디오 생성, 번역, 코드 개발, 디자인/예술 등'),
        ('도전과제', '정확성 문제, 편향성, 윤리적 우려, 보안 및 개인정보 보호 문제'),
        ('해결 방안', '포괄적인 AI 거버넌스 프레임워크 구축과 모범 사례 준수')
    ]
    
    for key, value in summary_data:
        row_cells = table.add_row().cells
        row_cells[0].text = key
        row_cells[1].text = value
    
    # 표 스타일링
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.style.font.name = '맑은 고딕'
                paragraph.style.font.size = Pt(10)
    
    # 불릿 포인트 요약
    doc.add_heading('1.3 주요 발견사항', level=2)
    
    findings = [
        "Generative AI는 1950년대부터 시작된 긴 발전 역사를 가지고 있으며, 최근 급속한 발전을 보이고 있음",
        "텍스트, 이미지, 비디오, 오디오, 코드 등 다양한 형태의 콘텐츠 생성이 가능함",
        "법률, 의료, 교육, 엔터테인먼트 등 다양한 산업 분야에서 활용되고 있음",
        "정확성, 편향성, 윤리적 문제 등 여러 도전과제가 존재함",
        "안전하고 책임감 있는 사용을 위한 가이드라인과 모범 사례가 필요함"
    ]
    
    for finding in findings:
        para = doc.add_paragraph(finding, style='List Bullet')
        para.style.font.name = '맑은 고딕'
        para.style.font.size = Pt(11)

def add_main_content(doc):
    """
    본문 내용 추가
    """
    
    # 2. 정의 및 발전사
    doc.add_heading('2. 정의 및 발전사 (Definition and Evolution)', level=1)
    
    # 2.1 기술 정의
    doc.add_heading('2.1 기술 정의', level=2)
    definition_text = """
Generative AI는 기존 데이터를 기반으로 새로운 콘텐츠를 생성하는 인공지능 기술로, 
1950년대 Alan Turing의 이론적 기반부터 시작되어 현재까지 급속도로 발전해왔습니다.
    """
    para = doc.add_paragraph(definition_text.strip())
    para.style.font.name = '맑은 고딕'
    para.style.font.size = Pt(11)
    
    # 2.2 발전 과정 표
    doc.add_heading('2.2 주요 발전 과정', level=2)
    
    # 발전 과정 표 생성
    evolution_table = doc.add_table(rows=1, cols=3)
    evolution_table.style = 'Table Grid'
    evolution_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 헤더
    hdr_cells = evolution_table.rows[0].cells
    hdr_cells[0].text = '연도'
    hdr_cells[1].text = '주요 사건'
    hdr_cells[2].text = '의미'
    
    # 발전 과정 데이터
    evolution_data = [
        ('1956', 'Dartmouth Summer Research Project', 'AI 분야 공식 설립'),
        ('1961', 'ELIZA 챗봇 개발', 'Joseph Weizenbaum의 첫 번째 대화형 AI'),
        ('1979', 'Neocognitron 개발', 'Kunihiko Fukushima의 계층적 신경망'),
        ('1997', 'LSTM 네트워크 도입', '순차 데이터 처리 향상'),
        ('2014', 'GAN 개발', 'Generative Adversarial Networks 등장'),
        ('2017', 'Transformer 모델', 'Attention 메커니즘 도입'),
        ('2022', 'ChatGPT 출시', '대중화 시작, AI 혁신의 전환점')
    ]
    
    for year, event, meaning in evolution_data:
        row_cells = evolution_table.add_row().cells
        row_cells[0].text = year
        row_cells[1].text = event
        row_cells[2].text = meaning
    
    # 표 스타일링
    for row in evolution_table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.style.font.name = '맑은 고딕'
                paragraph.style.font.size = Pt(10)
    
    # 2.3 현재 주요 모델
    doc.add_heading('2.3 현재 주요 모델', level=2)
    
    # 주요 모델 표
    models_table = doc.add_table(rows=1, cols=3)
    models_table.style = 'Table Grid'
    models_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 헤더
    hdr_cells = models_table.rows[0].cells
    hdr_cells[0].text = '회사/기관'
    hdr_cells[1].text = '주요 모델'
    hdr_cells[2].text = '특징'
    
    # 모델 데이터
    models_data = [
        ('OpenAI', 'GPT-4, GPT-4 Turbo, DALL-E 3', '텍스트 및 이미지 생성의 선도적 모델'),
        ('Anthropic', 'Claude', '안전성과 해석가능성 중점'),
        ('Meta', 'LLaMA 시리즈', '효율적인 텍스트 생성'),
        ('Google', 'Gemini', '멀티모달 AI, 창의성과 응용성'),
        ('Stability AI', 'Stable Diffusion 2, 3', '고품질 이미지 생성')
    ]
    
    for company, models, features in models_data:
        row_cells = models_table.add_row().cells
        row_cells[0].text = company
        row_cells[1].text = models
        row_cells[2].text = features
    
    # 표 스타일링
    for row in models_table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.style.font.name = '맑은 고딕'
                paragraph.style.font.size = Pt(10)
    
    # 2.4 핵심 특징
    doc.add_heading('2.4 핵심 특징', level=2)
    
    features = [
        "다양한 형태의 콘텐츠 생성: 텍스트, 이미지, 비디오, 오디오, 코드",
        "원본 데이터와 구별하기 어려운 고품질 콘텐츠 생성",
        "산업 전반에 걸친 혁신적 변화 주도",
        "사용자 친화적 인터페이스로 접근성 향상",
        "지속적인 학습과 개선을 통한 성능 향상"
    ]
    
    for feature in features:
        para = doc.add_paragraph(feature, style='List Bullet')
        para.style.font.name = '맑은 고딕'
        para.style.font.size = Pt(11)
    
    # 3. 기술 및 작동 원리
    doc.add_heading('3. 기술 및 작동 원리 (Technology and Workings)', level=1)
    
    # 3.1 작동 과정
    doc.add_heading('3.1 3단계 작동 과정', level=2)
    
    # 작동 과정 표
    process_table = doc.add_table(rows=1, cols=3)
    process_table.style = 'Table Grid'
    process_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 헤더
    hdr_cells = process_table.rows[0].cells
    hdr_cells[0].text = '단계'
    hdr_cells[1].text = '과정'
    hdr_cells[2].text = '주요 활동'
    
    # 작동 과정 데이터
    process_data = [
        ('훈련 단계', 'Training Phase', '신경망을 통한 대량 데이터 패턴 학습, 비지도/반지도 학습'),
        ('튜닝 단계', 'Tuning Phase', '특정 작업에 맞는 미세 조정, 프롬프트 엔지니어링'),
        ('생성 단계', 'Generation Phase', '학습된 능력 적용, 새로운 콘텐츠 생성')
    ]
    
    for stage, phase, activity in process_data:
        row_cells = process_table.add_row().cells
        row_cells[0].text = stage
        row_cells[1].text = phase
        row_cells[2].text = activity
    
    # 표 스타일링
    for row in process_table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.style.font.name = '맑은 고딕'
                paragraph.style.font.size = Pt(10)
    
    # 3.2 주요 기술 아키텍처
    doc.add_heading('3.2 주요 기술 아키텍처', level=2)
    
    # 기술 아키텍처 표
    tech_table = doc.add_table(rows=1, cols=3)
    tech_table.style = 'Table Grid'
    tech_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 헤더
    hdr_cells = tech_table.rows[0].cells
    hdr_cells[0].text = '기술명'
    hdr_cells[1].text = '약어'
    hdr_cells[2].text = '주요 특징'
    
    # 기술 데이터
    tech_data = [
        ('Generative Adversarial Networks', 'GAN', '생성기와 판별기의 적대적 관계를 통한 고품질 콘텐츠 생성'),
        ('Transformer 모델', 'Transformer', 'Attention 메커니즘을 활용한 시퀀스 처리'),
        ('Long Short-Term Memory', 'LSTM', '순차 데이터 처리에 특화된 순환 신경망'),
        ('Variational Autoencoders', 'VAE', '확률적 인코더-디코더 구조를 통한 데이터 생성')
    ]
    
    for name, abbrev, features in tech_data:
        row_cells = tech_table.add_row().cells
        row_cells[0].text = name
        row_cells[1].text = abbrev
        row_cells[2].text = features
    
    # 표 스타일링
    for row in tech_table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.style.font.name = '맑은 고딕'
                paragraph.style.font.size = Pt(10)
    
    # 3.3 핵심 원리
    doc.add_heading('3.3 핵심 작동 원리', level=2)
    
    principles = [
        "패턴 인식: 대량의 데이터에서 반복되는 패턴을 학습",
        "확률적 생성: 학습된 패턴을 바탕으로 새로운 콘텐츠를 확률적으로 생성",
        "적대적 학습: GAN의 경우 생성기와 판별기가 경쟁하며 성능 향상",
        "어텐션 메커니즘: Transformer에서 중요한 정보에 집중하는 방식",
        "미세 조정: 특정 작업에 맞게 모델을 최적화하는 과정"
    ]
    
    for principle in principles:
        para = doc.add_paragraph(principle, style='List Bullet')
        para.style.font.name = '맑은 고딕'
        para.style.font.size = Pt(11)
    
    # 4. 응용 분야
    doc.add_heading('4. 응용 분야 (Applications)', level=1)
    
    # 4.1 주요 응용 분야 표
    doc.add_heading('4.1 주요 응용 분야', level=2)
    
    # 응용 분야 표
    app_table = doc.add_table(rows=1, cols=3)
    app_table.style = 'Table Grid'
    app_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 헤더
    hdr_cells = app_table.rows[0].cells
    hdr_cells[0].text = '분야'
    hdr_cells[1].text = '주요 기능'
    hdr_cells[2].text = '대표 도구/사례'
    
    # 응용 분야 데이터
    app_data = [
        ('텍스트 처리', '요약, 생성, 번역, 대화형 AI', 'ChatGPT, Claude, 법률 문서 요약'),
        ('멀티미디어 생성', '이미지, 비디오, 오디오 생성', 'DALL-E, Stable Diffusion, Runway Gen-2'),
        ('소프트웨어 개발', '코드 생성, 리뷰, 디버깅', 'GitHub Copilot, Amazon CodeWhisperer'),
        ('창작 및 디자인', '디지털 아트, 3D 모델링', 'Midjourney, 디지털 아트 갤러리'),
        ('과학 연구', '합성 데이터, 의료 연구', '의료 이미지 분석, 시뮬레이션')
    ]
    
    for field, functions, tools in app_data:
        row_cells = app_table.add_row().cells
        row_cells[0].text = field
        row_cells[1].text = functions
        row_cells[2].text = tools
    
    # 표 스타일링
    for row in app_table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.style.font.name = '맑은 고딕'
                paragraph.style.font.size = Pt(10)
    
    # 4.2 IDB 실제 적용 사례
    doc.add_heading('4.2 IDB 실제 적용 사례', level=2)
    
    # IDB 사례 표
    idb_table = doc.add_table(rows=1, cols=3)
    idb_table.style = 'Table Grid'
    idb_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 헤더
    hdr_cells = idb_table.rows[0].cells
    hdr_cells[0].text = '프로젝트명'
    hdr_cells[1].text = '주요 기능'
    hdr_cells[2].text = '활용 효과'
    
    # IDB 사례 데이터
    idb_data = [
        ('IINA', '문서 검색 및 인사이트 종합', '900개 이상 공개 문서에서 효율적 정보 추출'),
        ('Aurora', '내부 문서 검색 및 콘텐츠 생성', '다중 어시스턴트 플랫폼으로 업무 효율성 향상'),
        ('Seek', '출판물 지식 접근 가속화', '출판물 내 정보 검색 및 인용 기능 제공'),
        ('ATAL', '읽기 교육 지원 챗봇', '교사 대상 교육 방법론 및 자료 제공')
    ]
    
    for project, function, effect in idb_data:
        row_cells = idb_table.add_row().cells
        row_cells[0].text = project
        row_cells[1].text = function
        row_cells[2].text = effect
    
    # 표 스타일링
    for row in idb_table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.style.font.name = '맑은 고딕'
                paragraph.style.font.size = Pt(10)
    
    # 4.3 산업별 활용 현황
    doc.add_heading('4.3 산업별 활용 현황', level=2)
    
    industries = [
        "법률: 복잡한 사건 파일 요약, 법률 문서 분석",
        "의료: 의료 이미지 진단 향상, 환자 결과 개선, 치료법 개발 가속화",
        "교육: 개인화된 학습 자료 생성, 교사 지원 시스템",
        "엔터테인먼트: 영화/애니메이션 특수 효과, 음악 작곡",
        "제조업: 제품 디자인, 건축 설계, 도시 계획",
        "미디어: 뉴스 다이제스트 생성, 콘텐츠 자동화"
    ]
    
    for industry in industries:
        para = doc.add_paragraph(industry, style='List Bullet')
        para.style.font.name = '맑은 고딕'
        para.style.font.size = Pt(11)
    
    # 5. 도전과제 및 위험요소
    doc.add_heading('5. 도전과제 및 위험요소 (Challenges and Risks)', level=1)
    
    # 5.1 주요 도전과제 표
    doc.add_heading('5.1 주요 도전과제', level=2)
    
    # 도전과제 표
    challenge_table = doc.add_table(rows=1, cols=3)
    challenge_table.style = 'Table Grid'
    challenge_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 헤더
    hdr_cells = challenge_table.rows[0].cells
    hdr_cells[0].text = '도전과제'
    hdr_cells[1].text = '주요 문제점'
    hdr_cells[2].text = '영향 및 위험'
    
    # 도전과제 데이터
    challenge_data = [
        ('정확성 문제', '환각 현상, 오정보 생성', '뉴스 전파, 법률 조언 등 민감 영역에서의 오정보 위험'),
        ('편향성 및 윤리', '훈련 데이터 편향성 반영', '법 집행, 의료 분야에서 불공정한 결과 초래'),
        ('데이터 품질', '훈련 데이터 품질 문제', '모델 성능에 직접적 영향, 라이선싱 이슈'),
        ('설명 가능성', '블랙박스 문제', '의사결정 과정 이해 어려움, 신뢰성 부족'),
        ('보안 및 개인정보', '데이터 유출, 악성 사용', '규제 준수 문제, 평판 손상 위험')
    ]
    
    for challenge, problem, impact in challenge_data:
        row_cells = challenge_table.add_row().cells
        row_cells[0].text = challenge
        row_cells[1].text = problem
        row_cells[2].text = impact
    
    # 표 스타일링
    for row in challenge_table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.style.font.name = '맑은 고딕'
                paragraph.style.font.size = Pt(10)
    
    # 5.2 구체적 위험 요소
    doc.add_heading('5.2 구체적 위험 요소', level=2)
    
    # 위험 요소별 상세 설명
    risks = [
        "환각 현상: 모델이 거짓 정보를 사실로 제시하는 현상으로, 훈련 데이터의 편향성이나 알고리즘 한계로 인해 발생",
        "편향성 문제: 훈련 데이터의 편향성이 모델 출력에 반영되어 특정 그룹에 대한 불공정한 결과를 초래할 수 있음",
        "지적재산권 침해: 기존 콘텐츠를 학습한 모델이 유사한 콘텐츠를 생성할 때 저작권 문제가 발생할 수 있음",
        "개인정보 유출: 공개 도구 사용 시 입력된 개인정보가 저장되어 다른 사용자에게 노출될 위험",
        "악의적 사용: 가짜 뉴스 생성, 사기성 콘텐츠 제작, 악성 소프트웨어 개발 등에 악용될 가능성",
        "의존성 증가: AI 생성 콘텐츠에 대한 과도한 의존으로 인한 창의성 감소 및 인간의 판단력 약화"
    ]
    
    for risk in risks:
        para = doc.add_paragraph(risk, style='List Bullet')
        para.style.font.name = '맑은 고딕'
        para.style.font.size = Pt(11)
    
    # 5.3 위험 완화 전략
    doc.add_heading('5.3 위험 완화 전략', level=2)
    
    mitigation_strategies = [
        "모델 투명성 향상: 설명 가능한 AI(XAI) 기술을 통한 의사결정 과정 공개",
        "편향성 감지 및 교정: 다양한 데이터셋 사용, 편향성 감지 알고리즘 적용",
        "품질 관리 체계: 입력 데이터 검증, 출력 결과 검토, 지속적인 모니터링",
        "윤리적 가이드라인: AI 사용에 대한 명확한 윤리 기준 수립 및 준수",
        "보안 강화: 데이터 암호화, 접근 제어, 정기적인 보안 감사",
        "사용자 교육: AI의 한계와 올바른 사용법에 대한 교육 프로그램 제공"
    ]
    
    for strategy in mitigation_strategies:
        para = doc.add_paragraph(strategy, style='List Bullet')
        para.style.font.name = '맑은 고딕'
        para.style.font.size = Pt(11)
    
    # 6. 모범 사례 및 가이드라인
    doc.add_heading('6. 모범 사례 및 가이드라인 (Best Practices and Guidelines)', level=1)
    
    # 6.1 프롬프트 라이브러리
    doc.add_heading('6.1 프롬프트 라이브러리 활용', level=2)
    
    # 프롬프트 라이브러리 표
    prompt_table = doc.add_table(rows=1, cols=3)
    prompt_table.style = 'Table Grid'
    prompt_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 헤더
    hdr_cells = prompt_table.rows[0].cells
    hdr_cells[0].text = '라이브러리명'
    hdr_cells[1].text = '대상 모델'
    hdr_cells[2].text = '주요 용도'
    
    # 프롬프트 라이브러리 데이터
    prompt_data = [
        ('Content at Scale Prompt Library', 'ChatGPT, Bard, Midjourney, DALL-E 2', '다양한 사용 사례별 프롬프트 모음'),
        ('Prompts for Content Creation', '전문가 제작 프롬프트', '콘텐츠 생성, 마케팅, 고객 서비스'),
        ('AI Art Prompts', 'DALL-E, Midjourney, Stable Diffusion', 'AI 아트 생성용 프롬프트 및 가이드'),
        ('Coding and Development Prompts', '개발 도구', '코드 작성, 리뷰, 디버깅, 아키텍처 설계'),
        ('Autonomous AI Agents Prompts', 'GPT-4, Auto-GPT, Baby-AGI', '자율 AI 에이전트 구축')
    ]
    
    for library, models, purpose in prompt_data:
        row_cells = prompt_table.add_row().cells
        row_cells[0].text = library
        row_cells[1].text = models
        row_cells[2].text = purpose
    
    # 표 스타일링
    for row in prompt_table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.style.font.name = '맑은 고딕'
                paragraph.style.font.size = Pt(10)
    
    # 6.2 기본 모범 사례
    doc.add_heading('6.2 기본 모범 사례', level=2)
    
    basic_practices = [
        "정확성 검증: AI 생성 콘텐츠의 정확성을 반드시 검증하고 확인",
        "다중 정보원 활용: 단일 정보원으로서의 의존을 금지하고 다양한 출처 활용",
        "기밀 정보 보호: 비공개 또는 기밀 정보 사용 전 조직 승인 확인",
        "개인정보 보호: 개인정보 공유를 금지하고 데이터 보호 조치 강화",
        "투명성 확보: 결론 도달 과정에 대한 질문을 권장하고 설명 가능성 확보",
        "지속적 학습: AI 도구의 한계와 올바른 사용법에 대한 지속적인 학습",
        "편향성 인식: 편향된 데이터에 대한 주의를 기울이고 다양한 관점 고려",
        "조직 가치 준수: 생성된 콘텐츠가 조직의 가치와 일치하는지 확인",
        "저작권 고려: AI 도구 사용 시 저작권 문제를 인식하고 적절한 출처 명시",
        "출처 명시: AI 도구 사용 시 반드시 출처를 명시하고 인용 가이드라인 준수"
    ]
    
    for practice in basic_practices:
        para = doc.add_paragraph(practice, style='List Bullet')
        para.style.font.name = '맑은 고딕'
        para.style.font.size = Pt(11)
    
    # 6.3 조직 차원의 접근
    doc.add_heading('6.3 조직 차원의 접근', level=2)
    
    # 조직 차원 접근 표
    org_table = doc.add_table(rows=1, cols=2)
    org_table.style = 'Table Grid'
    org_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # 헤더
    hdr_cells = org_table.rows[0].cells
    hdr_cells[0].text = '영역'
    hdr_cells[1].text = '주요 활동'
    
    # 조직 차원 데이터
    org_data = [
        ('거버넌스', '포괄적인 AI 거버넌스 프레임워크 구축, AI 데이터 거버넌스 수립'),
        ('보안', '역할 기반 인증 구현, 암호화 및 보안 통신 채널 구축'),
        ('프라이버시', '개인정보 영향 평가 실시, 데이터 프라이버시 규정 준수'),
        ('윤리', '프라이버시 바이 디자인 접근법 채택, 윤리적 가이드라인 수립'),
        ('기술', '적합한 모델 선택, 모델 훈련 최적화, 사용자 경험 테스트'),
        ('환경', '에너지 소비 및 탄소 발자국 영향 인식, 지속가능한 AI 사용')
    ]
    
    for area, activities in org_data:
        row_cells = org_table.add_row().cells
        row_cells[0].text = area
        row_cells[1].text = activities
    
    # 표 스타일링
    for row in org_table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.style.font.name = '맑은 고딕'
                paragraph.style.font.size = Pt(10)
    
    # 6.4 실행 체크리스트
    doc.add_heading('6.4 실행 체크리스트', level=2)
    
    checklist = [
        "AI 도구 도입 전 조직 내 검토 및 승인 절차 수립",
        "사용자 교육 프로그램 개발 및 실시",
        "AI 생성 콘텐츠에 대한 품질 관리 체계 구축",
        "정기적인 보안 감사 및 위험 평가 실시",
        "AI 사용에 대한 윤리적 가이드라인 수립 및 공유",
        "지속적인 모니터링 및 개선 체계 운영"
    ]
    
    for item in checklist:
        para = doc.add_paragraph(item, style='List Bullet')
        para.style.font.name = '맑은 고딕'
        para.style.font.size = Pt(11)

def add_conclusion(doc):
    """
    결론 섹션 추가
    """
    doc.add_heading('7. 결론 (Conclusion)', level=1)
    
    conclusion_text = """
Generative AI는 산업 전반에 혁신을 가져올 잠재력을 가지고 있지만, 
그 사용에는 안전하고 윤리적으로 접근할 책임이 따릅니다.

주요 성과:
• 다양한 분야에서 생산성 향상과 창의적 솔루션 제공
• IDB를 포함한 조직에서의 실제 적용 사례 확산
• 지속적인 기술 발전과 모델 개선

주요 도전과제:
• 정확성, 편향성, 윤리적 우려 등 기술적 한계
• 보안 및 개인정보 보호 문제
• 설명 가능성과 신뢰성 부족

향후 방향:
• 모범 사례 준수와 윤리적 가이드라인 수립
• 강력한 보안 조치 구현
• 지속적인 연구와 개발을 통한 기술 개선
• 조직 차원의 포괄적인 AI 거버넌스 체계 구축

Generative AI의 이점을 최대화하면서 위험을 최소화하기 위해서는 
책임감 있는 혁신과 전략적 도입이 필수적입니다.
    """
    
    para = doc.add_paragraph(conclusion_text.strip())
    para.style.font.name = '맑은 고딕'
    para.style.font.size = Pt(11)

def add_references(doc):
    """
    참고문헌 섹션 추가
    """
    doc.add_heading('8. 참고문헌 (References)', level=1)
    
    references = [
        "Inter-American Development Bank. (2025). Tech Report: Generative AI.",
        "OpenAI. (2022). ChatGPT: Optimizing Language Models for Dialogue.",
        "Anthropic. (2023). Constitutional AI: Harmlessness from AI Feedback.",
        "Meta AI. (2023). LLaMA: Open and Efficient Foundation Language Models.",
        "Google. (2023). Gemini: A Family of Highly Capable Multimodal Models.",
        "Stability AI. (2023). Stable Diffusion: High-Resolution Image Synthesis.",
        "Goodfellow, I., et al. (2014). Generative Adversarial Networks.",
        "Vaswani, A., et al. (2017). Attention Is All You Need.",
        "Association for the Advancement of Artificial Intelligence. (2023). Ethics and Diversity Guidelines.",
        "European Union. (2024). EU AI Act: Regulation on Artificial Intelligence."
    ]
    
    for ref in references:
        para = doc.add_paragraph(ref, style='List Number')
        para.style.font.name = '맑은 고딕'
        para.style.font.size = Pt(10)

def convert_docx_to_pdf(docx_path, pdf_path):
    """
    Word 문서를 PDF로 변환하는 함수
    """
    try:
        # docx2pdf 라이브러리 사용
        from docx2pdf import convert
        convert(docx_path, pdf_path)
        return True
    except ImportError:
        print("docx2pdf 라이브러리가 설치되지 않았습니다.")
        print("pip install docx2pdf 명령으로 설치해주세요.")
        return False
    except Exception as e:
        print(f"PDF 변환 중 오류 발생: {str(e)}")
        return False

def create_presentation():
    """
    Generative AI 기술 보고서를 PowerPoint 프레젠테이션으로 생성하는 함수
    """
    # 새 프레젠테이션 생성
    prs = Presentation()
    
    # 슬라이드 크기 설정 (16:9)
    prs.slide_width = PptInches(13.33)
    prs.slide_height = PptInches(7.5)
    
    # 1. 제목 슬라이드
    slide_layout = prs.slide_layouts[0]  # 제목 슬라이드 레이아웃
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    subtitle = slide.placeholders[1]
    
    title.text = "Generative AI 기술 보고서"
    subtitle.text = "IDB(Inter-American Development Bank) 기술 보고서 분석\n" + datetime.now().strftime("%Y년 %m월 %d일")
    
    # 제목 스타일 설정
    title.text_frame.paragraphs[0].font.size = PptPt(44)
    title.text_frame.paragraphs[0].font.bold = True
    title.text_frame.paragraphs[0].font.color.rgb = RGBColor(31, 73, 125)
    
    # 부제목 스타일 설정
    subtitle.text_frame.paragraphs[0].font.size = PptPt(20)
    subtitle.text_frame.paragraphs[0].font.color.rgb = RGBColor(68, 114, 196)
    
    # 2. 목차 슬라이드
    slide_layout = prs.slide_layouts[1]  # 제목 및 내용 슬라이드 레이아웃
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    content = slide.placeholders[1]
    
    title.text = "목차"
    content.text = """1. 정의 및 발전사 (Definition and Evolution)
2. 기술 및 작동 원리 (Technology and Workings)
3. 응용 분야 (Applications)
4. 도전과제 및 위험요소 (Challenges and Risks)
5. 모범 사례 및 가이드라인 (Best Practices and Guidelines)"""
    
    # 3. 정의 및 발전사 슬라이드
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    content = slide.placeholders[1]
    
    title.text = "1. 정의 및 발전사"
    content.text = """• Generative AI는 인간의 창작물을 모방하여 새로운 콘텐츠를 생성하는 AI 기술
• 2017년 Transformer 아키텍처 등장으로 급속한 발전 시작
• GPT, BERT, DALL-E 등 다양한 모델 개발
• 현재 ChatGPT, Claude, Gemini 등 대화형 AI 서비스로 확산
• 텍스트, 이미지, 음성, 비디오 등 다양한 형태의 콘텐츠 생성 가능"""
    
    # 4. 기술 및 작동 원리 슬라이드
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    content = slide.placeholders[1]
    
    title.text = "2. 기술 및 작동 원리"
    content.text = """• 3단계 작동 과정: 입력 → 처리 → 출력
• Transformer 아키텍처 기반의 딥러닝 모델
• 대규모 데이터셋으로 사전 훈련 후 특정 작업에 파인튜닝
• Attention 메커니즘으로 문맥 이해 및 생성
• 확률적 샘플링을 통한 창의적 콘텐츠 생성"""
    
    # 5. 응용 분야 슬라이드
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    content = slide.placeholders[1]
    
    title.text = "3. 응용 분야"
    content.text = """• 콘텐츠 생성: 문서 작성, 번역, 요약, 이미지 생성
• 고객 서비스: 챗봇, 자동 응답 시스템
• 교육: 개인화된 학습, 자동 채점, 학습 자료 생성
• 의료: 진단 보조, 의료 문서 작성, 연구 분석
• IDB 실제 적용: 프로젝트 제안서 작성, 보고서 생성, 데이터 분석"""
    
    # 6. 도전과제 및 위험요소 슬라이드
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    content = slide.placeholders[1]
    
    title.text = "4. 도전과제 및 위험요소"
    content.text = """• 기술적 한계: 환각(Hallucination), 편향성, 일관성 부족
• 윤리적 문제: 저작권 침해, 가짜 정보 생성, 개인정보 보호
• 비용 및 리소스: 높은 컴퓨팅 비용, 대규모 데이터 요구
• 보안 위험: 데이터 유출, 악용 가능성
• 규제 및 법적 문제: 책임 소재 불분명, 규제 부재"""
    
    # 7. 모범 사례 및 가이드라인 슬라이드
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    content = slide.placeholders[1]
    
    title.text = "5. 모범 사례 및 가이드라인"
    content.text = """• 프롬프트 엔지니어링: 명확하고 구체적인 지시사항 제공
• 인간-AI 협업: AI 결과물에 대한 인간의 검토 및 수정
• 지속적 학습: 새로운 데이터로 모델 업데이트
• 윤리적 가이드라인: 투명성, 공정성, 책임성 확보
• 조직 차원의 접근: 정책 수립, 교육, 모니터링 체계 구축"""
    
    # 8. 결론 슬라이드
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    content = slide.placeholders[1]
    
    title.text = "결론 및 향후 전망"
    content.text = """• Generative AI는 다양한 분야에서 혁신적 변화를 가져올 잠재력
• 기술적 발전과 함께 윤리적, 사회적 고려사항이 중요
• 조직의 체계적 도입과 관리가 성공의 핵심
• 지속적인 연구와 개발을 통한 기술 개선 필요
• 인간과 AI의 협업을 통한 지속가능한 발전 모델 구축"""
    
    # 9. 감사 슬라이드
    slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    subtitle = slide.placeholders[1]
    
    title.text = "감사합니다"
    subtitle.text = "Questions & Discussion"
    
    # 모든 슬라이드의 텍스트 스타일 통일
    for slide in prs.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text_frame"):
                for paragraph in shape.text_frame.paragraphs:
                    paragraph.font.name = "맑은 고딕"
                    if paragraph.font.size is None:
                        paragraph.font.size = PptPt(18)
    
    return prs

def generate_report():
    """
    보고서 생성 및 저장 (Word, PDF, PPT)
    """
    try:
        print("보고서 생성 중...")
        
        # Word 문서 생성
        doc = create_report_document()
        
        # Word 파일 저장
        docx_filename = "ai_report_final.docx"
        doc.save(docx_filename)
        
        print(f"Word 보고서가 성공적으로 생성되었습니다: {docx_filename}")
        print(f"Word 파일 크기: {os.path.getsize(docx_filename)} bytes")
        
        # PDF 변환
        pdf_filename = "ai_report_final.pdf"
        print("PDF 변환 중...")
        
        pdf_success = False
        if convert_docx_to_pdf(docx_filename, pdf_filename):
            print(f"PDF 보고서가 성공적으로 생성되었습니다: {pdf_filename}")
            print(f"PDF 파일 크기: {os.path.getsize(pdf_filename)} bytes")
            pdf_success = True
        else:
            print("PDF 변환에 실패했습니다.")
        
        # PPT 생성
        ppt_filename = "ai_report_final.pptx"
        print("PowerPoint 프레젠테이션 생성 중...")
        
        try:
            prs = create_presentation()
            prs.save(ppt_filename)
            print(f"PowerPoint 프레젠테이션이 성공적으로 생성되었습니다: {ppt_filename}")
            print(f"PPT 파일 크기: {os.path.getsize(ppt_filename)} bytes")
            ppt_success = True
        except Exception as e:
            print(f"PPT 생성 중 오류 발생: {str(e)}")
            ppt_success = False
        
        return docx_filename, pdf_filename if pdf_success else None, ppt_filename if ppt_success else None
        
    except Exception as e:
        print(f"보고서 생성 중 오류 발생: {str(e)}")
        return None, None, None

def main():
    """
    메인 함수
    """
    print("=" * 50)
    print("Generative AI 기술 보고서 생성기")
    print("=" * 50)
    
    # 보고서 생성
    docx_file, pdf_file, ppt_file = generate_report()
    
    if docx_file:
        print("\n보고서 생성 완료!")
        print(f"생성된 Word 파일: {docx_file}")
        
        created_files = [docx_file]
        
        if pdf_file:
            print(f"생성된 PDF 파일: {pdf_file}")
            created_files.append(pdf_file)
        
        if ppt_file:
            print(f"생성된 PowerPoint 파일: {ppt_file}")
            created_files.append(ppt_file)
        
        print(f"\n총 {len(created_files)}개 형식으로 보고서가 생성되었습니다:")
        print("- Word 형식 (.docx): 편집 가능한 상세 문서")
        print("- PDF 형식 (.pdf): 인쇄 및 공유용 문서")
        print("- PowerPoint 형식 (.pptx): 프레젠테이션용 슬라이드")
        
        if not pdf_file:
            print("\n※ PDF 변환을 위해서는 docx2pdf 라이브러리가 필요합니다.")
        if not ppt_file:
            print("※ PPT 생성에 실패했습니다. python-pptx 라이브러리를 확인해주세요.")
        
        print("\n보고서 내용:")
        print("- 제목 페이지")
        print("- 목차")
        print("- 요약 (표와 불릿 포인트 포함)")
        print("- 5개 주요 주제별 상세 분석 (표와 리스트 형식)")
        print("- 결론")
        print("- 참고문헌")
        
        print("\nPowerPoint 프레젠테이션 구성:")
        print("- 제목 슬라이드")
        print("- 목차 슬라이드")
        print("- 5개 주요 주제별 슬라이드 (불릿 포인트 형식)")
        print("- 결론 슬라이드")
        print("- 감사 슬라이드")
    else:
        print("보고서 생성에 실패했습니다.")

if __name__ == "__main__":
    main()
