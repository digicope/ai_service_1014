#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YouTube Script Extractor GUI
유튜브 영상의 스크립트만 추출하고 저장하는 간단한 GUI 앱
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import threading
from datetime import datetime

# 기존 모듈들 import
from youtube_transcript_fetcher import extract_video_id, get_transcript, format_transcript

class YouTubeScriptExtractorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("YouTube Script Extractor")
        self.root.geometry("800x600")
        self.root.configure(bg='#f0f0f0')
        
        # 변수들
        self.current_transcript_data = None
        self.current_video_id = None
        
        self.setup_ui()
        
    def setup_ui(self):
        """UI 구성"""
        # 메인 프레임
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 제목
        title_label = ttk.Label(main_frame, text="YouTube Script Extractor", 
                               font=('Arial', 16, 'bold'))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # URL 입력 섹션
        url_frame = ttk.LabelFrame(main_frame, text="YouTube URL 입력", padding="10")
        url_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.url_var = tk.StringVar()
        url_entry = ttk.Entry(url_frame, textvariable=self.url_var, width=60)
        url_entry.grid(row=0, column=0, padx=(0, 10))
        
        fetch_btn = ttk.Button(url_frame, text="스크립트 추출", 
                              command=self.fetch_transcript)
        fetch_btn.grid(row=0, column=1)
        
        # 비디오 정보 섹션
        info_frame = ttk.LabelFrame(main_frame, text="비디오 정보", padding="10")
        info_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.info_text = scrolledtext.ScrolledText(info_frame, height=4, width=80)
        self.info_text.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        # 스크립트 미리보기 섹션
        preview_frame = ttk.LabelFrame(main_frame, text="스크립트 미리보기", padding="10")
        preview_frame.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        self.preview_text = scrolledtext.ScrolledText(preview_frame, height=15, width=80)
        self.preview_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 진행 상황 표시
        self.progress_var = tk.StringVar(value="대기 중...")
        progress_label = ttk.Label(main_frame, textvariable=self.progress_var)
        progress_label.grid(row=4, column=0, columnspan=2, pady=(0, 10))
        
        # 저장 버튼들
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=5, column=0, columnspan=2, pady=(0, 10))
        
        save_btn = ttk.Button(button_frame, text="텍스트 파일로 저장", 
                             command=self.save_text_file)
        save_btn.grid(row=0, column=0, padx=(0, 10))
        
        auto_save_btn = ttk.Button(button_frame, text="자동 저장", 
                                  command=self.auto_save)
        auto_save_btn.grid(row=0, column=1)
        
        clear_btn = ttk.Button(button_frame, text="초기화", 
                              command=self.clear_all)
        clear_btn.grid(row=0, column=2, padx=(10, 0))
        
        # 그리드 가중치 설정
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(3, weight=1)
        preview_frame.columnconfigure(0, weight=1)
        preview_frame.rowconfigure(0, weight=1)
        
    def fetch_transcript(self):
        """유튜브 스크립트 가져오기"""
        url = self.url_var.get().strip()
        if not url:
            messagebox.showerror("오류", "YouTube URL을 입력해주세요.")
            return
            
        # 백그라운드에서 실행
        thread = threading.Thread(target=self._fetch_transcript_thread)
        thread.daemon = True
        thread.start()
        
    def _fetch_transcript_thread(self):
        """스크립트 가져오기 스레드"""
        try:
            self.progress_var.set("스크립트 가져오는 중...")
            
            # URL에서 비디오 ID 추출
            video_id = extract_video_id(self.url_var.get())
            if not video_id:
                self.root.after(0, lambda: messagebox.showerror("오류", "유효하지 않은 YouTube URL입니다."))
                return
                
            # 스크립트 가져오기
            transcript_data = get_transcript(video_id)
            
            if not transcript_data:
                self.root.after(0, lambda: messagebox.showerror("오류", "자막을 가져올 수 없습니다. 해당 영상에 자막이 없거나 접근할 수 없습니다."))
                return
            
            self.current_transcript_data = transcript_data
            self.current_video_id = video_id
            
            # 스크립트 포맷팅
            formatted_transcript = format_transcript(transcript_data)
            
            # UI 업데이트
            info_text = f"비디오 ID: {video_id}\n"
            info_text += f"자막 개수: {len(transcript_data)}개\n"
            if transcript_data:
                total_duration = transcript_data[-1]['start'] + transcript_data[-1]['duration']
                info_text += f"총 영상 길이: {int(total_duration // 60)}분 {int(total_duration % 60)}초"
            
            self.root.after(0, lambda: self.info_text.delete(1.0, tk.END))
            self.root.after(0, lambda: self.info_text.insert(1.0, info_text))
            
            self.root.after(0, lambda: self.preview_text.delete(1.0, tk.END))
            self.root.after(0, lambda: self.preview_text.insert(1.0, formatted_transcript))
            
            self.root.after(0, lambda: self.progress_var.set("스크립트 가져오기 완료"))
            
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("오류", f"스크립트 가져오기 실패: {str(e)}"))
            self.root.after(0, lambda: self.progress_var.set("오류 발생"))
            
    def save_text_file(self):
        """텍스트 파일로 저장"""
        if not self.current_transcript_data:
            messagebox.showerror("오류", "먼저 스크립트를 가져와주세요.")
            return
            
        # 파일 저장 대화상자
        if self.current_video_id:
            default_filename = f"transcript_{self.current_video_id}.txt"
        else:
            default_filename = "transcript.txt"
            
        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            title="텍스트 파일 저장",
            initialvalue=default_filename
        )
        
        if filename:
            try:
                script_text = format_transcript(self.current_transcript_data)
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(script_text)
                messagebox.showinfo("성공", f"파일이 저장되었습니다:\n{filename}")
            except Exception as e:
                messagebox.showerror("오류", f"파일 저장 실패: {str(e)}")
    
    def auto_save(self):
        """자동으로 파일명 생성하여 저장"""
        if not self.current_transcript_data:
            messagebox.showerror("오류", "먼저 스크립트를 가져와주세요.")
            return
            
        # 자동으로 파일명 생성
        if self.current_video_id:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"transcript_{self.current_video_id}_{timestamp}.txt"
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"transcript_{timestamp}.txt"
        
        try:
            script_text = format_transcript(self.current_transcript_data)
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(script_text)
            messagebox.showinfo("성공", f"파일이 자동으로 저장되었습니다:\n{filename}")
        except Exception as e:
            messagebox.showerror("오류", f"파일 저장 실패: {str(e)}")
    
    def clear_all(self):
        """모든 내용 초기화"""
        self.url_var.set("")
        self.info_text.delete(1.0, tk.END)
        self.preview_text.delete(1.0, tk.END)
        self.progress_var.set("대기 중...")
        self.current_transcript_data = None
        self.current_video_id = None

def main():
    root = tk.Tk()
    app = YouTubeScriptExtractorGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
