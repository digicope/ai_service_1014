import pandas as pd
from estimate_reader import get_dataframes

def create_pivot_tables():
    """
    품목별 단가 및 총액 비교 PivotTable을 생성하는 함수
    """
    # DataFrame 가져오기
    products_df, conditions_df = get_dataframes()
    
    print("=" * 80)
    print("품목별 견적 비교 PivotTable 분석")
    print("=" * 80)
    
    # 1. 품목별 단가 비교 PivotTable
    print("\n📊 품목별 단가 비교 PivotTable")
    print("-" * 80)
    
    unit_price_pivot = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values='단가', 
        aggfunc='first'
    )
    
    # 가격을 천 단위로 포맷팅
    unit_price_formatted = unit_price_pivot.map(
        lambda x: f"{x:,.0f}원" if pd.notna(x) else "-"
    )
    
    print(unit_price_formatted.to_string())
    
    # 2. 품목별 총액 비교 PivotTable
    print("\n💰 품목별 총액 비교 PivotTable")
    print("-" * 80)
    
    total_price_pivot = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values='총액', 
        aggfunc='first'
    )
    
    # 총액을 천 단위로 포맷팅
    total_price_formatted = total_price_pivot.map(
        lambda x: f"{x:,.0f}원" if pd.notna(x) else "-"
    )
    
    print(total_price_formatted.to_string())
    
    # 3. 최저가 분석
    print("\n🏆 품목별 최저가 분석")
    print("-" * 80)
    
    # 단가 최저가 분석
    print("단가 최저가:")
    for product in unit_price_pivot.index:
        product_prices = unit_price_pivot.loc[product].dropna()
        if not product_prices.empty:
            min_price = product_prices.min()
            min_company = product_prices.idxmin()
            print(f"  {product}: {min_company} - {min_price:,.0f}원")
    
    print("\n총액 최저가:")
    for product in total_price_pivot.index:
        product_totals = total_price_pivot.loc[product].dropna()
        if not product_totals.empty:
            min_total = product_totals.min()
            min_company = product_totals.idxmin()
            print(f"  {product}: {min_company} - {min_total:,.0f}원")
    
    # 4. 업체별 총 합계
    print("\n📈 업체별 총 합계")
    print("-" * 80)
    
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values()
    for company, total in company_totals.items():
        print(f"{company}: {total:,.0f}원")
    
    print(f"\n최저가 업체: {company_totals.index[0]} - {company_totals.iloc[0]:,.0f}원")
    
    return unit_price_pivot, total_price_pivot

def create_detailed_comparison():
    """
    더 상세한 비교 분석을 제공하는 함수
    """
    products_df, conditions_df = get_dataframes()
    
    print("\n" + "=" * 80)
    print("상세 비교 분석")
    print("=" * 80)
    
    # 품목별 모든 정보를 포함한 비교표
    print("\n📋 품목별 상세 비교표")
    print("-" * 80)
    
    # 품목별로 그룹화하여 모든 정보 표시
    detailed_comparison = products_df.groupby('품목').apply(
        lambda x: x.set_index('업체명')[['수량', '단가', '총액']].T
    )
    
    for product, data in detailed_comparison.items():
        print(f"\n【{product}】")
        print(data.to_string())
    
    # 업체별 상세 조건과 함께 요약
    print("\n🏢 업체별 종합 정보")
    print("-" * 80)
    
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        company_products = products_df[products_df['업체명'] == company]
        total_amount = company_products['총액'].sum()
        
        print(f"\n【{company}】")
        print(f"총 견적액: {total_amount:,.0f}원")
        print(f"제품 특장점: {row['제품특장점']}")
        print(f"납품 조건: {row['납품조건']}")
        print(f"A/S 안내: {row['A/S안내']}")

if __name__ == "__main__":
    # PivotTable 생성
    unit_pivot, total_pivot = create_pivot_tables()
    
    # 상세 비교 분석
    create_detailed_comparison()
