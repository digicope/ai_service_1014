<?php
// 메일 전송 설정
$to = "digicope@aicore.co.kr";
$subject = "Portfolio Contact Form - New Message";

// 폼 데이터 받기
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $message = isset($_POST['message']) ? trim($_POST['message']) : '';
    
    // 입력값 검증
    if (empty($name) || empty($email) || empty($message)) {
        echo json_encode(['success' => false, 'message' => '모든 필드를 입력해주세요.']);
        exit;
    }
    
    // 이메일 형식 검증
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => '올바른 이메일 주소를 입력해주세요.']);
        exit;
    }
    
    // 메일 내용 구성
    $email_message = "
    <html>
    <head>
        <title>Portfolio Contact Form</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 20px; border-radius: 10px 10px 0 0; }
            .content { background: #f8f9fa; padding: 20px; border-radius: 0 0 10px 10px; }
            .field { margin-bottom: 15px; }
            .label { font-weight: bold; color: #2c3e50; }
            .value { margin-top: 5px; padding: 10px; background: white; border-radius: 5px; border-left: 4px solid #667eea; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>📧 Portfolio Contact Form</h2>
                <p>새로운 연락 메시지가 도착했습니다.</p>
            </div>
            <div class='content'>
                <div class='field'>
                    <div class='label'>👤 이름:</div>
                    <div class='value'>" . htmlspecialchars($name) . "</div>
                </div>
                <div class='field'>
                    <div class='label'>📧 이메일:</div>
                    <div class='value'>" . htmlspecialchars($email) . "</div>
                </div>
                <div class='field'>
                    <div class='label'>💬 메시지:</div>
                    <div class='value'>" . nl2br(htmlspecialchars($message)) . "</div>
                </div>
                <div class='field'>
                    <div class='label'>🕒 전송 시간:</div>
                    <div class='value'>" . date('Y-m-d H:i:s') . "</div>
                </div>
            </div>
        </div>
    </body>
    </html>
    ";
    
    // 메일 헤더 설정
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: " . $name . " <" . $email . ">" . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();
    
    // 메일 전송
    if (mail($to, $subject, $email_message, $headers)) {
        echo json_encode(['success' => true, 'message' => '메시지가 성공적으로 전송되었습니다!']);
    } else {
        echo json_encode(['success' => false, 'message' => '메시지 전송에 실패했습니다. 다시 시도해주세요.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => '잘못된 요청입니다.']);
}
?>
