import pandas as pd
from estimate_reader import get_dataframes

def create_final_comparison():
    """
    단가 비교표, 총액 비교표, 업체별 상세 조건 요약표를 보기 좋게 출력하는 함수
    """
    # DataFrame 가져오기
    products_df, conditions_df = get_dataframes()
    
    print("=" * 120)
    print("📊 견적서 종합 비교 분석")
    print("=" * 120)
    
    # 1. 단가 비교표
    print("\n💰 품목별 단가 비교표")
    print("-" * 120)
    
    unit_price_pivot = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values='단가', 
        aggfunc='first'
    )
    
    # 최저가와 최저가 업체 계산
    unit_price_pivot['최저가'] = unit_price_pivot.min(axis=1)
    unit_price_pivot['최저가업체'] = unit_price_pivot.iloc[:, :-1].idxmin(axis=1)
    
    # 가격을 천 단위로 포맷팅
    unit_price_formatted = unit_price_pivot.copy()
    for col in unit_price_pivot.columns:
        if col not in ['최저가업체']:
            unit_price_formatted[col] = unit_price_pivot[col].map(
                lambda x: f"{x:,.0f}원" if pd.notna(x) else "-"
            )
    
    print(unit_price_formatted.to_string())
    
    # 2. 총액 비교표
    print("\n💵 품목별 총액 비교표")
    print("-" * 120)
    
    total_price_pivot = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values='총액', 
        aggfunc='first'
    )
    
    # 최저가와 최저가 업체 계산
    total_price_pivot['최저가'] = total_price_pivot.min(axis=1)
    total_price_pivot['최저가업체'] = total_price_pivot.iloc[:, :-1].idxmin(axis=1)
    
    # 총액을 천 단위로 포맷팅
    total_price_formatted = total_price_pivot.copy()
    for col in total_price_pivot.columns:
        if col not in ['최저가업체']:
            total_price_formatted[col] = total_price_pivot[col].map(
                lambda x: f"{x:,.0f}원" if pd.notna(x) else "-"
            )
    
    print(total_price_formatted.to_string())
    
    # 3. 업체별 상세 조건 요약표
    print("\n🏢 업체별 상세 조건 요약표")
    print("-" * 120)
    
    # 업체별 총 견적액 계산
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values()
    
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        company_products = products_df[products_df['업체명'] == company]
        total_amount = company_products['총액'].sum()
        
        print(f"\n【{company}】")
        print(f"💰 총 견적액: {total_amount:,.0f}원")
        print(f"🎯 제품 특장점: {row['제품특장점'].replace('제품 특장점: ', '')}")
        print(f"🚚 납품 조건: {row['납품조건'].replace('납품 조건: ', '')}")
        print(f"🔧 A/S 안내: {row['A/S안내'].replace('A/S 안내: ', '')}")
        
        # 제품 목록
        print(f"📦 제품 목록:")
        for _, product in company_products.iterrows():
            print(f"   • {product['품목']}")
            print(f"     수량: {product['수량']}개, 단가: {product['단가']:,.0f}원, 총액: {product['총액']:,.0f}원")
        print("-" * 80)
    
    # 4. 종합 분석 요약
    print("\n📈 종합 분석 요약")
    print("-" * 120)
    
    print("🏆 가격 경쟁력 순위:")
    for i, (company, total) in enumerate(company_totals.items(), 1):
        print(f"   {i}위: {company} - {total:,.0f}원")
    
    print("\n⚡ 납품 속도 비교:")
    delivery_info = {
        'A컴퍼니': '5일 (가장 빠름)',
        'B테크': '7일', 
        'C솔루션': '10일 (가장 느림)'
    }
    for company, info in delivery_info.items():
        print(f"   {company}: {info}")
    
    print("\n🛡️ A/S 기간 비교:")
    as_info = {
        'C솔루션': '3년 (가장 긴 기간)',
        'A컴퍼니': '2년',
        'B테크': '1년 (가장 짧은 기간)'
    }
    for company, info in as_info.items():
        print(f"   {company}: {info}")
    
    # 5. 최저가 품목별 요약
    print("\n🏆 품목별 최저가 요약")
    print("-" * 120)
    
    summary_data = []
    for product in unit_price_pivot.index:
        min_unit_price = unit_price_pivot.loc[product, '최저가']
        min_unit_company = unit_price_pivot.loc[product, '최저가업체']
        min_total_price = total_price_pivot.loc[product, '최저가']
        min_total_company = total_price_pivot.loc[product, '최저가업체']
        
        summary_data.append({
            '품목': product,
            '단가최저가': f"{min_unit_price:,.0f}원",
            '단가최저가업체': min_unit_company,
            '총액최저가': f"{min_total_price:,.0f}원",
            '총액최저가업체': min_total_company
        })
    
    summary_df = pd.DataFrame(summary_data)
    print(summary_df.to_string(index=False))
    
    # 6. 업체별 경쟁력 분석
    print("\n📊 업체별 경쟁력 분석")
    print("-" * 120)
    
    # 각 업체가 최저가를 차지한 품목 수 계산
    unit_wins = unit_price_pivot['최저가업체'].value_counts()
    total_wins = total_price_pivot['최저가업체'].value_counts()
    
    print("단가 최저가 차지 품목 수:")
    for company, count in unit_wins.items():
        print(f"   {company}: {count}개 품목")
    
    print("\n총액 최저가 차지 품목 수:")
    for company, count in total_wins.items():
        print(f"   {company}: {count}개 품목")
    
    return unit_price_pivot, total_price_pivot, summary_df

def create_simple_tables():
    """
    간단한 형태의 비교표들만 보여주는 함수
    """
    products_df, conditions_df = get_dataframes()
    
    print("\n" + "=" * 120)
    print("📋 간단한 비교표")
    print("=" * 120)
    
    # 1. 단가 비교표 (간단)
    print("\n💰 품목별 단가 비교표 (간단)")
    print("-" * 120)
    
    unit_price_pivot = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values='단가', 
        aggfunc='first'
    )
    
    unit_price_formatted = unit_price_pivot.map(
        lambda x: f"{x:,.0f}원" if pd.notna(x) else "-"
    )
    
    print(unit_price_formatted.to_string())
    
    # 2. 총액 비교표 (간단)
    print("\n💵 품목별 총액 비교표 (간단)")
    print("-" * 120)
    
    total_price_pivot = products_df.pivot_table(
        index='품목', 
        columns='업체명', 
        values='총액', 
        aggfunc='first'
    )
    
    total_price_formatted = total_price_pivot.map(
        lambda x: f"{x:,.0f}원" if pd.notna(x) else "-"
    )
    
    print(total_price_formatted.to_string())
    
    # 3. 업체별 상세 조건 요약표 (간단)
    print("\n🏢 업체별 상세 조건 요약표 (간단)")
    print("-" * 120)
    
    company_totals = products_df.groupby('업체명')['총액'].sum().sort_values()
    
    for _, row in conditions_df.iterrows():
        company = row['업체명']
        company_products = products_df[products_df['업체명'] == company]
        total_amount = company_products['총액'].sum()
        
        print(f"\n【{company}】 - {total_amount:,.0f}원")
        print(f"제품 특장점: {row['제품특장점'].replace('제품 특장점: ', '')}")
        print(f"납품 조건: {row['납품조건'].replace('납품 조건: ', '')}")
        print(f"A/S 안내: {row['A/S안내'].replace('A/S 안내: ', '')}")

if __name__ == "__main__":
    # 상세한 종합 비교 분석
    unit_pivot, total_pivot, summary_df = create_final_comparison()
    
    # 간단한 비교표
    create_simple_tables()
