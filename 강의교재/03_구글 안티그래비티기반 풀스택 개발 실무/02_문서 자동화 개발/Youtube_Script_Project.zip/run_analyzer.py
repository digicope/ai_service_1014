#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YouTube AI Analyzer 실행 스크립트
"""

import sys
import os

# 현재 디렉토리를 Python 경로에 추가
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

# 작업 디렉토리를 스크립트가 있는 디렉토리로 변경
os.chdir(current_dir)

try:
    from youtube_ai_analyzer_gui import main
    
    if __name__ == "__main__":
        print("YouTube AI Analyzer를 시작합니다...")
        print(f"작업 디렉토리: {current_dir}")
        main()
        
except ImportError as e:
    print(f"필요한 모듈을 찾을 수 없습니다: {e}")
    print("다음 명령어로 필요한 패키지를 설치해주세요:")
    print("pip install -r requirements.txt")
    sys.exit(1)
except Exception as e:
    print(f"앱 실행 중 오류가 발생했습니다: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
