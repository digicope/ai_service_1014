import pygame
import sys

# pygame 초기화
pygame.init()

# 화면 크기 설정
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# 화면 생성
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Breakout Game")

# 색상 정의
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
PURPLE = (128, 0, 128)

# 패들 클래스
class Paddle:
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.speed = 5
        self.rect = pygame.Rect(x, y, width, height)  # rect 속성 추가
    
    def move_left(self):
        if self.x > 0:
            self.x -= self.speed
            self.rect.x = self.x  # rect 위치 업데이트
    
    def move_right(self):
        if self.x < SCREEN_WIDTH - self.width:
            self.x += self.speed
            self.rect.x = self.x  # rect 위치 업데이트
    
    def draw(self, screen):
        pygame.draw.rect(screen, WHITE, (self.x, self.y, self.width, self.height))

# 공 클래스
class Ball:
    def __init__(self, x, y, radius, speed=3):
        self.x = x
        self.y = y
        self.radius = radius
        self.speed_x = speed
        self.speed_y = -speed
        # 공의 충돌 감지를 위한 rect 속성 추가
        self.rect = pygame.Rect(x - radius, y - radius, radius * 2, radius * 2)
    
    def move(self):
        self.x += self.speed_x
        self.y += self.speed_y
        # rect 위치 업데이트
        self.rect.center = (int(self.x), int(self.y))
    
    def check_wall_collision(self):
        # 좌우 벽 충돌 검사
        if self.x - self.radius <= 0:
            self.x = self.radius  # 벽에 파고들지 않도록 위치 조정
            self.speed_x = -self.speed_x
        elif self.x + self.radius >= SCREEN_WIDTH:
            self.x = SCREEN_WIDTH - self.radius  # 벽에 파고들지 않도록 위치 조정
            self.speed_x = -self.speed_x
        
        # 상단 벽 충돌 검사
        if self.y - self.radius <= 0:
            self.y = self.radius  # 벽에 파고들지 않도록 위치 조정
            self.speed_y = -self.speed_y
    
    def check_bottom_collision(self):
        # 화면 하단에 닿았는지 검사
        if self.y + self.radius >= SCREEN_HEIGHT:
            return True  # 게임 오버
        return False
    
    def check_paddle_collision(self, paddle):
        # 공의 rect와 패들의 rect가 충돌했는지 확인
        if self.rect.colliderect(paddle.rect):
            # 공이 패들 위에서 충돌했을 때만 반사 (패들 아래에서 충돌 방지)
            if self.speed_y > 0:  # 공이 아래로 내려오고 있을 때만
                self.speed_y = -self.speed_y
                # 공이 패들에 파고들지 않도록 위치 조정
                self.y = paddle.y - self.radius
    
    def check_brick_collision(self, brick):
        if not brick.destroyed and self.rect.colliderect(brick.rect):
            self.speed_y = -self.speed_y  # 벽돌에 맞으면 y축 속도 반전
            brick.destroyed = True  # 벽돌 파괴
            # 공이 벽돌에 파고들지 않도록 위치 조정
            if self.speed_y > 0:  # 공이 위로 올라가고 있을 때
                self.y = brick.y + brick.height + self.radius
            else:  # 공이 아래로 내려오고 있을 때
                self.y = brick.y - self.radius
            return True  # 벽돌이 파괴되었음을 알림
        return False
    
    def draw(self, screen):
        pygame.draw.circle(screen, RED, (int(self.x), int(self.y)), self.radius)

# 벽돌 클래스
class Brick:
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.destroyed = False
        self.rect = pygame.Rect(x, y, width, height)  # rect 속성 추가
    
    def draw(self, screen):
        if not self.destroyed:
            pygame.draw.rect(screen, self.color, (self.x, self.y, self.width, self.height))
            # 벽돌 테두리 그리기
            pygame.draw.rect(screen, WHITE, (self.x, self.y, self.width, self.height), 2)

# 난이도 선택 함수
def select_difficulty(screen, font, large_font):
    difficulties = ["Easy", "Normal", "Hard"]
    speeds = [2, 3, 4]
    selected = 0
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected = (selected - 1) % len(difficulties)
                elif event.key == pygame.K_DOWN:
                    selected = (selected + 1) % len(difficulties)
                elif event.key == pygame.K_RETURN:
                    return speeds[selected]
        
        # 화면 그리기
        screen.fill(BLACK)
        
        # 제목
        title_text = large_font.render("Select Difficulty", True, WHITE)
        title_rect = title_text.get_rect(center=(SCREEN_WIDTH // 2, 150))
        screen.blit(title_text, title_rect)
        
        # 난이도 옵션들
        for i, difficulty in enumerate(difficulties):
            color = WHITE if i == selected else (128, 128, 128)
            text = font.render(difficulty, True, color)
            rect = text.get_rect(center=(SCREEN_WIDTH // 2, 250 + i * 50))
            screen.blit(text, rect)
        
        # 안내 메시지
        instruction_text = font.render("Use UP/DOWN arrows and ENTER to select", True, WHITE)
        instruction_rect = instruction_text.get_rect(center=(SCREEN_WIDTH // 2, 450))
        screen.blit(instruction_text, instruction_rect)
        
        pygame.display.flip()

# 게임 초기화 함수
def init_game(ball_speed):
    # 패들 생성 (화면 하단 중앙에 위치)
    paddle_width = 100
    paddle_height = 15
    paddle_x = SCREEN_WIDTH // 2 - paddle_width // 2
    paddle_y = SCREEN_HEIGHT - 30
    paddle = Paddle(paddle_x, paddle_y, paddle_width, paddle_height)
    
    # 공 생성 (화면 중앙에 위치)
    ball_radius = 10
    ball_x = SCREEN_WIDTH // 2
    ball_y = SCREEN_HEIGHT // 2
    ball = Ball(ball_x, ball_y, ball_radius, ball_speed)
    
    # 벽돌 생성 (행렬 형태로 배치)
    brick_width = 75
    brick_height = 25
    brick_rows = 5
    brick_cols = 10
    brick_colors = [RED, ORANGE, YELLOW, GREEN, BLUE]
    
    # 벽돌 그리드의 시작 위치 계산 (중앙 정렬)
    total_brick_width = brick_cols * brick_width
    start_x = (SCREEN_WIDTH - total_brick_width) // 2
    start_y = 50
    
    bricks = []
    for row in range(brick_rows):
        for col in range(brick_cols):
            x = start_x + col * brick_width
            y = start_y + row * brick_height
            color = brick_colors[row % len(brick_colors)]
            brick = Brick(x, y, brick_width, brick_height, color)
            bricks.append(brick)
    
    return paddle, ball, bricks

# 게임 재시작 여부 확인 함수
def ask_restart(screen, font, large_font, message):
    selected = True  # True = Yes, False = No
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    selected = not selected
                elif event.key == pygame.K_RETURN:
                    return selected
                elif event.key == pygame.K_ESCAPE:
                    return False
        
        # 화면 그리기
        screen.fill(BLACK)
        
        # 메시지
        message_text = large_font.render(message, True, WHITE)
        message_rect = message_text.get_rect(center=(SCREEN_WIDTH // 2, 200))
        screen.blit(message_text, message_rect)
        
        # 재시작 옵션
        yes_color = WHITE if selected else (128, 128, 128)
        no_color = WHITE if not selected else (128, 128, 128)
        
        yes_text = font.render("Yes (Y)", True, yes_color)
        no_text = font.render("No (N)", True, no_color)
        
        yes_rect = yes_text.get_rect(center=(SCREEN_WIDTH // 2 - 100, 300))
        no_rect = no_text.get_rect(center=(SCREEN_WIDTH // 2 + 100, 300))
        
        screen.blit(yes_text, yes_rect)
        screen.blit(no_text, no_rect)
        
        # 안내 메시지
        instruction_text = font.render("Use LEFT/RIGHT arrows and ENTER to select", True, WHITE)
        instruction_rect = instruction_text.get_rect(center=(SCREEN_WIDTH // 2, 400))
        screen.blit(instruction_text, instruction_rect)
        
        pygame.display.flip()

# 게임 루프
def main():
    clock = pygame.time.Clock()
    
    # 폰트 설정
    font = pygame.font.Font(None, 36)  # 기본 폰트, 크기 36
    large_font = pygame.font.Font(None, 72)  # 큰 폰트, 크기 72
    
    # 게임 루프
    while True:
        # 난이도 선택
        ball_speed = select_difficulty(screen, font, large_font)
        if ball_speed is None:  # 사용자가 창을 닫은 경우
            break
        
        # 게임 초기화
        paddle, ball, bricks = init_game(ball_speed)
        score = 0
        game_over = False
        game_won = False
        running = True
        
        # 게임 플레이 루프
        while running:
            # 이벤트 처리
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
            
            # 키보드 입력 처리
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                paddle.move_left()
            if keys[pygame.K_RIGHT]:
                paddle.move_right()
            
            # 게임이 진행 중일 때만 공 움직임 및 충돌 검사
            if not game_over and not game_won:
                # 공 움직임 및 충돌 검사
                ball.move()
                ball.check_wall_collision()
                ball.check_paddle_collision(paddle)  # 패들 충돌 검사
                
                # 공이 화면 하단에 닿았는지 검사
                if ball.check_bottom_collision():
                    game_over = True
                
                # 벽돌 충돌 검사 및 점수 업데이트
                for brick in bricks[:]:  # 리스트를 순회하면서 요소를 제거할 때는 슬라이스 복사본을 사용
                    if ball.check_brick_collision(brick):
                        score += 10  # 벽돌 파괴 시 10점 추가
                
                # 파괴되지 않은 벽돌만 남기기
                bricks = [brick for brick in bricks if not brick.destroyed]
                
                # 모든 벽돌이 파괴되었는지 검사
                if len(bricks) == 0:
                    game_won = True
            
            # 화면을 검은색으로 채우기
            screen.fill(BLACK)
            
            # 벽돌들 그리기
            for brick in bricks:
                brick.draw(screen)
            
            # 패들 그리기
            paddle.draw(screen)
            
            # 공 그리기
            ball.draw(screen)
            
            # 점수 표시 (화면 상단 중앙)
            score_text = font.render(f"Score: {score}", True, WHITE)  # 텍스트 렌더링 (텍스트, 안티앨리어싱, 색상)
            score_rect = score_text.get_rect(center=(SCREEN_WIDTH // 2, 20))  # 화면 상단 중앙에 위치
            screen.blit(score_text, score_rect)  # 화면 상단 중앙에 점수 표시
            
            # 화면 업데이트
            pygame.display.flip()
            
            # FPS 제한 (60 FPS)
            clock.tick(60)
            
            # 게임 종료 시 재시작 여부 확인
            if game_over or game_won:
                # 게임 종료 메시지를 잠시 표시
                message = "Game Over" if game_over else "You Win!"
                color = RED if game_over else GREEN
                
                # 게임 종료 메시지 표시
                game_end_text = large_font.render(message, True, color)
                game_end_rect = game_end_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
                screen.blit(game_end_text, game_end_rect)
                
                # 점수 표시
                final_score_text = font.render(f"Final Score: {score}", True, WHITE)
                final_score_rect = final_score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50))
                screen.blit(final_score_text, final_score_rect)
                
                pygame.display.flip()
                pygame.time.wait(2000)  # 2초 대기
                
                # 재시작 여부 확인
                if ask_restart(screen, font, large_font, "Play Again?"):
                    break  # 새로운 게임 시작
                else:
                    # 게임 완전 종료
                    pygame.quit()
                    sys.exit()
    
    # pygame 종료
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
