import os
import sys
from dotenv import load_dotenv
from google import genai
from google.genai import types
from google.genai.errors import APIError

# 윈도우 콘솔 한글/이모지 출력 인코딩 설정
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")

# .env 파일 경로 설정 및 환경 변수 로드
current_dir = os.path.dirname(os.path.abspath(__file__))
dotenv_path = os.path.join(current_dir, ".env")
load_dotenv(dotenv_path)


def select_temperature() -> float:
    """8단계: 생성 파라미터(temperature) 선택 메뉴"""
    print("=" * 45)
    print("  [Gemini 생성 파라미터(temperature) 설정]")
    print("  1. 0.2 - 정밀하고 사실 중심의 일관된 응답")
    print("  2. 1.0 - 창의적이고 다양한 아이디어 중심 응답")
    print("=" * 45)

    while True:
        choice = input("선택해주세요 (1 또는 2, 기본값 1): ").strip()
        if choice in ("", "1"):
            print(">> temperature가 0.2로 설정되었습니다.\n")
            return 0.2
        elif choice == "2":
            print(">> temperature가 1.0으로 설정되었습니다.\n")
            return 1.0
        else:
            print("올바른 번호(1 또는 2)를 입력해주세요.")


def chat_with_gemini():
    """5~8단계: 대화 반복 실행, 대화 메모리(맥락 유지), 오류 처리"""
    # 7단계: API 키 확인 오류 처리
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        print("[오류] GEMINI_API_KEY 환경 변수를 찾을 수 없습니다.")
        print(".env 파일에 GEMINI_API_KEY가 올바르게 설정되어 있는지 확인해주세요.")
        return

    # 7단계: 클라이언트 초기화 오류 처리
    try:
        client = genai.Client(api_key=api_key)
    except Exception as e:
        print(f"[초기화 오류] Gemini 클라이언트를 생성할 수 없습니다: {e}")
        return

    # 8단계: temperature 선택
    temperature = select_temperature()

    # 6단계: 대화 메모리 (히스토리 리스트)
    history = []

    print("-" * 45)
    print("Gemini 챗봇과 대화를 시작합니다!")
    print("대화를 종료하려면 'quit'을 입력하세요.")
    print("-" * 45)

    # 5단계: 반복 실행
    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n대화를 종료합니다. 이용해주셔서 감사합니다!")
            break

        if not user_input:
            continue

        if user_input.lower() == "quit":
            print("Bot: 대화를 종료합니다. 좋은 하루 보내세요!")
            break

        # 6단계: 사용자 메시지를 히스토리에 추가
        user_content = types.Content(
            role="user",
            parts=[types.Part.from_text(text=user_input)],
        )
        history.append(user_content)

        # 7단계: API 요청 및 네트워크 오류 처리
        try:
            response = client.models.generate_content(
                model="gemini-3.5-flash",
                contents=history,
                config=types.GenerateContentConfig(temperature=temperature),
            )

            bot_reply = response.text if response.text else "(응답이 비어 있습니다)"
            print(f"Bot: {bot_reply}\n")

            # 모델 응답을 히스토리에 추가하여 다음 요청 시 맥락 유지
            model_content = types.Content(
                role="model",
                parts=[types.Part.from_text(text=bot_reply)],
            )
            history.append(model_content)

        except APIError as e:
            # API 호출 실패 처리
            print(f"[API 오류] Gemini API 호출 중 문제가 발생했습니다: {e.message or e}")
            history.pop()  # 실패한 질문은 맥락 히스토리에서 제거
        except ConnectionError as e:
            # 네트워크 오류 처리
            print(f"[네트워크 오류] 인터넷 연결 상태를 확인해주세요: {e}")
            history.pop()
        except Exception as e:
            # 기타 예외 처리
            print(f"[시스템 오류] 예기치 않은 오류가 발생했습니다: {e}")
            history.pop()


if __name__ == "__main__":
    chat_with_gemini()
