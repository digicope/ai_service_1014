#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YouTube Script Analyzer GUI Application
유튜브 스크립트 분석 및 MD 파일 생성 GUI 앱
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import threading
import os
from datetime import datetime
import re

# 기존 모듈들 import
from youtube_transcript_fetcher import extract_video_id, get_transcript, format_transcript

class YouTubeAnalyzerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("YouTube Script Analyzer")
        self.root.geometry("1000x700")
        self.root.configure(bg='#f0f0f0')
        
        # YouTube Transcript 관련 변수들
        self.current_transcript_data = None
        
        # 변수들
        self.current_video_id = None
        
        self.setup_ui()
        
    def setup_ui(self):
        """UI 구성"""
        # 메인 프레임
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 제목
        title_label = ttk.Label(main_frame, text="YouTube Script Analyzer", 
                               font=('Arial', 16, 'bold'))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # URL 입력 섹션
        url_frame = ttk.LabelFrame(main_frame, text="YouTube URL 입력", padding="10")
        url_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.url_var = tk.StringVar()
        url_entry = ttk.Entry(url_frame, textvariable=self.url_var, width=60)
        url_entry.grid(row=0, column=0, padx=(0, 10))
        
        fetch_btn = ttk.Button(url_frame, text="스크립트 가져오기", 
                              command=self.fetch_transcript)
        fetch_btn.grid(row=0, column=1)
        
        # 비디오 정보 섹션
        info_frame = ttk.LabelFrame(main_frame, text="비디오 정보", padding="10")
        info_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.info_text = scrolledtext.ScrolledText(info_frame, height=4, width=80)
        self.info_text.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        # 분석 옵션 섹션
        options_frame = ttk.LabelFrame(main_frame, text="분석 옵션", padding="10")
        options_frame.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # 체크박스들
        self.summary_var = tk.BooleanVar(value=True)
        self.faq_var = tk.BooleanVar(value=True)
        self.blog_var = tk.BooleanVar(value=True)
        self.quiz_var = tk.BooleanVar(value=True)
        self.comparison_var = tk.BooleanVar(value=True)
        
        ttk.Checkbutton(options_frame, text="5문장 요약", variable=self.summary_var).grid(row=0, column=0, sticky=tk.W)
        ttk.Checkbutton(options_frame, text="FAQ 형식", variable=self.faq_var).grid(row=0, column=1, sticky=tk.W)
        ttk.Checkbutton(options_frame, text="블로그용 글", variable=self.blog_var).grid(row=1, column=0, sticky=tk.W)
        ttk.Checkbutton(options_frame, text="객관식 퀴즈", variable=self.quiz_var).grid(row=1, column=1, sticky=tk.W)
        ttk.Checkbutton(options_frame, text="최신 동향 비교", variable=self.comparison_var).grid(row=2, column=0, sticky=tk.W)
        
        # 분석 실행 버튼
        analyze_btn = ttk.Button(options_frame, text="분석 실행", 
                                command=self.analyze_transcript)
        analyze_btn.grid(row=3, column=0, columnspan=2, pady=(10, 0))
        
        # 진행 상황 표시
        self.progress_var = tk.StringVar(value="대기 중...")
        progress_label = ttk.Label(main_frame, textvariable=self.progress_var)
        progress_label.grid(row=4, column=0, columnspan=2, pady=(0, 10))
        
        # 결과 표시 섹션
        result_frame = ttk.LabelFrame(main_frame, text="분석 결과", padding="10")
        result_frame.grid(row=5, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        self.result_text = scrolledtext.ScrolledText(result_frame, height=15, width=80)
        self.result_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 저장 버튼
        save_btn = ttk.Button(main_frame, text="MD 파일 저장", 
                             command=self.save_md_file)
        save_btn.grid(row=6, column=0, columnspan=2, pady=(10, 0))
        
        # 그리드 가중치 설정
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(5, weight=1)
        result_frame.columnconfigure(0, weight=1)
        result_frame.rowconfigure(0, weight=1)
        
    def fetch_transcript(self):
        """유튜브 스크립트 가져오기"""
        url = self.url_var.get().strip()
        if not url:
            messagebox.showerror("오류", "YouTube URL을 입력해주세요.")
            return
            
        # 백그라운드에서 실행
        thread = threading.Thread(target=self._fetch_transcript_thread)
        thread.daemon = True
        thread.start()
        
    def _fetch_transcript_thread(self):
        """스크립트 가져오기 스레드"""
        try:
            self.progress_var.set("스크립트 가져오는 중...")
            
            # URL에서 비디오 ID 추출
            video_id = extract_video_id(self.url_var.get())
            if not video_id:
                self.root.after(0, lambda: messagebox.showerror("오류", "유효하지 않은 YouTube URL입니다."))
                return
                
            # 스크립트 가져오기
            transcript_data = get_transcript(video_id)
            
            if not transcript_data:
                self.root.after(0, lambda: messagebox.showerror("오류", "자막을 가져올 수 없습니다. 해당 영상에 자막이 없거나 접근할 수 없습니다."))
                return
            
            self.current_transcript_data = transcript_data
            self.current_video_id = video_id
            
            # UI 업데이트
            info_text = f"비디오 ID: {video_id}\n"
            info_text += f"자막 개수: {len(transcript_data)}개\n"
            if transcript_data:
                total_duration = transcript_data[-1]['start'] + transcript_data[-1]['duration']
                info_text += f"총 영상 길이: {int(total_duration // 60)}분 {int(total_duration % 60)}초"
            
            self.root.after(0, lambda: self.info_text.delete(1.0, tk.END))
            self.root.after(0, lambda: self.info_text.insert(1.0, info_text))
            self.root.after(0, lambda: self.progress_var.set("스크립트 가져오기 완료"))
            
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("오류", f"스크립트 가져오기 실패: {str(e)}"))
            self.root.after(0, lambda: self.progress_var.set("오류 발생"))
            
    def analyze_transcript(self):
        """스크립트 분석 실행"""
        if not self.current_transcript_data:
            messagebox.showerror("오류", "먼저 스크립트를 가져와주세요.")
            return
            
        # 백그라운드에서 실행
        thread = threading.Thread(target=self._analyze_transcript_thread)
        thread.daemon = True
        thread.start()
        
    def _analyze_transcript_thread(self):
        """스크립트 분석 스레드"""
        try:
            self.progress_var.set("분석 중...")
            
            # 스크립트 텍스트 추출
            script_text = format_transcript(self.current_transcript_data)
            
            # 분석 결과 생성
            analysis_result = self.generate_analysis(script_text)
            
            # UI 업데이트
            self.root.after(0, lambda: self.result_text.delete(1.0, tk.END))
            self.root.after(0, lambda: self.result_text.insert(1.0, analysis_result))
            self.root.after(0, lambda: self.progress_var.set("분석 완료"))
            
            # 자동으로 MD 파일 저장
            self.root.after(0, self.auto_save_md_file)
            
            # 원본 스크립트도 텍스트 파일로 저장
            self.root.after(0, self.save_original_script)
            
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("오류", f"분석 실패: {str(e)}"))
            self.root.after(0, lambda: self.progress_var.set("오류 발생"))
            
    def generate_analysis(self, script_text):
        """스크립트 분석 및 결과 생성"""
        analysis = []
        
        # 기본 정보
        analysis.append("# AI 발전 역사 분석 보고서")
        analysis.append(f"**생성일**: {datetime.now().strftime('%Y년 %m월 %d일')}")
        analysis.append(f"**비디오 ID**: {self.current_video_id}")
        analysis.append("")
        
        # 5문장 요약
        if self.summary_var.get():
            analysis.append("## 5문장 요약")
            summary = self.generate_summary(script_text)
            analysis.append(summary)
            analysis.append("")
            
        # 핵심 주제 3가지
        analysis.append("## 핵심 주제 3가지")
        topics = self.generate_topics(script_text)
        analysis.append(topics)
        analysis.append("")
        
        # FAQ 형식
        if self.faq_var.get():
            analysis.append("## FAQ 형식")
            faq = self.generate_faq(script_text)
            analysis.append(faq)
            analysis.append("")
            
        # 블로그용 글
        if self.blog_var.get():
            analysis.append("## 블로그용 글")
            blog = self.generate_blog_post(script_text)
            analysis.append(blog)
            analysis.append("")
            
        # 객관식 퀴즈
        if self.quiz_var.get():
            analysis.append("## 객관식 퀴즈")
            quiz = self.generate_quiz(script_text)
            analysis.append(quiz)
            analysis.append("")
            
        # 최신 동향 비교
        if self.comparison_var.get():
            analysis.append("## 2025년 최신 동향과 비교")
            comparison = self.generate_comparison(script_text)
            analysis.append(comparison)
            analysis.append("")
            
        return "\n".join(analysis)
        
    def generate_summary(self, script_text):
        """5문장 요약 생성 - 실제 스크립트 내용 기반"""
        lines = [line.strip() for line in script_text.split('\n') if line.strip()]
        
        # 시간 정보가 있는 문장들만 추출
        content_lines = []
        for line in lines:
            if line.startswith('[') and ']' in line:
                # 시간 정보 제거하고 내용만 추출
                content = line.split(']', 1)[1].strip()
                if len(content) > 10:  # 의미있는 내용만
                    content_lines.append(content)
        
        if not content_lines:
            return "스크립트에서 의미있는 내용을 찾을 수 없습니다."
        
        # 스크립트를 5개 구간으로 나누어 각각 요약
        total_lines = len(content_lines)
        chunk_size = max(1, total_lines // 5)
        
        summary = []
        for i in range(5):
            start_idx = i * chunk_size
            end_idx = min((i + 1) * chunk_size, total_lines)
            
            if start_idx < total_lines:
                chunk_lines = content_lines[start_idx:end_idx]
                if chunk_lines:
                    # 가장 긴 문장을 선택 (보통 더 의미있음)
                    selected_line = max(chunk_lines, key=len)
                    summary.append(f"{i+1}. {selected_line}")
                else:
                    summary.append(f"{i+1}. 내용 없음")
        
        return "\n".join(summary)
        
    def generate_topics(self, script_text):
        """핵심 주제 3가지 생성 - 실제 스크립트 내용 기반"""
        lines = [line.strip() for line in script_text.split('\n') if line.strip()]
        
        # 시간 정보가 있는 문장들만 추출
        content_lines = []
        for line in lines:
            if line.startswith('[') and ']' in line:
                # 시간 정보 제거하고 내용만 추출
                content = line.split(']', 1)[1].strip()
                if len(content) > 15:  # 의미있는 내용만
                    content_lines.append(content)
        
        if not content_lines:
            return "스크립트에서 의미있는 내용을 찾을 수 없습니다."
        
        # 스크립트를 3개 구간으로 나누어 각각의 주제 추출
        total_lines = len(content_lines)
        chunk_size = max(1, total_lines // 3)
        
        topics = []
        for i in range(3):
            start_idx = i * chunk_size
            end_idx = min((i + 1) * chunk_size, total_lines)
            
            if start_idx < total_lines:
                chunk_lines = content_lines[start_idx:end_idx]
                if chunk_lines:
                    # 가장 긴 문장을 주제로 사용
                    main_topic = max(chunk_lines, key=len)
                    topics.append(f"### **주제 {i+1}**")
                    topics.append(f"- {main_topic}")
                    topics.append("")
                else:
                    topics.append(f"### **주제 {i+1}**")
                    topics.append(f"- 내용 없음")
                    topics.append("")
        
        return "\n".join(topics)
        
    def generate_faq(self, script_text):
        """FAQ 형식 생성 - 실제 스크립트 내용 기반"""
        lines = [line.strip() for line in script_text.split('\n') if line.strip()]
        
        # 시간 정보가 있는 문장들만 추출
        content_lines = []
        for line in lines:
            if line.startswith('[') and ']' in line:
                # 시간 정보 제거하고 내용만 추출
                content = line.split(']', 1)[1].strip()
                if len(content) > 20:  # 의미있는 내용만
                    content_lines.append(content)
        
        if not content_lines:
            return "스크립트에서 의미있는 내용을 찾을 수 없습니다."
        
        faq = []
        
        # Q1: 시작/기원 관련
        faq.append("### **Q1. 이 영상의 주요 내용은 무엇인가요?**")
        faq.append(f"**A.** {content_lines[0]}")
        faq.append("")
        
        # Q2: 중간 내용
        faq.append("### **Q2. 핵심 포인트는 무엇인가요?**")
        if len(content_lines) > 1:
            mid_idx = len(content_lines) // 2
            faq.append(f"**A.** {content_lines[mid_idx]}")
        else:
            faq.append(f"**A.** {content_lines[0]}")
        faq.append("")
        
        # Q3: 기술적 내용
        faq.append("### **Q3. 기술적 특징은 무엇인가요?**")
        tech_lines = [line for line in content_lines if any(word in line.lower() for word in ['기술', '시스템', '알고리즘', '데이터', 'AI', '인공지능', '컴퓨터', '프로그램'])]
        if tech_lines:
            faq.append(f"**A.** {tech_lines[0]}")
        elif len(content_lines) > 2:
            faq.append(f"**A.** {content_lines[2]}")
        else:
            faq.append(f"**A.** {content_lines[0]}")
        faq.append("")
        
        # Q4: 결론/현재 상황
        faq.append("### **Q4. 현재 상황은 어떻게 되나요?**")
        if len(content_lines) > 3:
            faq.append(f"**A.** {content_lines[-1]}")
        else:
            faq.append(f"**A.** {content_lines[0]}")
        
        return "\n".join(faq)
        
    def generate_blog_post(self, script_text):
        """블로그용 글 생성 - 실제 스크립트 내용 기반"""
        lines = [line.strip() for line in script_text.split('\n') if line.strip()]
        
        # 시간 정보가 있는 문장들만 추출
        content_lines = []
        for line in lines:
            if line.startswith('[') and ']' in line:
                # 시간 정보 제거하고 내용만 추출
                content = line.split(']', 1)[1].strip()
                if len(content) > 15:  # 의미있는 내용만
                    content_lines.append(content)
        
        if not content_lines:
            return "스크립트에서 의미있는 내용을 찾을 수 없습니다."
        
        blog = []
        
        # 제목 (스크립트의 첫 번째 의미있는 문장 기반)
        if content_lines:
            title = content_lines[0][:50] + "..." if len(content_lines[0]) > 50 else content_lines[0]
            blog.append(f"# {title}")
        else:
            blog.append("# 스크립트 분석 기반 블로그 포스트")
        blog.append("")
        
        # 서론
        blog.append("## 서론")
        blog.append(content_lines[0])
        blog.append("")
        
        # 본문 (3개 섹션)
        blog.append("## 본문")
        for i in range(3):
            if i < len(content_lines):
                blog.append(f"### 섹션 {i+1}")
                blog.append(content_lines[i])
                blog.append("")
            else:
                blog.append(f"### 섹션 {i+1}")
                blog.append(content_lines[0])  # 첫 번째 내용으로 대체
                blog.append("")
        
        # 결론
        blog.append("## 결론")
        if len(content_lines) > 1:
            blog.append(content_lines[-1])
        else:
            blog.append(content_lines[0])
        
        return "\n".join(blog)
        
    def generate_quiz(self, script_text):
        """객관식 퀴즈 생성 - 실제 스크립트 내용 기반"""
        lines = [line.strip() for line in script_text.split('\n') if line.strip()]
        
        # 시간 정보가 있는 문장들만 추출
        content_lines = []
        for line in lines:
            if line.startswith('[') and ']' in line:
                # 시간 정보 제거하고 내용만 추출
                content = line.split(']', 1)[1].strip()
                if len(content) > 15:  # 의미있는 내용만
                    content_lines.append(content)
        
        if not content_lines:
            return "스크립트에서 의미있는 내용을 찾을 수 없습니다."
        
        quiz = []
        
        # 문제 1: 주요 내용
        quiz.append("## 문제 1")
        quiz.append("이 영상의 주요 내용은 무엇인가요?")
        quiz.append("")
        quiz.append("(a) 기술적 설명")
        quiz.append("(b) 역사적 배경")
        quiz.append("(c) 현재 상황")
        quiz.append("(d) 미래 전망")
        quiz.append("")
        quiz.append(f"**정답: 스크립트 내용 - {content_lines[0][:100]}...**")
        quiz.append("")
        quiz.append("---")
        quiz.append("")
        
        # 문제 2: 핵심 개념
        quiz.append("## 문제 2")
        quiz.append("핵심 개념은 무엇인가요?")
        quiz.append("")
        quiz.append("(a) 시스템")
        quiz.append("(b) 알고리즘")
        quiz.append("(c) 데이터")
        quiz.append("(d) 기술")
        quiz.append("")
        if len(content_lines) > 1:
            quiz.append(f"**정답: 스크립트 내용 - {content_lines[1][:100]}...**")
        else:
            quiz.append(f"**정답: 스크립트 내용 - {content_lines[0][:100]}...**")
        quiz.append("")
        quiz.append("---")
        quiz.append("")
        
        # 문제 3: 결론
        quiz.append("## 문제 3")
        quiz.append("결론은 무엇인가요?")
        quiz.append("")
        quiz.append("(a) 성공적인 결과")
        quiz.append("(b) 지속적인 발전")
        quiz.append("(c) 새로운 도전")
        quiz.append("(d) 미래 전망")
        quiz.append("")
        if len(content_lines) > 2:
            quiz.append(f"**정답: 스크립트 내용 - {content_lines[2][:100]}...**")
        else:
            quiz.append(f"**정답: 스크립트 내용 - {content_lines[0][:100]}...**")
        
        return "\n".join(quiz)
        
    def generate_comparison(self, script_text):
        """최신 동향 비교 생성 - 실제 스크립트 내용 기반"""
        lines = [line.strip() for line in script_text.split('\n') if line.strip()]
        
        # 시간 정보가 있는 문장들만 추출
        content_lines = []
        for line in lines:
            if line.startswith('[') and ']' in line:
                # 시간 정보 제거하고 내용만 추출
                content = line.split(']', 1)[1].strip()
                if len(content) > 15:  # 의미있는 내용만
                    content_lines.append(content)
        
        if not content_lines:
            return "스크립트에서 의미있는 내용을 찾을 수 없습니다."
        
        comparison = []
        
        # 스크립트 내용 분석
        comparison.append("### **스크립트 내용 분석**")
        comparison.append(f"- **주요 내용**: {content_lines[0]}")
        
        if len(content_lines) > 1:
            comparison.append(f"- **핵심 포인트**: {content_lines[1]}")
        else:
            comparison.append(f"- **핵심 포인트**: {content_lines[0]}")
        
        if len(content_lines) > 2:
            comparison.append(f"- **기술적 특징**: {content_lines[2]}")
        else:
            comparison.append(f"- **기술적 특징**: {content_lines[0]}")
        comparison.append("")
        
        # 2025년 최신 동향
        comparison.append("### **2025년 최신 동향**")
        comparison.append("- **4차 AI 붐**: 멀티모달 AI와 AI 에이전트 시대")
        comparison.append("- **새로운 성과**: GPT-4, Claude, Gemini 등 대화형 AI의 일상화")
        comparison.append("- **현재 상황**: AI가 모든 산업의 기반 기술로 자리매김")
        comparison.append("")
        
        # 주요 변화점
        comparison.append("### **주요 변화점**")
        comparison.append("1. **기술적 진화**: 온디바이스 AI, 멀티모달 AI, AI 에이전트 등장")
        comparison.append("2. **산업 적용**: 모든 분야로 확장, 범용 AI와 특화 AI 공존")
        comparison.append("3. **사회적 영향**: AI 윤리, 법제도 정비, 규제 체계 구축")
        
        return "\n".join(comparison)
        
    def save_md_file(self):
        """MD 파일 저장"""
        if not self.result_text.get(1.0, tk.END).strip():
            messagebox.showerror("오류", "먼저 분석을 실행해주세요.")
            return
            
        # 자동으로 파일명 생성
        if self.current_video_id:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"youtube_analysis_{self.current_video_id}_{timestamp}.md"
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"youtube_analysis_{timestamp}.md"
        
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(self.result_text.get(1.0, tk.END))
            messagebox.showinfo("성공", f"파일이 자동으로 저장되었습니다:\n{filename}")
        except Exception as e:
            messagebox.showerror("오류", f"파일 저장 실패: {str(e)}")
    
    def auto_save_md_file(self):
        """분석 완료 후 자동으로 MD 파일 저장"""
        if not self.result_text.get(1.0, tk.END).strip():
            return
            
        # 자동으로 파일명 생성
        if self.current_video_id:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"youtube_analysis_{self.current_video_id}_{timestamp}.md"
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"youtube_analysis_{timestamp}.md"
        
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(self.result_text.get(1.0, tk.END))
            self.progress_var.set(f"분석 완료 및 자동 저장: {filename}")
        except Exception as e:
            self.progress_var.set(f"자동 저장 실패: {str(e)}")
    
    def save_original_script(self):
        """원본 스크립트를 텍스트 파일로 저장"""
        if not self.current_transcript_data:
            return
            
        # 자동으로 파일명 생성
        if self.current_video_id:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"transcript_{self.current_video_id}_{timestamp}.txt"
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"transcript_{timestamp}.txt"
        
        try:
            # 원본 스크립트 포맷팅
            script_text = format_transcript(self.current_transcript_data)
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(script_text)
            
            # 진행 상황에 원본 스크립트 저장 완료 표시
            current_status = self.progress_var.get()
            self.progress_var.set(f"{current_status} | 원본 스크립트 저장: {filename}")
        except Exception as e:
            current_status = self.progress_var.get()
            self.progress_var.set(f"{current_status} | 원본 스크립트 저장 실패: {str(e)}")

def main():
    root = tk.Tk()
    app = YouTubeAnalyzerGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
