#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YouTube Script Analyzer GUI 실행 스크립트
"""

import sys
import os

# 현재 디렉토리를 Python 경로에 추가
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

try:
    from youtube_analyzer_gui import main
    print("YouTube Script Analyzer GUI를 시작합니다...")
    main()
except ImportError as e:
    print(f"필요한 모듈을 찾을 수 없습니다: {e}")
    print("다음 명령어로 필요한 패키지를 설치해주세요:")
    print("pip install -r requirements.txt")
except Exception as e:
    print(f"오류가 발생했습니다: {e}")
    input("엔터를 눌러 종료하세요...")
